(function(){
var l=document.createElement('link');l.rel='stylesheet';l.href='https://fonts.googleapis.com/css2?family=Nunito:wght@900&display=swap';document.head.appendChild(l);
var st=document.createElement('style');st.textContent='.upl{stroke-dasharray:1;stroke-dashoffset:1;animation:upLine 1.4s ease-out .2s forwards}@keyframes upLine{to{stroke-dashoffset:0}}.upd{opacity:0;transform-box:fill-box;transform-origin:center;animation:upPop .5s cubic-bezier(.3,1.6,.5,1) 1.5s forwards,upPulse 2.4s ease-in-out 2.2s infinite}@keyframes upPop{from{opacity:0;transform:scale(0)}to{opacity:1;transform:scale(1)}}@keyframes upPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.25)}}.upr{stroke-dasharray:0 100;animation:upRing 1.6s cubic-bezier(.4,0,.2,1) .4s forwards}@keyframes upRing{to{stroke-dasharray:70 100}}';document.head.appendChild(st);
var mark='<svg width="48" height="48" viewBox="0 0 120 120"><defs><linearGradient id="upmoMark" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient></defs><rect width="120" height="120" rx="30" fill="url(#upmoMark)"/><path class="upl" pathLength="1" d="M24 88 C48 88 44 60 60 60 S74 32 96 32" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round"/><circle cx="24" cy="88" r="5" fill="#fff" fill-opacity="0.55"/><circle class="upd" cx="96" cy="32" r="8" fill="#fff"/></svg>';
var ring='<svg width="44" height="44" viewBox="0 0 100 100" style="margin-left:3px;"><defs><linearGradient id="upmoRing" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient></defs><circle cx="50" cy="50" r="38" fill="none" stroke="url(#upmoRing)" stroke-opacity="0.25" stroke-width="16"/><circle class="upr" pathLength="100" cx="50" cy="50" r="38" fill="none" stroke="url(#upmoRing)" stroke-width="16" stroke-linecap="round" transform="rotate(-90 50 50)"/></svg>';
var html='<div style="display:flex;align-items:center;justify-content:center;gap:12px;font-family:Nunito,Arial,sans-serif;">'+mark+'<div style="display:flex;align-items:center;font-size:52px;font-weight:900;letter-spacing:-1px;line-height:1;"><span style="background:linear-gradient(90deg,#6A5BD6,#5B94D0);-webkit-background-clip:text;background-clip:text;color:transparent;">UPM</span>'+ring+'</div></div>';
function put(){var t=document.getElementById("upmoLogo");if(t){t.innerHTML=html;t.style.cssText="padding:36px 0 24px 0;";}}
if(document.readyState=='loading'){document.addEventListener('DOMContentLoaded',put);}else{put();}
})();
(function(){
var st=document.createElement('style');
st.textContent='.card{border-radius:22px!important;overflow:hidden;box-shadow:0 24px 70px rgba(91,148,208,.28),0 0 0 1px rgba(106,91,214,.12)!important;}'
+'button[type=submit]{background:linear-gradient(90deg,#6A5BD6,#5B94D0 60%,#5FD2B0)!important;border-radius:18px!important;box-shadow:0 8px 22px rgba(91,148,208,.35);}'
+'button[type=submit]:hover{background:linear-gradient(90deg,#5B4DC4,#4A83C2 60%,#4FC4A2)!important;}'
+'input:focus{border-color:#5B94D0!important;box-shadow:inset 0 0 8px rgba(91,148,208,.18)!important;}';
document.head.appendChild(st);
var f=document.getElementById('form');
if(f){f.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.tagName==='INPUT'){e.preventDefault();if(f.requestSubmit){f.requestSubmit();}else{f.dispatchEvent(new Event('submit',{cancelable:true}));}}});}
})();
