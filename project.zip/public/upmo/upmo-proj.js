(function(){
function fd(s){if(!s){return '—';}var d=new Date(s);if(isNaN(d.getTime())){return String(s);}var m=d.getMonth()+1,dd=d.getDate();return (dd<10?'0':'')+dd+'.'+(m<10?'0':'')+m+'.'+d.getFullYear();}
function pill(bg,t){return '<span style="background:'+bg+';color:#fff;border-radius:9px;padding:2px 0;width:38px;display:inline-block;text-align:center;font-size:9px;font-weight:700;font-variant-numeric:tabular-nums;">'+t+'</span>';}
function pills(has,pl,f){
var w='<span style="display:flex;gap:4px;align-items:center;margin-left:auto;flex-shrink:0;">';
if(!has){return w+pill('#cbd5e1','—')+pill('#cbd5e1','—')+'<span style="width:34px;text-align:right;color:#9ca3af;font-size:9px;font-weight:700;">—</span></span>';}
var d=f-pl;var dc=d<0?'#e53e3e':'#38a169';
return w+pill('#4a9fd8',pl+'%')+pill('#38a169',f+'%')+'<span style="width:34px;text-align:right;color:'+dc+';font-size:9px;font-weight:700;">'+(d>0?'+':'')+d+'%</span></span>';
}
function bar(has,pl,f){
if(!has){return '';}
return '<div style="position:relative;height:5px;border-radius:3px;background:#e5e7eb;margin-top:5px;"><div style="position:absolute;left:0;top:0;bottom:0;width:'+Math.min(100,f)+'%;background:#38a169;border-radius:3px;"></div><div style="position:absolute;top:-2px;bottom:-2px;left:'+Math.min(100,pl)+'%;width:2px;background:#4a9fd8;"></div></div>';
}
function dates(a,b,has){return '<div style="font-size:9px;color:#6b7280;margin-top:3px;">'+(has?fd(a)+' — '+fd(b):'нет данных')+'</div>';}
window.upmoProj=function(el,ty){
if(el===null){return;}window._upmoFocus=null;
el.style.overflow='auto';el.style.padding='12px';el.style.scrollbarWidth='none';el.style.msOverflowStyle='none';if(!document.getElementById('upmoProjSt')){var sx=document.createElement('style');sx.id='upmoProjSt';sx.textContent='#upmoBlk3::-webkit-scrollbar{display:none;}';document.head.appendChild(sx);}
el.innerHTML='<div style="font-size:11px;color:#6b7280;">Загрузка...</div>';
fetch('/api/prep/objects'+(ty?'?type='+ty:'')).then(function(r){return r.json();}).then(function(list){
var names={},pre={},dm={};
PROJECTS.prep.items.forEach(function(it){names[it.code]=it.name;if(ty){return;}var pc=it.code.split('-')[0];if(pre[pc]==null){pre[pc]=[];}pre[pc].push(it.code);});
list.forEach(function(o){dm[o.code]=o;var pc=o.code.split('-')[0];if(pre[pc]==null){pre[pc]=[];}if(pre[pc].indexOf(o.code)<0){pre[pc].push(o.code);}});
var pn={OPS01:'Внепроектные объекты'};
[].concat(PROJECTS.main.items,PROJECTS.aux.items).forEach(function(p){pn[p.code]=p.name;});
var parents=[],used={};
[].concat(PROJECTS.main.items,PROJECTS.aux.items).forEach(function(p){if(pre[p.code]!=null){parents.push({code:p.code,name:p.name});used[p.code]=true;}});
Object.keys(pre).forEach(function(pc){if(used[pc]==true){return;}parents.push({code:pc,name:pn[pc]||pc});});
var tot={c:0,d:0,w:0};
var h='';
parents.forEach(function(p){
var codes=pre[p.code]||[];var cost=0,done=0,pw=0,has=false,st=null,en=null;var objs='';
codes.forEach(function(c){
var o=dm[c];var oh=(o!=null)&&((o.cost||0)>0);
var opl=0,of=0;
if(oh){has=true;cost+=o.cost||0;done+=o.done||0;pw+=(o.planPct||0)*(o.cost||0);opl=Math.round(o.planPct||0);of=o.cost?Math.round((o.done||0)/o.cost*100):0;
if(o.start&&(st==null||new Date(o.start)<new Date(st))){st=o.start;}
if(o.end&&(en==null||new Date(o.end)>new Date(en))){en=o.end;}}
objs+='<div class="upO" data-oc="'+c+'" style="cursor:pointer;padding:8px 10px;border-top:1px solid #eef0f3;"><div style="display:flex;align-items:center;gap:6px;font-size:10px;color:#374151;"><span>'+(names[c]||c)+'</span>'+pills(oh,opl,of)+'</div>'+'</div>';
});
if(has){tot.c+=cost;tot.d+=done;tot.w+=pw;}
var ppl=cost?Math.round(pw/cost):0;var pf=cost?Math.round(done/cost*100):0;
h+='<div style="border-radius:14px;background:#fff;box-shadow:0 1px 6px rgba(0,0,0,0.14);margin-bottom:8px;overflow:hidden;"><div class="upP" data-pk="'+p.code+'" style="padding:9px 10px;cursor:pointer;"><div style="display:flex;align-items:center;gap:6px;font-size:11px;font-weight:700;color:#1f2937;"><span>'+p.code+' '+p.name+'</span>'+pills(has,ppl,pf)+'</div>'+'</div><div data-kids="'+p.code+'" data-o="0" style="max-height:0;overflow:hidden;transition:max-height .35s ease;background:#fff;">'+objs+'</div></div>';
});
var tpl=tot.c?Math.round(tot.w/tot.c):0;var tf=tot.c?Math.round(tot.d/tot.c*100):0;
el.innerHTML=h;
var MNF=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
function setCardMonth(tt,bb,v0,v1,v2){
var cd=document.getElementById('upmoCard');if(cd===null||cd.children.length<3){return;}
var t=cd.children[0],bg=cd.children[1],g=cd.children[2];
var vs=[g.children[0].children[1],g.children[1].children[1],g.children[2].children[1]];
if(!cd._o){cd._o=[t.textContent,bg.textContent,vs[0].textContent,vs[1].textContent,vs[2].textContent];}
anim(t,tt);anim(bg,bb);anim(vs[0],v0);anim(vs[1],v1);anim(vs[2],v2);
}
function setProgPct(pp,fp){
var p=document.getElementById('upmoBlk4b2');if(!p||p.children.length<2){return;}
var cs=p.children[0].children;
var pv=[cs[0].children[1],cs[1].children[1],cs[2].children[1]];
var bars=p.children[1].children;
var bi=[bars[0].firstChild,bars[1].firstChild];
if(!p._o){p._o=[pv[0].textContent,pv[1].textContent,pv[2].textContent,pv[2].style.color,bi[0].style.width,bi[1].style.width];}
function pf(x){return (Math.round(x*10)/10).toString().replace('.',',')+'%';}
var x0,x1,x2,xc,w0,w1;
if(pp===null||fp===null){x0='—';x1='—';x2='—';xc='#9ca3af';w0='0%';w1='0%';}
else{var df=fp-pp;var base=Math.max(pp,fp);x0=pf(pp);x1=pf(fp);x2=(df>0?'+':'')+pf(df);xc=df<0?'#e53e3e':'#38a169';w0=(base>0?pp/base*100:0)+'%';w1=(base>0?fp/base*100:0)+'%';}
anim(pv[0],x0);anim(pv[1],x1);anim(pv[2],x2);
pv[2].style.color=xc;bi[0].style.width=w0;bi[1].style.width=w1;
}
function applyCard(){
var p=window.upmoPeriod||null;var code=window._upmoFocus||null;var o=code?(dm[code]||null):null;
if(!p){setCard(o,code,code===null);return;}
if(p.t){setCardMonth('Неделя · вт '+p.t.slice(8)+'.'+p.t.slice(5,7)+'.'+p.t.slice(0,4)+(code?' · '+code:''),'—','—','—','—');setProgPct(null,null);return;}
window.upmoScData(ty,code).then(function(sc){
var fm=(typeof fmtMoney==='function')?fmtMoney:function(x){return String(x);};
var key=p.y+'-'+(p.m<10?'0':'')+p.m;
var i=(sc.labels||[]).indexOf(key);
var tt=MNF[p.m-1]+' '+p.y+(code?' · '+code:'');
var pl=(i>=0)?(sc.planAmt[i]||0):null;
var f=(i>=0&&sc.factAmt[i]!=null)?sc.factAmt[i]:null;
var bb=(pl===null)?'—':String(fm(pl));
var v1=(f===null)?'—':String(fm(f));
var v2=(pl===null||f===null)?'—':String(fm(pl-f));
setCardMonth(tt,bb,bb,v1,v2);
setSide(o,code===null);
window.upmoSumData(ty,code,o).then(function(su){var tot=su.totalCost||0;var pp=(tot&&pl!==null)?pl/tot*100:null;var fp=(tot&&f!==null)?f/tot*100:null;setProgPct(pp,fp);});
});
}
function redraw(code,o){var sc=document.getElementById('upmoSc'),mo=document.getElementById('upmoMo');if(!sc||!mo){return;}[sc,mo].forEach(function(x){x.style.transition='opacity .25s';x.style.opacity='0';});setTimeout(function(){if(window.upmoScurve){window.upmoScurve(sc,ty,code,o);}if(window.upmoMonths){window.upmoMonths(mo,ty,code);}setTimeout(function(){sc.style.opacity='1';mo.style.opacity='1';},80);},260);}
function anim(node,txt){
var tk=(node._tk=(node._tk||0)+1);
var cur=node.textContent;
node.style.minHeight=node.offsetHeight+'px';
var se=Math.max(6,Math.min(30,500/Math.max(1,cur.length)));
var sw=Math.max(6,Math.min(30,500/Math.max(1,txt.length)));
function erase(){
if(node._tk!==tk){return;}
if(cur.length>0){cur=cur.slice(0,-1);node.textContent=cur;setTimeout(erase,se);}else{write(1);}
}
function write(k){
if(node._tk!==tk){return;}
node.textContent=txt.slice(txt.length-k);
if(k<txt.length){setTimeout(function(){write(k+1);},sw);}else{node.style.minHeight='';}
}
if(cur.length===0&&txt.length===0){return;}
erase();
}
function setSide(o,reset){
var d=document.getElementById('upmoBlk4b1'),p=document.getElementById('upmoBlk4b2');
var ok=o&&(o.cost||0)>0;
if(d&&d.children.length>=3){
var dv=[d.children[0].children[1],d.children[2].children[1]];
if(!d._o){d._o=[dv[0].textContent,dv[1].textContent];}
var a0,a1;
if(reset){a0=d._o[0];a1=d._o[1];}else{a0=ok?fd(o.start):'—';a1=ok?fd(o.end||o.planEnd):'—';}
anim(dv[0],a0);anim(dv[1],a1);
}
if(p&&p.children.length>=2){
var cs=p.children[0].children;
var pv=[cs[0].children[1],cs[1].children[1],cs[2].children[1]];
var bars=p.children[1].children;
var bi=[bars[0].firstChild,bars[1].firstChild];
if(!p._o){p._o=[pv[0].textContent,pv[1].textContent,pv[2].textContent,pv[2].style.color,bi[0].style.width,bi[1].style.width];}
var x0,x1,x2,xc,w0,w1;
if(reset){x0=p._o[0];x1=p._o[1];x2=p._o[2];xc=p._o[3];w0=p._o[4];w1=p._o[5];}
else if(!ok){x0='—';x1='—';x2='—';xc='#9ca3af';w0='0%';w1='0%';}
else{var pl=Math.round(o.planPct||0);var f=Math.round((o.done||0)/o.cost*100);var df=f-pl;x0=pl+'%';x1=f+'%';x2=(df>0?'+':'')+df+'%';xc=df<0?'#e53e3e':'#38a169';w0=Math.min(100,pl)+'%';w1=Math.min(100,f)+'%';}
anim(pv[0],x0);anim(pv[1],x1);anim(pv[2],x2);
pv[2].style.color=xc;bi[0].style.width=w0;bi[1].style.width=w1;
}
}
function setCard(o,code,reset){
var cd=document.getElementById('upmoCard');if(cd===null||cd.children.length<3){return;}
var t=cd.children[0],bg=cd.children[1],g=cd.children[2];
var vs=[g.children[0].children[1],g.children[1].children[1],g.children[2].children[1]];
if(!cd._o){cd._o=[t.textContent,bg.textContent,vs[0].textContent,vs[1].textContent,vs[2].textContent];}
var tt,bb,v0,v1,v2;
if(reset){tt=cd._o[0];bb=cd._o[1];v0=cd._o[2];v1=cd._o[3];v2=cd._o[4];}
else{
var fm=(typeof fmtMoney==='function')?fmtMoney:function(x){return String(x);};
var ok=o&&(o.cost||0)>0;
tt=(names[code]||code);
if(!ok){bb='—';v0='—';v1='—';v2='—';}
else{var pl=Math.round(o.cost*(o.planPct||0)/100);bb=String(fm(o.cost));v0=String(fm(pl));v1=String(fm(o.done||0));v2=String(fm(o.cost-(o.done||0)));}
}
anim(t,tt);anim(bg,bb);anim(vs[0],v0);anim(vs[1],v1);anim(vs[2],v2);setSide(o,reset);
}
if(window._upmoPerL){window.removeEventListener('upmo-period',window._upmoPerL);}window._upmoPerL=function(){applyCard();};window.addEventListener('upmo-period',window._upmoPerL);
el.onclick=function(e){
var ob=e.target.closest('.upO');if(ob!==null){var oc=ob.getAttribute('data-oc');var was=(window._upmoFocus===oc);window._upmoFocus=was?null:oc;applyCard();redraw(was?null:oc,was?null:(dm[oc]||null));el.querySelectorAll('.upO').forEach(function(x){x.style.background='';});if(was){if(window.dsMapAll){window.dsMapAll();}}else{ob.style.background='#eaf3fb';if(window.dsMapFocus){window.dsMapFocus(oc);}}return;}
var r=e.target.closest('.upP');if(r===null){return;}
var k=el.querySelector('[data-kids="'+r.getAttribute('data-pk')+'"]');if(k===null){return;}
var op=k.getAttribute('data-o')==='1';
k.style.maxHeight=op?'0px':k.scrollHeight+'px';k.setAttribute('data-o',op?'0':'1');
var ar=r.querySelector('.ar');if(ar){ar.innerHTML=op?'&#9656;':'&#9662;';}
};
}).catch(function(){el.innerHTML='<div style="font-size:11px;color:#6b7280;">Не удалось загрузить</div>';});
};
})();
