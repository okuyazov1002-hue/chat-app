window.upmoScurve=function(el,ty,code,obj){
if(el===null){return;}
var msg=function(t){el.innerHTML='<div style="padding:14px;color:#6b7280;font-size:11px;">'+t+'</div>';};
msg('Загрузка...');
Promise.all([window.upmoScData(ty,code),window.upmoSumData(ty,code,obj)]).then(function(a){
var sc=a[0],su=a[1];
var n=sc.labels?sc.labels.length:0;
if(n<2){msg('Нет данных');return;}
var pc=[],fc=[],sp=0,sf=0,last=-1;
for(var i=0;i<n;i++){sp+=(sc.planAmt&&sc.planAmt[i])||0;pc.push(sp);if(sc.factAmt&&sc.factAmt[i]!=null){sf+=sc.factAmt[i];fc.push(sf);last=i;}else{fc.push(null);}}
var total=su.totalCost||sp;
var top=Math.max(total,sp,last>=0?fc[last]:0);
if(top<=0){msg('Нет данных');return;}
function cm(v){var b=Math.abs(v);if(b>=1e9){return (v/1e9).toFixed(1)+' млрд';}if(b>=1e6){return Math.round(v/1e6)+' млн';}if(b>=1e3){return Math.round(v/1e3)+' тыс';}return String(Math.round(v));}
var step=Math.max(22,Math.floor(((el.clientWidth||0)-24)/n));
var W=n*step,H=Math.max(200,Math.min(450,window.innerHeight-618)),pt=28,pb=28;
function X(i){return i*step+step/2;}
function Y(v){v=Math.min(top,Math.max(0,v));return pt+(1-v/top)*(H-pt-pb);}
function sm(q){var d='M'+q[0][0].toFixed(1)+' '+q[0][1].toFixed(1);for(var j=1;j<q.length;j++){var m2=(q[j-1][0]+q[j][0])/2;d+=' C'+m2.toFixed(1)+' '+q[j-1][1].toFixed(1)+' '+m2.toFixed(1)+' '+q[j][1].toFixed(1)+' '+q[j][0].toFixed(1)+' '+q[j][1].toFixed(1);}return d;}
var s='<svg width="'+W+'" height="'+H+'" viewBox="0 0 '+W+' '+H+'" style="display:block;">';
[0,0.25,0.5,0.75,1].forEach(function(g){var y=Y(top*g);s+='<line x1="0" x2="'+W+'" y1="'+y+'" y2="'+y+'" stroke="rgba(0,0,0,0.08)" stroke-width="1"/>';});
for(var i2=0;i2<n;i2++){var k=String(sc.labels[i2]);var mm2=k.slice(5);s+='<text x="'+X(i2)+'" y="'+(H-14)+'" text-anchor="middle" font-size="9" fill="#6b7280">'+mm2+'</text>';if(i2===0||mm2==='01'){s+='<text x="'+X(i2)+'" y="'+(H-3)+'" text-anchor="middle" font-size="9" fill="#9ca3af">'+k.slice(0,4)+'</text>';}}
var pp=[];for(var i3=0;i3<n;i3++){pp.push([X(i3),Y(pc[i3])]);}
s+='<path d="'+sm(pp)+'" fill="none" stroke="#2563eb" stroke-width="2" stroke-linecap="round"/>';
if(last>=1){var fp=[];for(var i4=0;i4<=last;i4++){fp.push([X(i4),Y(fc[i4])]);}
s+='<path d="'+sm(fp)+' L'+X(last).toFixed(1)+' '+Y(0)+' L'+X(0).toFixed(1)+' '+Y(0)+' Z" fill="rgba(19,138,98,0.15)" stroke="none"/>';
s+='<path d="'+sm(fp)+'" fill="none" stroke="#138a62" stroke-width="3" stroke-linecap="round"/>';}
if(last>=0){var pv=pc[last],fv=fc[last],cx=X(last),tx=Math.max(50,Math.min(W-50,cx)),pa=(pv>=fv);
s+='<line x1="'+cx+'" x2="'+cx+'" y1="'+Y(pv)+'" y2="'+Y(fv)+'" stroke="#f87171" stroke-width="2" stroke-dasharray="4 3" stroke-linecap="round"/>';
s+='<text x="'+(cx-8)+'" y="'+((Y(pv)+Y(fv))/2+3)+'" text-anchor="end" font-size="10" font-weight="700" fill="#ef4444" stroke="#fff" stroke-width="3" paint-order="stroke">'+(pv>=fv?'−':'+')+cm(Math.abs(pv-fv))+' ('+Math.round(Math.abs(pv-fv)/total*100)+'%)</text>';
s+='<circle cx="'+cx+'" cy="'+Y(pv)+'" r="4" fill="#2563eb" stroke="#fff" stroke-width="1.5"/><circle cx="'+cx+'" cy="'+Y(fv)+'" r="4" fill="#138a62" stroke="#fff" stroke-width="1.5"/>';
s+='<text x="'+tx+'" y="'+(Y(pv)+(pa?-9:15))+'" text-anchor="middle" font-size="10" font-weight="700" fill="#2563eb">'+cm(pv)+' ('+Math.round(pv/total*100)+'%)</text>';
s+='<text x="'+tx+'" y="'+(Y(fv)+(pa?15:-9))+'" text-anchor="middle" font-size="10" font-weight="700" fill="#138a62">'+cm(fv)+' ('+Math.round(fv/total*100)+'%)</text>';}
s+='</svg>';
el.innerHTML='<div id="upmoScS" style="padding:0 12px 12px;overflow-x:auto;scrollbar-width:none;cursor:grab;">'+s+'</div>';if(window.upmoLink){window.upmoLink();}
}).catch(function(){msg('Не удалось загрузить');});
};
