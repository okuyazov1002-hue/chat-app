(function(){
window.upmoProjPage=function(B,k,ttl){
var lab='font-size:11px;color:#4b5563;font-weight:600;';
var val='font-size:12px;white-space:nowrap;color:#1f2937;font-weight:700;';
var bx='border-radius:14px;padding:8px 6px;box-shadow:0 2px 8px rgba(0,0,0,0.12);';
function cell(t,f){return '<div style="margin-bottom:4px;"><div style="'+lab+'">'+t+'</div><div data-f="'+f+'" style="'+val+'">—</div></div>';}
B.innerHTML='<div style="padding:16px;"><div style="font-size:15px;font-weight:700;color:#1f2937;margin-bottom:16px;">'+ttl+'</div><div style="display:flex;gap:16px;align-items:stretch;"><div id="upmoPCard" style="position:relative;z-index:20;width:315px;box-sizing:border-box;box-shadow:-5px -5px 16px rgba(106,90,224,0.45),5px 5px 16px rgba(29,211,176,0.45),0 0 18px rgba(74,144,217,0.4);border-radius:16px;padding:14px 12px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);color:#fff;font-size:11px;"><div style="font-size:11px;color:rgba(255,255,255,0.85);font-weight:700;">Общая стоимость</div><div data-f="tc" style="font-size:18px;color:#fff;font-weight:700;margin-top:2px;">—</div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:10px;"><div style="'+bx+'background:rgba(255,255,255,0.5);">'+cell('План','pl')+cell('Остаток','rp')+'</div><div style="'+bx+'background:rgba(255,255,255,0.5);">'+cell('Выполнено','dn')+cell('Остаток','rd')+'</div><div style="'+bx+'background:rgba(255,255,255,0.5);">'+cell('Оплачено','pd')+cell('Остаток','rm')+'</div></div></div><div id="upmoPSt" style="display:flex;gap:0;align-items:stretch;flex:1;min-width:0;margin-left:-30px;"></div></div></div>';
fetch('/api/proj/summary?code='+encodeURIComponent(k.slice(5))).then(function(r){return r.json();}).then(function(d){
var fm=(typeof fmtMoney==='function')?fmtMoney:function(x){return String(x);};
var q=B.querySelector('#upmoPCard');if(!q){return;}
function sv(f,v){var e=q.querySelector('[data-f="'+f+'"]');if(e){e.textContent=fm(Math.round(v||0));}}
sv('tc',d.totalCost);sv('pl',d.plan);sv('rp',Math.max(0,(d.totalCost||0)-(d.plan||0)));sv('dn',d.done);sv('rd',Math.max(0,(d.totalCost||0)-(d.done||0)));sv('pd',d.paid);sv('rm',d.remaining);
}).catch(function(){});
(function(){var box=B.querySelector('#upmoPSt');if(!box){return;}
var ORD=['Базовое проектирование','Детальное проектирование','Изготовление','Логистика','Строительство','ПНР'];
box.innerHTML=ORD.map(function(n,i){return '<div style="box-sizing:border-box;flex:1 1 0;min-width:0;background:#fff;border-radius:0 14px 14px 0;padding:10px 12px 10px 42px;position:relative;z-index:'+(10-i)+';'+(i>0?'margin-left:-30px;':'')+'box-shadow:0 2px 14px rgba(0,0,0,0.2);"><div style="font-size:10px;font-weight:700;color:#1f2937;">'+n+'</div><div data-st="'+n+'" style="font-size:12px;font-weight:700;color:#1f2937;margin-top:6px;white-space:nowrap;">—</div></div>';}).join('');
fetch("/api/reports/"+encodeURIComponent(k.slice(5))+"/summary").then(function(r){return r.json();}).then(function(d){
var fm=(typeof fmtMoney==='function')?fmtMoney:function(x){return String(x);};
ORD.forEach(function(n){var f=null;(d.stages||[]).forEach(function(x){if(x.name===n||(n==='Строительство'&&/строительств|смр/i.test(x.name))||(n==='ПНР'&&/пнр|пуско/i.test(x.name))){f=x;}});
var e=box.querySelector('[data-st="'+n+'"]');if(e){var c=Math.round(f?(f.cost||0):0),dn=Math.round(f?(f.done||0):0),pd=Math.round(f?(f.paid||0):0),pl=Math.round(c*(f?(f.planPct||0):0)/100);
function mn(l,v,bg){var L='font-size:9px;color:#6b7280;font-weight:600;',V='font-size:10px;color:#1f2937;font-weight:700;';return '<div style="background:'+bg+';border-radius:10px;padding:5px 6px;min-width:0;"><div style="'+L+'">'+l+'</div><div style="'+V+'">'+fm(v)+'</div><div style="'+L+'margin-top:3px;">Остаток</div><div style="'+V+'">'+fm(Math.max(0,c-v))+'</div></div>';}
e.innerHTML=fm(c)+'<div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:5px;">'+mn('Выполнено',dn,'rgba(74,144,217,0.2)')+mn('Оплачено',pd,'rgba(29,211,176,0.22)')+'</div>';
var pp=Math.round(f?(f.planPct||0):0),fp=c?Math.min(100,Math.round(dn/c*100)):0,dl=fp-pp;
e.innerHTML+='<div style="display:flex;justify-content:space-between;font-size:10px;font-weight:700;margin-top:10px;"><span style="color:#4a90d9;">'+pp+'%</span><span style="color:'+(dl<0?'#d9776f':'#3aa88a')+';">'+(dl>0?'+':'')+dl+'%</span><span style="color:#2f855a;">'+fp+'%</span></div><div style="height:6px;border-radius:3px;background:#eef0f4;display:flex;overflow:hidden;margin-top:3px;"><div style="width:'+fp+'%;background:#1dd3b0;"></div><div style="width:'+Math.max(0,pp-fp)+'%;background:#4a90d9;"></div></div>';}});
}).catch(function(){});})();
};
var ov=null,A=null,B=null,busy=false;
var st=document.createElement('style');
st.textContent='.upm-win{position:fixed;z-index:2000;top:16px;bottom:16px;background:#fff;border-radius:0 20px 20px 0;box-sizing:border-box;border:1px solid rgba(0,0,0,0.06);clip-path:inset(0 100% 0 0);transition:clip-path .45s cubic-bezier(.22,1,.36,1);overflow:auto;}.upm-win.on{clip-path:inset(0 0 0 0);}#upmoA{left:104px;width:420px;padding:16px;z-index:2001;}#upmoB{left:104px;right:16px;bottom:auto;max-height:calc(100vh - 32px);}#upmoWin,#upmoWin *{-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent;outline:none;}';
document.head.appendChild(st);
function row(l,k,t,hk){return '<div class="ml-row" data-k="'+k+'" style="display:flex;align-items:center;padding:9px 10px 9px 12px;cursor:pointer;text-align:left;font-size:11px;'+(l?'color:#374151;':'font-weight:700;color:#1f2937;')+'"><span class="ar" style="width:12px;min-width:12px;flex-shrink:0;color:#6b7280;">'+(hk?'&#9662;':'')+'</span><span>'+t+'</span></div>';}
function sec(k,t,items){var inn='';items.forEach(function(it){inn+=row(1,it[0],it[1],false);});return '<div class="ml-card0" style="margin:0 0 6px 0;">'+row(0,k,t,true)+'<div data-kids="'+k+'" data-o="1" style="max-height:600px;overflow:hidden;transition:max-height .35s ease;">'+inn+'</div></div>';}
function listHtml(){
var pi=[['act:all','Общая информация'],['act:int','Внутренний'],['act:ext','Внешний']];
var mi=[],ai=[];
try{mi=PROJECTS.main.items.map(function(it){return ['proj:'+it.code,it.code+' '+it.name];});ai=PROJECTS.aux.items.map(function(it){return ['proj:'+it.code,it.code+' '+it.name];});}catch(err){}
return sec('prep','Подготовительные работы',pi)+sec('main','Основные проекты',mi)+sec('aux','Вспомогательные проекты',ai);
}
function openAll(){
if(ov){return;}
if(Date.now()-(window._upmoLastClose||0)<560){return;}
var _t0=tw;closeTeam();if(_t0){_t0.style.display='none';}ov=document.createElement('div');ov.id='upmoWin';
A=document.createElement('div');A.id='upmoA';A.className='upm-win';A.innerHTML=listHtml();
B=document.createElement('div');B.id='upmoB';B.className='upm-win';
ov.appendChild(A);ov.appendChild(B);document.body.appendChild(ov);
var pv=document.querySelector('.buttons button.nav-active');window._upmoPrev=(pv&&pv.id!=='upmoBtn')?pv:null;document.querySelectorAll('.buttons button').forEach(function(x){x.classList.remove('nav-active');});var b=document.getElementById('upmoBtn');if(b){b.classList.add('nav-active');}
A.addEventListener('click',function(e){
var r=e.target.closest('.ml-row');if(r===null){return;}
var k=r.getAttribute('data-k');
var kids=A.querySelector('[data-kids="'+k+'"]');
if(kids){var op=kids.getAttribute('data-o')==='1';kids.style.maxHeight=op?'0px':kids.scrollHeight+'px';kids.setAttribute('data-o',op?'0':'1');r.querySelector('.ar').innerHTML=op?'&#9656;':'&#9662;';return;}
if(k.indexOf('act:')===0||k.indexOf('proj:')===0){pick(k);}
});
void A.offsetWidth;
setTimeout(function(){if(A){A.classList.add('on');}},20);
}
function closeAll(){
if(ov===null){return;}
window._upmoLastClose=Date.now();
var o=ov,a=A,b=B;ov=null;A=null;B=null;busy=false;
a.classList.remove('on');b.classList.remove('on');
var bt=document.getElementById('upmoBtn');if(bt){bt.classList.remove('nav-active');}if(window._upmoPrev){window._upmoPrev.classList.add('nav-active');window._upmoPrev=null;}
setTimeout(function(){o.remove();if(ov===null&&window.upmoMapRestore){window.upmoMapRestore();}},520);
}
function pick(k){
if(busy){return;}busy=true;
var ttl='';try{ttl=A.querySelector('[data-k="'+k+'"] span:last-child').textContent;}catch(e){}
A.classList.remove('on');B.classList.remove('on');
setTimeout(function(){
if(B===null){busy=false;return;}
if(k.indexOf('proj:')===0){B.style.bottom='16px';window.upmoProjPage(B,k,ttl);}else if(window.upmoFillPanel){B.style.bottom='';window.upmoFillPanel(B,k);}
B.classList.add('on');busy=false;
},480);
}
function teamBdHtml(){
var cards='';
try{
var today=new Date();today.setHours(0,0,0,0);
var arr=PERSONNEL.filter(function(u){return u.birthday;}).map(function(u){var p=u.birthday.split('.');if(p.length!==3){return null;}var d=parseInt(p[0],10),m=parseInt(p[1],10)-1;var n=new Date(today.getFullYear(),m,d);if(n<today){n=new Date(today.getFullYear()+1,m,d);}return {name:u.name,bd:u.birthday,days:Math.round((n-today)/86400000),avatar:u.avatar||''};}).filter(Boolean);
arr.sort(function(a,b){return a.days-b.days;});
cards=arr.slice(0,3).map(function(u){var av=u.avatar?'<img src="'+u.avatar+'">':'<span>'+u.name.charAt(0)+'</span>';return '<div class="bday-card" style="width:auto;margin-left:36px;padding:0 12px 0 36px;height:36px;"><div class="bday-card-avatar" style="width:40px;height:40px;font-size:16px;">'+av+'</div><div class="bday-card-info" style="display:flex;align-items:center;gap:10px;"><div class="bday-card-name" style="margin-bottom:0;flex:1;">'+u.name+'</div><div class="bday-card-date" style="white-space:nowrap;width:68px;text-align:left;flex:0 0 68px;">'+u.bd+'</div><div class="bday-card-days" style="margin-top:0;white-space:nowrap;width:78px;text-align:left;flex:0 0 78px;">'+fmtDaysUntil(u.days)+'</div></div></div>';}).join('');
}catch(e){}
return '<div id="teamBd" style="position:relative;padding:14px 16px 16px 0;background:linear-gradient(135deg,#6A5BD6 0%,#5B94D0 60%,#5FD2B0 100%);box-sizing:border-box;"><div style="margin:0 0 0 16px;font-size:10px;font-weight:700;color:#fff;">День рождения</div><div id="teamBdBody" style="overflow:hidden;transition:max-height .4s cubic-bezier(.22,1,.36,1);"><div style="display:flex;flex-direction:column;gap:10px;padding-top:10px;">'+cards+'</div></div><div id="teamBdHandle" title="Свернуть / развернуть" onclick="var b=document.getElementById(\'teamBdBody\');var o=b.getAttribute(\'data-o\')!==\'0\';b.style.maxHeight=b.scrollHeight+\'px\';void b.offsetHeight;b.style.maxHeight=o?\'0px\':b.scrollHeight+\'px\';b.setAttribute(\'data-o\',o?\'0\':\'1\');this.firstChild.style.transform=o?\'rotate(180deg)\':\'none\';" style="position:absolute;left:50%;bottom:-8px;transform:translateX(-50%);width:48px;height:16px;border-radius:12px;z-index:2;background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 3px 8px rgba(0,0,0,0.15);"><svg width="12" height="12" viewBox="0 0 12 12" style="transition:transform .3s;transform:rotate(0deg);"><path d="M2 7 L6 3 L10 7" fill="none" stroke="#5B94D0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></div></div>';
}
function teamListHtml(){
var out='';
try{
function rk(u){var pos=String(u.position||'').toLowerCase().trim();var dep=String(u.department||'').toLowerCase();
if(pos.indexOf('заместитель директора')>=0&&pos.indexOf('управлению проектами')>=0){return 2;}
if(pos.indexOf('директор')===0&&pos.indexOf('заместитель')<0){return 1;}
if(pos==='главный инженер'||pos.indexOf('главный инженер дсомк')>=0){return 3;}
if(dep.indexOf('технологический')>=0&&pos.indexOf('начальник отдела')>=0){return 4;}
return 99;}
function det(u){function L(t,v){return v?'<div style="display:flex;justify-content:flex-start;gap:12px;padding:3px 0;"><span style="color:#8a94a6;width:96px;flex:0 0 96px;text-align:right;">'+t+'</span><span style="color:#1f2937;font-weight:600;word-break:break-word;text-align:left;">'+v+'</span></div>':'';}
return '<div style="position:relative;z-index:1;max-height:0;overflow:hidden;opacity:0;margin:0 0 0 36px;background:#fff;border-radius:0 0 10px 10px;padding:0 14px;transition:max-height .35s ease,opacity .3s ease,margin .35s ease,padding .35s ease;font-size:11px;box-shadow:0 4px 10px rgba(0,0,0,0.1);">'+L('Отдел',u.department)+L('Должность',u.position)+L('День рождения',u.birthday)+L('Внутр. телефон',u.internalPhone)+L('Моб. телефон',u.mobilePhone)+L('Email',u.email)+'</div>';}
var us=PERSONNEL.map(function(u,i){return {u:u,i:i,r:rk(u)};}).sort(function(a,b){return a.r-b.r||a.i-b.i;}).map(function(x){return x.u;});
out=us.map(function(u){var av=u.avatar?'<img src="'+u.avatar+'" style="width:100%;height:100%;object-fit:cover;">':'<span>'+(u.name?u.name.charAt(0):'?')+'</span>';
return '<div data-s="'+String([u.name,u.position,u.department].join(' ')).toLowerCase().replace(/"/g,'')+'" style="flex:0 0 auto;"><div onclick="var d=this.nextSibling,o=d.style.maxHeight&&d.style.maxHeight!==\'0px\';d.style.maxHeight=o?\'0px\':(d.scrollHeight+30)+\'px\';d.style.opacity=o?0:1;d.style.marginTop=o?\'0\':\'4px\';d.style.padding=o?\'0 14px\':\'14px 14px 10px\';" style="cursor:pointer;position:relative;z-index:2;display:flex;align-items:center;background:#fff;border-radius:10px;height:44px;margin-left:36px;padding:0 12px 0 36px;box-shadow:0 2px 8px rgba(0,0,0,0.12);box-sizing:border-box;flex:0 0 auto;"><div style="position:absolute;left:-20px;top:50%;transform:translateY(-50%);width:44px;height:44px;border-radius:50%;overflow:hidden;background:#4a9fd8;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;box-sizing:border-box;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.15);">'+av+'</div><div style="font-size:12px;font-weight:700;color:#1f2937;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">'+u.name+'</div></div>'+det(u)+'</div>';}).join('');
}catch(e){}
return '<div style="padding:22px 16px 16px 0;display:flex;flex-direction:column;gap:10px;">'+out+'</div>';
}
(function(){var st=document.createElement('style');st.textContent='#teamWin{scrollbar-width:none;-ms-overflow-style:none;}#teamWin::-webkit-scrollbar{display:none;width:0;height:0;}';document.head.appendChild(st);})();var tw=null;
var STRUCT_DEFS='<svg width="0" height="0" style="position:absolute"><defs><linearGradient id="impTray" gradientUnits="userSpaceOnUse" x1="18" y1="0" x2="102" y2="0"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient><linearGradient id="impArrow" gradientUnits="userSpaceOnUse" x1="0" y1="18" x2="0" y2="72"><stop offset="0" stop-color="#6A5BD6"/><stop offset="1" stop-color="#5B94D0"/></linearGradient><linearGradient id="expArrow" gradientUnits="userSpaceOnUse" x1="0" y1="20" x2="0" y2="72"><stop offset="0" stop-color="#5FD2B0"/><stop offset="1" stop-color="#5B94D0"/></linearGradient></defs></svg>';
function structBtns(code){
var tray='<path d="M20 72 V92 Q20 100 28 100 H92 Q100 100 100 92 V72" fill="none" stroke="url(#impTray)" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>';
var imp='<svg width="20" height="20" viewBox="0 0 120 120">'+tray+'<path d="M60 18 V70 M44 54 L60 70 L76 54" fill="none" stroke="url(#impArrow)" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/></svg>';
var exp='<svg width="20" height="20" viewBox="0 0 120 120">'+tray+'<path d="M60 72 V20 M44 36 L60 20 L76 36" fill="none" stroke="url(#expArrow)" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/></svg>';
return '<span style="margin-left:auto;display:flex;gap:10px;align-items:center;padding-left:10px;"><span data-upd="'+code+'" style="font-size:10px;color:#8a94a6;white-space:nowrap;margin-right:4px;"></span><span class="sx-btn" data-act="import" data-code="'+code+'" title="Импорт" style="display:flex;cursor:pointer;">'+imp+'</span><span class="sx-btn" data-act="export" data-code="'+code+'" title="Экспорт" style="display:flex;cursor:pointer;">'+exp+'</span></span>';
}
function structRow(pad,t,hk,k,bold,open,ex){return '<div class="sx-row" data-sk="'+k+'" style="display:flex;align-items:center;padding:9px 10px 9px '+pad+'px;cursor:pointer;text-align:left;font-size:11px;'+(bold?'font-weight:700;color:#1f2937;':'color:#374151;')+'"><span style="width:12px;min-width:12px;flex-shrink:0;color:#6b7280;transition:transform .3s;'+((hk&&!open)?'transform:rotate(-90deg);':'')+'">'+(hk?'&#9662;':'')+'</span><span>'+t+'</span>'+(ex||'')+'</div>';}
function structKids(k,inner,open){return '<div data-sk-kids="'+k+'" style="overflow:hidden;transition:max-height .35s ease;max-height:'+(open?'5000px':'0')+';">'+inner+'</div>';}
function structListHtml(){
var nm={};try{PROJECTS.main.items.concat(PROJECTS.aux.items).forEach(function(it){nm[it.code]=it.name;});}catch(e){}
var g={},ord=[];try{PROJECTS.prep.items.forEach(function(it){var pc=it.code.split('-')[0];if(g[pc]==null){g[pc]=[];ord.push(pc);}g[pc].push(it);});}catch(e){}
var inner='';
ord.forEach(function(pc){var sub='';g[pc].forEach(function(it){sub+=structRow(12,it.code+' '+it.name,false,'o:'+it.code,false,true,structBtns(it.code));});inner+='<div style="background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.12);margin:4px 10px 10px 10px;">'+structRow(12,(pc+' '+(nm[pc]||'')).trim(),true,'p:'+pc,false,false)+structKids('p:'+pc,sub,false)+'</div>';});
var h='<div class="ml-card0" style="margin:0 0 6px 0;">'+structRow(12,'Подготовительные работы',true,'prep',true,true)+structKids('prep',inner,true)+'</div>';
[['main','Основные проекты'],['aux','Вспомогательные проекты']].forEach(function(x){var it2='';try{PROJECTS[x[0]].items.forEach(function(it){it2+=structRow(14,it.code+' '+it.name,false,'q:'+it.code,false,true);});}catch(e){}h+='<div class="ml-card0" style="margin:0 0 6px 0;">'+structRow(12,x[1],true,x[0],true,true)+structKids(x[0],it2,true)+'</div>';});
return h;
}
window._structCache=window._structCache||null;
function structPaint(w,l){l.forEach(function(x){var e=w.querySelector('[data-upd="'+x.code+'"]');if(!e){return;}if(!x.updatedAt){e.textContent='';return;}var d=new Date(x.updatedAt);if(isNaN(d)){return;}var p2=function(n){return (n<10?'0':'')+n;};e.textContent=(x.updatedBy||'')+' · '+p2(d.getDate())+'.'+p2(d.getMonth()+1)+'.'+d.getFullYear()+' '+p2(d.getHours())+':'+p2(d.getMinutes());});}
function structUpd(w,force){
if(window._structCache&&!force){structPaint(w,window._structCache);return;}
var codes=[];try{PROJECTS.prep.items.forEach(function(it){codes.push(it.code);});}catch(e){}
if(!codes.length){return;}
fetch('/api/reports/list?codes='+encodeURIComponent(codes.join(','))).then(function(r){return r.json();}).then(function(l){
if(!Array.isArray(l)){return;}
window._structCache=l;structPaint(w,l);return;
l.forEach(function(x){var e=w.querySelector('[data-upd="'+x.code+'"]');if(!e){return;}
if(!x.updatedAt){e.textContent='';return;}
var d=new Date(x.updatedAt);if(isNaN(d)){return;}
var p2=function(n){return (n<10?'0':'')+n;};
e.textContent=(x.updatedBy||'')+' · '+p2(d.getDate())+'.'+p2(d.getMonth()+1)+'.'+d.getFullYear()+' '+p2(d.getHours())+':'+p2(d.getMinutes());
});
}).catch(function(){});
}
function structCodes(){var a=[];try{PROJECTS.prep.items.forEach(function(it){a.push(it.code);});['main','aux'].forEach(function(k){PROJECTS[k].items.forEach(function(it){a.push(it.code);});});}catch(e){}return a;}
function structDropFiles(files){
var list=Array.prototype.slice.call(files).filter(function(f){return /\.xlsx$/i.test(f.name);});
if(!list.length){alert('Нужны файлы .xlsx');return;}
var codes=structCodes(),ok=[],bad=[];
list.forEach(function(f){var c=f.name.replace(/\.xlsx$/i,'').replace(/\s*\(\d+\)$/,'').trim();(codes.indexOf(c)>=0?ok:bad).push({f:f,c:c});});
if(bad.length){alert('Проект не найден по имени файла: '+bad.map(function(x){return x.f.name;}).join(', ')+'\nИмя файла должно быть кодом проекта, например CSM01-SA.xlsx');}
if(!ok.length){return;}
if(!confirm('Загрузить: '+ok.map(function(x){return x.c;}).join(', ')+'?\nДанные запишутся по кодам внутри файлов и заменят текущие.')){return;}
var res=[];
function next(i){
if(i>=ok.length){window._structCache=null;if(sw){structUpd(sw,true);}alert(res.join('\n'));return;}
var fd=new FormData();fd.append('file',ok[i].f);
fetch('/api/reports/import',{method:'POST',body:fd}).then(function(r){return r.json().catch(function(){return {};}).then(function(j){res.push(ok[i].c+': '+(r.ok?'загружено':('ошибка '+(j.message||r.status))));next(i+1);});}).catch(function(){res.push(ok[i].c+': нет связи');next(i+1);});
}
next(0);
}
function structDropClear(){Array.prototype.forEach.call(document.querySelectorAll('#structWin,#structureBtn'),function(x){x.style.outline='';});}
function structIsFiles(e){return e.dataTransfer&&Array.prototype.indexOf.call(e.dataTransfer.types||[],'Files')>=0;}
document.addEventListener('dragover',function(e){if(window.innerWidth<=768||!structIsFiles(e)){return;}var t=e.target.closest&&e.target.closest('#structWin,#structureBtn');if(!t){return;}e.preventDefault();e.dataTransfer.dropEffect='copy';t.style.outline='2px dashed #5B94D0';t.style.outlineOffset='-4px';},true);
document.addEventListener('dragleave',function(e){var rt=e.relatedTarget;if(!rt||!rt.closest||!rt.closest('#structWin,#structureBtn')){structDropClear();}},true);
document.addEventListener('drop',function(e){if(window.innerWidth<=768||!structIsFiles(e)){return;}var t=e.target.closest&&e.target.closest('#structWin,#structureBtn');if(!t){return;}e.preventDefault();e.stopPropagation();structDropClear();structDropFiles(e.dataTransfer.files);},true);
(function(){var st=document.createElement('style');st.textContent='@keyframes mapSlide{from{clip-path:inset(0 100% 0 0);}to{clip-path:inset(0 0 0 0);}}#page-map{z-index:0;}#page-map.mslide.active{animation:mapSlide .5s cubic-bezier(.22,1,.36,1) both;}';document.head.appendChild(st);})();
document.addEventListener('click',function(e){
if(window.innerWidth<=768||window._upmoMapInit){return;}
if(!e.target.closest('#mapBtn')){return;}
var pm=document.getElementById('page-map');if(!pm||pm.classList.contains('active')){return;}
pm.classList.remove('mslide');void pm.offsetWidth;pm.classList.add('mslide');
setTimeout(function(){pm.classList.remove('mslide');try{if(window.leafMap){window.leafMap.invalidateSize();}}catch(x){}},600);
},true);
(function(){var st=document.createElement('style');st.textContent='#mapBox{border-radius:20px;overflow:hidden;}.leaflet-control-attribution{display:none!important;}';document.head.appendChild(st);})();
(function(){var st=document.createElement('style');st.textContent='@keyframes mapOut{from{clip-path:inset(0 0 0 0);}to{clip-path:inset(0 100% 0 0);}}#page-map.mout.active{animation:mapOut .4s cubic-bezier(.22,1,.36,1) both;}';document.head.appendChild(st);})();
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
var b=e.target.closest('.buttons button');
if(!b||b.id==='mapBtn'||b.id==='aiNavBtn'||b.id==='logoutBtn'){return;}
var pm=document.getElementById('page-map');if(!pm||!pm.classList.contains('active')||pm.classList.contains('mout')){return;}
pm.classList.add('mout');
setTimeout(function(){window._teamPrev=null;window._upmoPrev=null;window._structPrev=null;var mb=document.getElementById('mapBtn');if(mb){mb.classList.remove('nav-active');}},30);
setTimeout(function(){pm.classList.remove('mout');pm.classList.remove('active');},420);
},true);
(function(){var st=document.createElement('style');st.textContent='#mapInfo{margin-right:12px!important;border-radius:0 20px 20px 0!important;box-shadow:none!important;}#page-map{background:#f6f7fb!important;}';document.head.appendChild(st);})();
document.addEventListener('click',function(e){
if(window.innerWidth<=768||window._upmoMapInit){return;}
if(!e.target.closest('#mapBtn')){return;}
if(sw!==null){var _s=sw;closeStruct(true);_s.style.display='none';}
if(tw!==null){var _t=tw;closeTeam();_t.style.display='none';}
if(ov!==null){var _o=ov;closeAll();_o.style.display='none';}
},true);
document.addEventListener('click',function(e){
if(window.innerWidth<=768||window._upmoMapInit){return;}
var t=e.target.closest('#mapBtn');if(!t){return;}
var pm=document.getElementById('page-map');
if(!pm||!pm.classList.contains('active')){return;}
e.stopPropagation();e.preventDefault();
var an=t.querySelectorAll('animateTransform');for(var i=0;i<an.length;i++){try{an[i].beginElement();}catch(x){}}
if(pm.classList.contains('mout')){return;}
pm.classList.add('mout');t.classList.remove('nav-active');
setTimeout(function(){pm.classList.remove('mout');pm.classList.remove('active');},420);
},true);
var iw=null;
function closeIdea(instant){
if(iw===null){return;}
var o=iw;iw=null;
if(instant){o.style.display='none';}
o.classList.remove('on');
var ib=document.getElementById('ideaBtn');if(ib){ib.classList.remove('nav-active');ib.classList.remove('lampOn');ib.classList.add('lampOff');}
if(window._ideaPrev){window._ideaPrev.classList.add('nav-active');window._ideaPrev=null;}
window._ideaLastClose=Date.now();
setTimeout(function(){o.remove();},520);
}
function openIdea(){
if(iw!==null){return;}
if(ov!==null){var _o=ov;closeAll();_o.style.display='none';}
if(tw!==null){var _t=tw;closeTeam();_t.style.display='none';}
if(sw!==null){var _s=sw;closeStruct(true);}
var pv=document.querySelector('.buttons button.nav-active');
window._ideaPrev=(pv&&pv.id!=='ideaBtn')?pv:null;
document.querySelectorAll('.buttons button').forEach(function(x){x.classList.remove('nav-active');});
var ib=document.getElementById('ideaBtn');if(ib){ib.classList.add('nav-active');ib.classList.remove('lampOff');ib.classList.add('lampOn');}
iw=document.createElement('div');iw.id='ideaWin';iw.className='upm-win';
iw.style.cssText='left:104px;width:420px;padding:0;z-index:2001;border:0;overflow:auto;';
iw.innerHTML='<div style="padding:16px;"><div style="font-size:15px;font-weight:700;color:#1f2937;margin-bottom:12px;">Предложения и рекомендации</div><div id="ideaDd" style="position:relative;margin-bottom:12px;"><div id="ideaDdBtn" style="height:36px;border-radius:12px;padding:0 14px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;font-size:12px;color:#1f2937;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,0.12);"><span id="ideaDdLbl">Рекомендация</span><span id="ideaDdAr" style="color:#6b7280;transition:transform .3s ease;">&#9662;</span></div><div id="ideaDdList" style="position:absolute;left:0;right:0;top:42px;z-index:10;overflow:hidden;max-height:0;opacity:0;border-radius:12px;background:#fff;box-shadow:0 6px 18px rgba(0,0,0,0.16);transition:max-height .35s cubic-bezier(.22,1,.36,1),opacity .25s ease;"><div class="ideaOpt" data-v="suggestion">Рекомендация</div><div class="ideaOpt" data-v="error">Ошибка</div></div><input type="hidden" id="ideaTy" value="suggestion"></div><textarea id="ideaTx" maxlength="2000" placeholder="Опишите..." style="width:100%;height:120px;box-sizing:border-box;border:1px solid #e5e7eb;border-radius:12px;padding:10px 12px;font-size:12px;outline:none;resize:none;font-family:inherit;"></textarea><div style="display:flex;align-items:center;gap:10px;margin-top:10px;"><button id="ideaSend" style="border:0;border-radius:16px;height:32px;padding:0 18px;color:#fff;font-size:12px;cursor:pointer;background:linear-gradient(135deg,#6A5BD6,#5B94D0 60%,#5FD2B0);">Отправить</button><span id="ideaMsg" style="font-size:11px;color:#6b7280;"></span></div><div style="font-size:12px;font-weight:700;color:#1f2937;margin:18px 0 8px;">Мои обращения</div><div id="ideaList"></div></div>';
document.body.appendChild(iw);
var ty=iw.querySelector('#ideaTy'),tx=iw.querySelector('#ideaTx'),sd=iw.querySelector('#ideaSend'),ms=iw.querySelector('#ideaMsg'),ls=iw.querySelector('#ideaList');
function esc(t){return String(t==null?'':t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
var STN={sent:['Отправлено','#5B94D0'],reviewed:['Рассмотрено','#d99a2b'],done:['Выполнено','#2f9e74']};
var editId=null;
function loadIdeas(){fetch('/api/ideas/my').then(function(r){return r.json();}).then(function(l){if(!Array.isArray(l)){return;}
ls.innerHTML=l.length?l.map(function(x){var st=STN[x.status]||STN.sent;var d=new Date(x.createdAt);var can=(x.status||'sent')==='sent';
return '<div class="ideaIt" data-id="'+x.id+'" data-ty="'+x.type+'" style="background:#fff;border-radius:12px;margin-bottom:8px;box-shadow:0 2px 8px rgba(0,0,0,0.12);overflow:hidden;"><div class="ideaHd" style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 12px;cursor:pointer;font-size:11px;"><span style="color:#1f2937;"><b>Заявка</b> <span style="color:#6b7280;">#'+esc(x.code)+'</span></span><span style="color:'+st[1]+';font-weight:700;">'+st[0]+'</span></div><div class="ideaBd" style="max-height:0;overflow:hidden;transition:max-height .35s ease;"><div style="padding:0 12px 12px;font-size:11px;color:#1f2937;"><div style="color:#8a94a6;margin-bottom:6px;">'+(x.type==='error'?'Ошибка':'Рекомендация')+(isNaN(d)?'':' · '+d.toLocaleString('ru-RU'))+'</div><div class="ideaTxt" style="white-space:pre-wrap;word-break:break-word;">'+esc(x.text)+'</div>'+(x.reply?'<div style="margin-top:8px;padding:8px 10px;background:#f6f7fb;border-radius:10px;"><b>Ответ'+(x.repliedBy?' · '+esc(x.repliedBy):'')+':</b> '+esc(x.reply)+'</div>':'')+(can?'<div style="display:flex;gap:8px;margin-top:10px;"><span class="ideaEd" style="cursor:pointer;color:#5B94D0;font-weight:700;">Редактировать</span><span class="ideaDel" style="cursor:pointer;color:#d9776f;font-weight:700;">Удалить</span></div>':'')+'</div></div></div>';}).join(''):'<div style="font-size:11px;color:#9ca3af;">Пока нет обращений</div>';}).catch(function(){});}
ls.addEventListener('click',function(e){var it=e.target.closest('.ideaIt');if(!it){return;}var id=it.getAttribute('data-id');
if(e.target.closest('.ideaDel')){if(!confirm('Удалить заявку?')){return;}fetch('/api/ideas/'+id,{method:'DELETE'}).then(function(r){return r.json().catch(function(){return {};}).then(function(j){if(!r.ok){alert(j.error||'Ошибка');}if(editId===id){editId=null;tx.value='';sd.textContent='Отправить';}loadIdeas();});});return;}
if(e.target.closest('.ideaEd')){editId=id;tx.value=it.querySelector('.ideaTxt').textContent;ty.value=it.getAttribute('data-ty');ddl.textContent=ty.value==='error'?'Ошибка':'Рекомендация';sd.textContent='Сохранить';ms.textContent='Редактирование заявки';tx.focus();return;}
if(e.target.closest('.ideaHd')){var bd=it.querySelector('.ideaBd');var o=bd.style.maxHeight&&bd.style.maxHeight!=='0px';bd.style.maxHeight=o?'0px':bd.scrollHeight+'px';}
});
loadIdeas();
(function(){var st=document.createElement('style');st.textContent='#ideaWin.chk>div>*:not(:first-child){visibility:hidden;}.ideaOpt{padding:10px 14px;font-size:12px;cursor:pointer;color:#374151;transition:background .2s;}.ideaOpt:hover{background:#eef2fb;}#ideaTx{border:0!important;box-shadow:0 2px 8px rgba(0,0,0,0.12);transition:box-shadow .25s;}#ideaTx:focus{box-shadow:0 0 0 2px rgba(91,148,208,.45),0 2px 8px rgba(0,0,0,0.1);}';document.head.appendChild(st);})();
var dd=iw.querySelector('#ideaDdList'),ddb=iw.querySelector('#ideaDdBtn'),ddl=iw.querySelector('#ideaDdLbl'),dda=iw.querySelector('#ideaDdAr'),ddo=false;
function ddSet(o){ddo=o;dd.style.maxHeight=o?'90px':'0';dd.style.opacity=o?'1':'0';dda.style.transform=o?'rotate(180deg)':'';}
ddb.onclick=function(e){e.stopPropagation();ddSet(!ddo);};
Array.prototype.forEach.call(dd.querySelectorAll('.ideaOpt'),function(o){o.onclick=function(e){e.stopPropagation();ty.value=o.getAttribute('data-v');ddl.textContent=o.textContent;ddSet(false);};});
iw.addEventListener('click',function(){if(ddo){ddSet(false);}});
var dv=document.createElement('div');dv.style.cssText='margin-top:18px;';ls.parentNode.appendChild(dv);
var devTab='new';
function showForm(){if(iw){iw.classList.remove('chk');}}
function loadDev(useCache){var _p=(useCache&&window._devCache)?Promise.resolve(window._devCache):fetch('/api/ideas/all').then(function(r){return r.ok?r.json():null;});_p.then(function(l){if(!iw){return;}if(!Array.isArray(l)){window._devCache=null;window._devNo=true;showForm();return;}window._devCache=l;showForm();
Array.prototype.forEach.call(iw.querySelectorAll('#ideaDd,#ideaTx'),function(e){e.style.display='none';});var _sd=iw.querySelector('#ideaSend');if(_sd&&_sd.parentNode){_sd.parentNode.style.display='none';}ls.style.display='none';if(ls.previousElementSibling){ls.previousElementSibling.style.display='none';}
var nw=l.filter(function(x){return x.status!=='done';}),dn=l.filter(function(x){return x.status==='done';});var shown=devTab==='done'?dn:nw;var tabs='<div style="display:flex;gap:8px;margin-bottom:12px;">'+[['new','Новые заявки',nw.length],['done','Выполнено',dn.length]].map(function(t){var on=devTab===t[0];return '<span class="devTab" data-t="'+t[0]+'" style="cursor:pointer;padding:7px 14px;border-radius:14px;font-size:12px;font-weight:700;'+(on?'color:#fff;background:linear-gradient(135deg,#6A5BD6,#5B94D0 60%,#5FD2B0);':'color:#374151;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,0.12);')+'">'+t[1]+' ('+t[2]+')</span>';}).join('')+'</div>';
dv.innerHTML=tabs+(shown.map(function(x){var st=STN[x.status]||STN.sent;var d=new Date(x.createdAt);
var btns=['sent','reviewed','done'].map(function(k){return '<span class="devSt" data-st="'+k+'" style="cursor:pointer;padding:4px 10px;border-radius:10px;font-size:10px;font-weight:700;color:#fff;background:'+STN[k][1]+';opacity:'+(k===x.status?'1':'.35')+';">'+STN[k][0]+'</span>';}).join(' ');
return '<div class="devIt" data-id="'+x.id+'" style="background:#fff;border-radius:12px;margin-bottom:8px;box-shadow:0 2px 8px rgba(0,0,0,0.12);overflow:hidden;"><div class="devHd" style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 12px;cursor:pointer;font-size:11px;"><span style="color:#1f2937;"><b>#'+esc(x.code)+'</b> <span style="color:#6b7280;">'+esc(x.name)+'</span></span><span class="devStl" style="color:'+st[1]+';font-weight:700;">'+st[0]+'</span></div><div class="devBd" style="max-height:0;overflow:hidden;transition:max-height .35s ease;"><div style="padding:0 12px 12px;font-size:11px;color:#1f2937;"><div style="color:#8a94a6;margin-bottom:6px;">'+(x.type==='error'?'Ошибка':'Рекомендация')+(isNaN(d)?'':' · '+d.toLocaleString('ru-RU'))+'</div><div style="white-space:pre-wrap;word-break:break-word;">'+esc(x.text)+'</div><div style="margin-top:10px;display:flex;gap:6px;">'+btns+'</div><textarea class="devRp" placeholder="Ответ пользователю..." style="width:100%;height:70px;box-sizing:border-box;margin-top:10px;border:0;border-radius:10px;padding:8px 10px;font-size:11px;outline:none;resize:none;font-family:inherit;box-shadow:0 2px 8px rgba(0,0,0,0.12);">'+esc(x.reply||'')+'</textarea><div style="display:flex;align-items:center;gap:10px;margin-top:8px;"><span class="devSave" style="cursor:pointer;color:#5B94D0;font-weight:700;">Сохранить ответ</span><span class="devMsg" style="color:#6b7280;"></span></div></div></div></div>';}).join('')||'<div style="font-size:11px;color:#9ca3af;">Заявок нет</div>');}).catch(function(){});}
dv.addEventListener('click',function(e){var tb=e.target.closest('.devTab');if(tb){devTab=tb.getAttribute('data-t');loadDev(true);return;}var it=e.target.closest('.devIt');if(!it){return;}var id=it.getAttribute('data-id');
var sb=e.target.closest('.devSt');
if(sb){var k=sb.getAttribute('data-st');fetch('/api/ideas/'+id+'/review',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:k})}).then(function(r){if(!r.ok){return;}(window._devCache||[]).forEach(function(q){if(q.id===id){q.status=k;}});Array.prototype.forEach.call(it.querySelectorAll('.devSt'),function(b){b.style.opacity=b.getAttribute('data-st')===k?'1':'.35';});var l=it.querySelector('.devStl');l.textContent=STN[k][0];l.style.color=STN[k][1];if(k==='done'||devTab==='done'){setTimeout(function(){loadDev(true);},400);}});return;}
if(e.target.closest('.devSave')){var m=it.querySelector('.devMsg');fetch('/api/ideas/'+id+'/review',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({reply:it.querySelector('.devRp').value})}).then(function(r){if(r.ok){(window._devCache||[]).forEach(function(q){if(q.id===id){q.reply=it.querySelector('.devRp').value;}});}m.textContent=r.ok?'Сохранено':'Ошибка';});return;}
if(e.target.closest('.devHd')){var bd=it.querySelector('.devBd');var o=bd.style.maxHeight&&bd.style.maxHeight!=='0px';bd.style.maxHeight=o?'0px':bd.scrollHeight+'px';}
});
if(!window._devNo&&!window._devCache){iw.classList.add('chk');}
if(window._devCache){loadDev(true);}
loadDev();
sd.onclick=function(){var t=tx.value.trim();if(!t){ms.textContent='Введите текст';return;}
sd.disabled=true;ms.textContent='Отправка...';
var _ed=editId;fetch(_ed?('/api/ideas/'+_ed):'/api/ideas',{method:_ed?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:ty.value,text:t})}).then(function(r){if(r.ok){tx.value='';editId=null;sd.textContent='Отправить';ms.textContent=_ed?'Сохранено':'Отправлено';loadIdeas();}else{ms.textContent='Ошибка отправки';}sd.disabled=false;}).catch(function(){ms.textContent='Нет связи с сервером';sd.disabled=false;});};
void iw.offsetWidth;
setTimeout(function(){if(iw){iw.classList.add('on');}},20);
}
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
var t=e.target.closest('#ideaBtn');
if(t){var _an=t.querySelectorAll('animateTransform');for(var _i=0;_i<_an.length;_i++){try{_an[_i].beginElement();}catch(_x){}}e.stopPropagation();e.preventDefault();if(iw===null){if(Date.now()-(window._ideaLastClose||0)<560){return;}openIdea();}else{closeIdea();}return;}
if(iw!==null&&e.target.closest('.buttons button')){closeIdea(true);}
},true);
(function(){var st=document.createElement('style');st.id='pfClose';st.textContent='.profile-modal-overlay .stage-modal{transform:none!important;opacity:1!important;clip-path:inset(-30px 100% -30px 0)!important;transition:clip-path .4s cubic-bezier(.22,1,.36,1)!important;}.profile-modal-overlay .stage-modal.open{clip-path:inset(-30px -60px -30px 0)!important;}';document.head.appendChild(st);})();
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
if(!e.target.closest('.buttons button')){return;}
var ex=document.querySelector('.profile-modal-overlay');if(!ex){return;}
var m=ex.querySelector('.stage-modal');if(m){m.style.display='none';}
if(typeof closeProfileModal==='function'){closeProfileModal();}else{ex.remove();}
},true);
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
if(!e.target.closest('#avatar')){return;}
window.pfOpenFix=1;
if(ov!==null){var _o=ov;closeAll();_o.style.display='none';}
if(tw!==null){var _t=tw;closeTeam();_t.style.display='none';}
if(sw!==null){var _s=sw;closeStruct(true);}
if(typeof iw!=='undefined'&&iw!==null){closeIdea(true);}
var pm=document.getElementById('page-map');
if(pm&&pm.classList.contains('active')&&!pm.classList.contains('mout')){pm.classList.add('mout');var mb=document.getElementById('mapBtn');if(mb){mb.classList.remove('nav-active');}setTimeout(function(){pm.classList.remove('mout');pm.classList.remove('active');},420);}
},true);
(function(){var st=document.createElement('style');st.id='stFix';st.textContent='.settings-modal-overlay .stage-modal{transform:none!important;opacity:1!important;clip-path:inset(-30px 100% -30px 0)!important;transition:clip-path .4s cubic-bezier(.22,1,.36,1)!important;}.settings-modal-overlay .stage-modal.open{clip-path:inset(-30px -60px -30px 0)!important;}';document.head.appendChild(st);})();
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
var b=e.target.closest('.buttons button');if(!b){return;}
var sb=document.getElementById('settingsBtn');
if(b.id==='settingsBtn'){
if(document.querySelector('.settings-modal-overlay')){return;}
if(ov!==null){var _o=ov;closeAll();_o.style.display='none';}
if(tw!==null){var _t=tw;closeTeam();_t.style.display='none';}
if(sw!==null){var _s=sw;closeStruct(true);}
if(typeof iw!=='undefined'&&iw!==null){closeIdea(true);}
var pm=document.getElementById('page-map');
if(pm&&pm.classList.contains('active')&&!pm.classList.contains('mout')){pm.classList.add('mout');var mb=document.getElementById('mapBtn');if(mb){mb.classList.remove('nav-active');}setTimeout(function(){pm.classList.remove('mout');pm.classList.remove('active');},420);}
setTimeout(function(){Array.prototype.forEach.call(document.querySelectorAll('.buttons button'),function(x){if(x!==sb){x.classList.remove('nav-active');}});},30);
return;}
var ex=document.querySelector('.settings-modal-overlay');
if(ex){var m=ex.querySelector('.stage-modal');if(m){m.style.display='none';}ex.remove();if(sb){sb.classList.remove('nav-active');}}
},true);
(function(){var st=document.createElement('style');st.id='pfLogoutCss';st.textContent='#logoutBtn{display:none!important;}';document.head.appendChild(st);
function add(){var sv=document.getElementById('pfSave');if(!sv||document.getElementById('pfLogout')){return;}
var row=sv.parentNode;if(!row||!row.parentNode){return;}
var b=document.createElement('button');b.id='pfLogout';b.textContent='Выход';
b.style.cssText='display:block;width:100%;height:34px;margin:12px 0 4px;border:0;border-radius:10px;background:#fff;color:#d9776f;font-size:12px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.12);';
sv.style.cssText+=';display:block;width:100%;height:34px;border-radius:10px;font-size:12px;';sv.setAttribute('pfSaveW','1');if(row.style){row.style.display='block';}
b.onclick=function(){var lb=document.getElementById('logoutBtn');if(lb){lb.click();}};
row.parentNode.insertBefore(b,row.nextSibling);}
new MutationObserver(add).observe(document.body,{childList:true,subtree:true});})();
(function(){var st=document.createElement('style');st.textContent='@keyframes gnB1{0%{stroke-dashoffset:100;opacity:0}.1%{opacity:1}10%,42%{stroke-dashoffset:0;opacity:1;transform:translateY(0)}54%,74%{stroke-dashoffset:0;opacity:1;transform:translateY(20px)}74.1%,100%{stroke-dashoffset:100;opacity:0;transform:translateY(0)}}@keyframes gnB2{0%,11.9%{stroke-dashoffset:100;opacity:0}12%{stroke-dashoffset:100;opacity:1}22%,74%{stroke-dashoffset:0;opacity:1}74.1%,100%{stroke-dashoffset:100;opacity:0}}@keyframes gnB3{0%,23.9%{stroke-dashoffset:100;opacity:0;transform:translateY(0)}24%{stroke-dashoffset:100;opacity:1;transform:translateY(0)}34%,42%{stroke-dashoffset:0;opacity:1;transform:translateY(0)}54%,74%{stroke-dashoffset:0;opacity:1;transform:translateY(-20px)}74.1%,100%{stroke-dashoffset:100;opacity:0;transform:translateY(0)}}@keyframes gnA1{0%,10%{transform:translateY(-9px);opacity:0}13%{opacity:1}15%{transform:translateY(1.5px);opacity:1}17%,40%{transform:translateY(0);opacity:1}44%,100%{transform:translateY(0);opacity:0}}@keyframes gnA2{0%,22%{transform:translateY(-9px);opacity:0}25%{opacity:1}27%{transform:translateY(1.5px);opacity:1}29%,40%{transform:translateY(0);opacity:1}44%,100%{transform:translateY(0);opacity:0}}@keyframes gnH{0%,52%{opacity:0}56%,74%{opacity:1}74.1%,100%{opacity:0}}@keyframes gnS{0%,60%{transform:translateX(0);animation-timing-function:ease-in}74%{transform:translateX(85px)}74.1%,100%{transform:translateX(0)}}.gnB{stroke-dasharray:100 100}.gnB,.gnA,.gnH,.gnS{animation-duration:7s;animation-iteration-count:infinite;animation-timing-function:cubic-bezier(.4,0,.2,1)}.gnB,.gnA{transform-box:fill-box}.gnH,.gnA{opacity:0}.gnB1{animation-name:gnB1}.gnB2{animation-name:gnB2}.gnB3{animation-name:gnB3}.gnA1{animation-name:gnA1}.gnA2{animation-name:gnA2}.gnH{animation-name:gnH}.gnS{animation-name:gnS}';document.head.appendChild(st);})();
(function(){var st=document.createElement('style');st.textContent='#ganttWin{scrollbar-width:none;-ms-overflow-style:none;}#ganttWin::-webkit-scrollbar{display:none;width:0;height:0;}';document.head.appendChild(st);})();
(function(){var st=document.createElement('style');st.id='gnLvl2';st.textContent='#ganttWin [data-sk-kids]{background:transparent!important;}#ganttWin .sx-row[data-sk^="p:"],#ganttWin .sx-row[data-sk^="m:"]{background:rgba(91,148,208,0.25)!important;border-radius:10px;}';document.head.appendChild(st);})();
var GCW=70,GCW2=0;GCW=[32,60,60,32,32,38];
function gcols(k){return '<span class="gcol" data-g="'+k+'" style="position:absolute;right:8px;top:50%;transform:translateY(-50%);display:flex;gap:4px;font-size:10px;color:#4b5563;white-space:nowrap;font-variant-numeric:tabular-nums;">'+GCW.map(function(w){return '<span style="width:'+w+'px;text-align:right;"></span>';}).join('')+'</span>';}
function gHead(){var n=['Дней','Начало','Окончание','План','Факт','Разн.'];return '<div style="position:sticky;top:-16px;z-index:5;background:#fff;margin:-16px -16px 8px;height:52px;box-sizing:border-box;align-items:flex-end;padding:0 34px 10px 26px;display:flex;justify-content:flex-end;gap:4px;font-variant-numeric:tabular-nums;font-size:10px;font-weight:700;color:#6b7280;">'+n.map(function(t,i){return '<span style="width:'+GCW[i]+'px;text-align:right;">'+t+'</span>';}).join('')+(window.gnFiltHtml?window.gnFiltHtml():'')+'</div>';}
function gFmt(v){if(!v){return '';}var d=new Date(v);if(isNaN(d)){return '';}var q=function(n){return (n<10?'0':'')+n;};return q(d.getDate())+'.'+q(d.getMonth()+1)+'.'+d.getFullYear();}
function gPaint(el,o){var c=el.children;if(!o){return;}c[1].textContent=gFmt(o.start);c[2].textContent=gFmt(o.end);var a=new Date(o.start),b=new Date(o.end);if(!isNaN(a)&&!isNaN(b)){c[0].textContent=Math.round((b-a)/86400000);}
if(o.plan==null||o.fact==null){return;}c[3].textContent=o.plan+'%';c[4].textContent=o.fact+'%';var df=o.fact-o.plan;c[5].textContent=(df>0?'+':'')+df+'%';c[5].style.color=df<0?'#d9776f':'#3aa88a';c[5].style.fontWeight='700';}
window._gnCache=window._gnCache||{};
function ganttFill(w){
var ST6=['Базовое проектирование','Детальное проектирование','Изготовление','Логистика','Строительство','ПНР'];
var els=w.querySelectorAll('.gcol'),by={};
Array.prototype.forEach.call(els,function(el){var k=el.getAttribute('data-g').split(':');var code=k[1];if(k[0]==='gp'){return;}(by[code]=by[code]||[]).push({el:el,t:k[0],i:k[2]});});
function paint(code,d){(by[code]||[]).forEach(function(x){
if(x.t==='ms'){var n=ST6[x.i],st=null;(d.stages||[]).forEach(function(q){if(q.name===n){st=q;}});if(!st){st=(d.stages||[])[x.i];}
if(st&&st.cost){gPaint(x.el,{start:st.start,end:st.end,plan:Math.round(st.planPct||0),fact:Math.min(100,Math.round((st.done||0)/st.cost*100))});}}
else if(d.totalCost){gPaint(x.el,{start:d.start,end:d.end,plan:Math.round(d.planPct||0),fact:Math.min(100,Math.round((d.done||0)/d.totalCost*100))});}});}
Object.keys(by).forEach(function(code){
if(window._gnCache[code]){paint(code,window._gnCache[code]);return;}
fetch('/api/reports/'+encodeURIComponent(code)+'/summary').then(function(r){return r.json();}).then(function(d){window._gnCache[code]=d;if(w.isConnected){paint(code,d);}}).catch(function(){});});
}
function gCodes(key){var a=[];try{if(key==='main'||key==='aux'){PROJECTS[key].items.forEach(function(it){a.push(it.code);});}else{PROJECTS.prep.items.forEach(function(it){if(key==='prep'||it.code.split('-')[0]===key){a.push(it.code);}});}}catch(e){}return a;}
function gGet(code){if(window._gnCache[code]){return Promise.resolve(window._gnCache[code]);}return fetch('/api/reports/'+encodeURIComponent(code)+'/summary').then(function(r){return r.json();}).then(function(d){window._gnCache[code]=d;return d;}).catch(function(){return null;});}
function gGroups(w){
Array.prototype.forEach.call(w.querySelectorAll('.gcol[data-g^="gp:"]'),function(el){
var key=el.getAttribute('data-g').slice(3),codes=gCodes(key);if(!codes.length){return;}
Promise.all(codes.map(gGet)).then(function(l){if(!w.isConnected){return;}
var cost=0,done=0,pw=0,st=null,en=null;
l.forEach(function(d){if(!d||!d.totalCost){return;}cost+=d.totalCost;done+=(d.done||0);pw+=(d.planPct||0)*d.totalCost;
if(d.start&&(!st||new Date(d.start)<new Date(st))){st=d.start;}if(d.end&&(!en||new Date(d.end)>new Date(en))){en=d.end;}});
if(!cost){return;}
gPaint(el,{start:st,end:en,plan:Math.round(pw/cost),fact:Math.min(100,Math.round(done/cost*100))});});});
}
(function(){var st=document.createElement('style');st.id='gnAlign';st.textContent='#ganttWin .sx-row{padding-right:288px!important;}#ganttWin .sx-row{position:relative;}#ganttWin [data-sk-kids]{clip-path:none;}#ganttWin .sx-row>span:nth-child(2){white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}';document.head.appendChild(st);})();
(function(){var st=document.createElement('style');st.id='gnAlign2';st.textContent='#ganttWin .sx-row>span:nth-child(2){max-width:calc(100% - 20px);}';document.head.appendChild(st);})();
(function(){var st=document.createElement('style');st.id='gnLines';st.textContent='#ganttWin [data-sk-kids^="p:"] .sx-row:not(:last-child),#ganttWin [data-sk-kids^="m:"] .sx-row:not(:last-child){border-bottom:1px solid #e5e9ef;}#ganttWin [data-sk-kids="main"]>.sx-row:not(:last-child),#ganttWin [data-sk-kids="aux"]>.sx-row:not(:last-child){border-bottom:1px solid #e5e9ef;}';document.head.appendChild(st);})();
function ganttBars(L,R){
var MW=14,sy=null,ey=null,W=0,centered=false;
var sc=document.createElement('div');sc.style.cssText='position:absolute;left:0;top:0;right:0;bottom:0;overflow-x:auto;overflow-y:hidden;cursor:grab;scrollbar-width:none;';
R.appendChild(sc);
var content=document.createElement('div');content.style.cssText='position:relative;height:100%;';sc.appendChild(content);
var lay=document.createElement('div');lay.style.cssText='position:absolute;left:0;top:0;pointer-events:none;z-index:1;';content.appendChild(lay);
var head=document.createElement('div');head.style.cssText='position:absolute;left:0;top:0;height:52px;background:#fff;border-bottom:1px solid #e5e9ef;z-index:5;box-sizing:border-box;';content.appendChild(head);
function pd(t){var m=/(\d\d)\.(\d\d)\.(\d{4})/.exec(t||'');return m?new Date(+m[3],+m[2]-1,+m[1]).getTime():null;}
function X(t){var a=new Date(sy,0,1).getTime(),b=new Date(ey+1,0,1).getTime();return (t-a)/(b-a)*W;}
function range(){var lo=2023,hi=2028;Array.prototype.forEach.call(L.querySelectorAll('.gcol'),function(c){var k=c.children;if(k.length<3){return;}[pd(k[1].textContent),pd(k[2].textContent)].forEach(function(t){if(t!=null){var y=new Date(t).getFullYear();if(y<lo){lo=y;}if(y>hi){hi=y;}}});});return [lo,hi];}
function build(lo,hi){var prev=sy;sy=lo;ey=hi;W=(ey-sy+1)*12*MW;content.style.width=W+'px';lay.style.width=W+'px';head.style.width=W+'px';
var h='';for(var y=sy;y<=ey;y++){h+='<div style="position:absolute;left:'+(y-sy)*12*MW+'px;width:'+12*MW+'px;top:0;bottom:0;border-left:1px solid #e5e9ef;box-sizing:border-box;"><div style="font-size:10px;font-weight:700;color:#1f2937;padding:8px 0 4px 0;text-align:center;">'+y+'</div><div style="display:flex;">';
for(var m=1;m<=12;m++){h+='<div style="width:'+MW+'px;text-align:center;font-size:9px;color:#6b7280;font-variant-numeric:tabular-nums;">'+(m<10?'0':'')+m+'</div>';}h+='</div></div>';}
h+='<div style="position:absolute;left:0;right:0;bottom:0;height:3px;background:linear-gradient(90deg,#6A5BD6,#5B94D0 60%,#5FD2B0);"></div>';
head.innerHTML=h;
if(prev!=null&&prev!==sy){sc.scrollLeft+=(prev-sy)*12*MW;}
if(!centered){centered=true;sc.scrollLeft=Math.max(0,X(Date.now())-sc.clientWidth/2);}}
function draw(){if(!L.isConnected){return;}
var r=range();if(sy!==r[0]||ey!==r[1]){build(r[0],r[1]);}
var lr=L.getBoundingClientRect(),st=L.scrollTop;
lay.style.height=L.scrollHeight+'px';lay.style.transform='translateY('+(-st)+'px)';
var h='',now=Date.now(),nx=X(now);for(var yy=sy;yy<=ey;yy++){h+='<div style="position:absolute;top:0;bottom:0;left:'+X(new Date(yy,0,1).getTime())+'px;width:1px;background:#e5e9ef;"></div>';}
h+='<div style="position:absolute;top:0;bottom:0;left:'+nx+'px;width:1px;background:#d9776f;opacity:.7;"></div>';
Array.prototype.forEach.call(L.querySelectorAll('.sx-row'),function(rw){
var c=rw.querySelector('.gcol');if(!c){return;}
var cT=-1e9,cB=1e9;for(var p=rw.parentElement;p&&p!==L;p=p.parentElement){if(p.hasAttribute('data-sk-kids')){var pr=p.getBoundingClientRect();if(pr.top>cT){cT=pr.top;}if(pr.bottom<cB){cB=pr.bottom;}}}
var rr=rw.getBoundingClientRect(),y=rr.top-lr.top+st;
if(rr.height<1||rr.bottom<=cT+0.5||rr.top>=cB-0.5){return;}
if(rr.bottom<=cB+0.5){h+='<div style="position:absolute;left:0;right:0;top:'+(y+rr.height)+'px;height:1px;background:#eef0f3;"></div>';}
var k=c.children,a=pd(k[1].textContent),b=pd(k[2].textContent);if(a==null||b==null){return;}
var pl=parseFloat(k[3].textContent)||0,fa=parseFloat(k[4].textContent)||0;
var x=X(a),w=Math.max(4,X(b)-x),bh=20,top=y+(rr.height-bh)/2,bv=rr.top+(rr.height-bh)/2,ca=Math.max(0,cT-bv),cb=Math.max(0,bv+bh-cB);if(ca+cb>=bh){return;}
h+='<div style="position:absolute;left:'+x+'px;width:'+w+'px;top:'+top+'px;height:'+bh+'px;border-radius:5px;background:rgba(91,148,208,.18);overflow:hidden;clip-path:inset('+ca+'px 0 '+cb+'px 0);"><div style="position:absolute;left:0;top:0;width:'+pl+'%;height:100%;background:#6A5BD6;"></div><div style="position:absolute;left:0;top:0;width:'+fa+'%;height:100%;background:#5FD2B0;"></div></div>';
});
lay.innerHTML=h;}
var raf=0;function sched(){cancelAnimationFrame(raf);raf=requestAnimationFrame(draw);}
L.addEventListener('scroll',sched);
L.addEventListener('click',function(){var t0=Date.now();(function loop(){draw();if(Date.now()-t0<520&&L.isConnected){requestAnimationFrame(loop);}})();});
new MutationObserver(sched).observe(L,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['style','data-o']});
var dx=null,s0=0;
sc.addEventListener('mousedown',function(e){dx=e.clientX;s0=sc.scrollLeft;sc.style.cursor='grabbing';e.preventDefault();});
window.addEventListener('mousemove',function(e){if(dx!==null){sc.scrollLeft=s0-(e.clientX-dx);}});
window.addEventListener('mouseup',function(){if(dx!==null){dx=null;sc.style.cursor='grab';}});
sc.addEventListener('wheel',function(e){if(e.shiftKey){L.scrollTop+=e.deltaY;}else{sc.scrollLeft+=(Math.abs(e.deltaX)>Math.abs(e.deltaY)?e.deltaX:e.deltaY);}e.preventDefault();},{passive:false});
setTimeout(draw,150);
}
function ganttCal(box){}
function ganttListHtml(){
var nm={};try{PROJECTS.main.items.concat(PROJECTS.aux.items).forEach(function(it){nm[it.code]=it.name;});}catch(e){}
var g={},ord=[];try{PROJECTS.prep.items.forEach(function(it){var pc=it.code.split('-')[0];if(g[pc]==null){g[pc]=[];ord.push(pc);}g[pc].push(it);});}catch(e){}
var inner='';
ord.forEach(function(pc){var sub='';g[pc].forEach(function(it){sub+=structRow(12,it.code+' '+it.name,false,'o:'+it.code,false,true,gcols('o:'+it.code));});inner+='<div style="background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.12);margin:4px 10px 10px 10px;">'+structRow(12,(pc+' '+(nm[pc]||'')).trim(),true,'p:'+pc,false,false,gcols('gp:'+pc))+structKids('p:'+pc,sub,false)+'</div>';});
var ST=['Базовое проектирование','Детальное проектирование','Изготовление','Логистика','Строительство','ПНР'];
var WS={PSP01:1,CSM01:1};
var h='<div class="ml-card0" style="margin:0 0 6px 0;">'+structRow(12,'Подготовительные работы',true,'prep',true,true,gcols('gp:prep'))+structKids('prep',inner,true)+'</div>';
[['main','Основные проекты'],['aux','Вспомогательные проекты']].forEach(function(x){var it2='';
try{PROJECTS[x[0]].items.forEach(function(it){var t=it.code+' '+it.name;
if(WS[it.code]){var sub='';ST.forEach(function(n,k){sub+=structRow(28,n,false,'ms:'+it.code+':'+k,false,true,gcols('ms:'+it.code+':'+k));});it2+='<div style="background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.12);margin:4px 10px 10px 10px;">'+structRow(12,t,true,'m:'+it.code,false,false,gcols('m:'+it.code))+structKids('m:'+it.code,sub,false)+'</div>';}
else{it2+=structRow(28,t,false,'q:'+it.code,false,true,gcols('q:'+it.code));}});}catch(e){}
h+='<div class="ml-card0" style="margin:0 0 6px 0;">'+structRow(12,x[1],true,x[0],true,true,gcols('gp:'+x[0]))+structKids(x[0],it2,true)+'</div>';});
return h;
}
var gw=null,gw2=null,gTimer=null;
function gnAnims(){var b=document.getElementById('ganttBtn');var sv=b&&b.querySelector('svg');if(!sv||!sv.getAnimations){return [];}return sv.getAnimations({subtree:true}).filter(function(a){return a.animationName&&a.animationName.indexOf('gn')===0;});}
function gnPlay(from,to){var an=gnAnims();clearTimeout(gTimer);an.forEach(function(a){a.currentTime=from;a.play();});gTimer=setTimeout(function(){gnAnims().forEach(function(a){a.pause();a.currentTime=2940;});},to-from);}
setTimeout(function(){gnAnims().forEach(function(a){a.pause();a.currentTime=2940;});},400);
function closeGantt(instant){
if(gw===null){return;}
var o=gw;gw=null;var o2=gw2;gw2=null;if(o2){if(instant){o2.style.display='none';}o2.classList.remove('on');setTimeout(function(){o2.remove();},520);}
if(instant){o.style.display='none';}
o.classList.remove('on');
var gb=document.getElementById('ganttBtn');if(gb){gb.classList.remove('nav-active');}
if(window._ganttPrev){window._ganttPrev.classList.add('nav-active');window._ganttPrev=null;}
window._ganttLastClose=Date.now();
gnPlay(2940,5180);
setTimeout(function(){o.remove();},520);
}
function openGantt(){
if(gw!==null){return;}
if(ov!==null){var _o=ov;closeAll();_o.style.display='none';}
if(tw!==null){var _t=tw;closeTeam();_t.style.display='none';}
if(sw!==null){closeStruct(true);}
if(typeof iw!=='undefined'&&iw!==null){closeIdea(true);}
var pv=document.querySelector('.buttons button.nav-active');
window._ganttPrev=(pv&&pv.id!=='ganttBtn')?pv:null;
document.querySelectorAll('.buttons button').forEach(function(x){x.classList.remove('nav-active');});
var gb=document.getElementById('ganttBtn');if(gb){gb.classList.add('nav-active');}
gw=document.createElement('div');gw.id='ganttWin';gw.className='upm-win';
gw.style.cssText='left:104px;width:calc(50vw - 104px);padding:0;z-index:2001;border:0;overflow:auto;';
gw.style.padding='16px';gw.innerHTML=gHead()+ganttListHtml();structBind(gw);ganttFill(gw);gGroups(gw);Array.prototype.forEach.call(gw.querySelectorAll('.sx-row'),function(r){r.draggable=false;});document.body.appendChild(gw);gw2=document.createElement('div');gw2.id='ganttWin2';gw2.className='upm-win';gw2.style.cssText='left:calc(50vw + 16px);right:16px;padding:0;z-index:2001;border:0;border-radius:20px;overflow:hidden;box-shadow:0 2px 14px rgba(0,0,0,0.12);';document.body.appendChild(gw2);ganttCal(gw2);ganttBars(gw,gw2);void gw.offsetWidth;
gnPlay(0,2940);
setTimeout(function(){if(gw){gw.classList.add('on');}if(gw2){gw2.classList.add('on');}},20);
}
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
var t=e.target.closest('#ganttBtn');
if(t){var an=t.querySelectorAll('animateTransform');for(var i=0;i<an.length;i++){try{an[i].beginElement();}catch(x){}}
e.stopPropagation();e.preventDefault();
if(gw===null){if(Date.now()-(window._ganttLastClose||0)<560){return;}openGantt();}else{closeGantt();}return;}
if(gw!==null&&e.target.closest('.buttons button')){closeGantt(true);}
},true);
(function(){var st=document.createElement('style');st.id='gnLeft';st.textContent='#ganttWin .sx-row>span:first-child{display:none!important;}#ganttWin .sx-row{padding-left:6px!important;text-align:left!important;}#ganttWin .sx-row[data-sk^="q:"]{padding-left:10px!important;}#ganttWin .sx-row[data-sk^="ms:"]{padding-left:20px!important;}#ganttWin .sx-row[data-sk^="p:"],#ganttWin .sx-row[data-sk^="m:"]{font-weight:700!important;color:#1f2937!important;}#ganttWin .sx-row[data-sk^="p:"] .gcol,#ganttWin .sx-row[data-sk^="m:"] .gcol{font-weight:700!important;color:#1f2937!important;}';document.head.appendChild(st);})();
(function(){
var IT=[['all','Все этапы'],['d','Проектирование'],['s','Поставка'],['c','Строительство'],['p','ПНР']];
var G=['d','d','s','s','c','p'];
window.gnFiltHtml=function(){window._gnMode='all';
var it=IT.map(function(x){return '<div class="gnFI" data-m="'+x[0]+'" style="padding:8px 12px;border-radius:8px;font-size:11px;font-weight:600;color:#1f2937;cursor:pointer;white-space:nowrap;">'+x[1]+'</div>';}).join('');
return '<div style="position:absolute;left:14px;bottom:8px;"><button id="gnFB" type="button" style="border:0;border-radius:14px;height:28px;padding:0 12px;background:#eef2f8;color:#1f2937;font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;display:flex;align-items:center;gap:6px;"><span id="gnFL">Все этапы</span><svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 3.5 L5 6.5 L8 3.5" fill="none" stroke="#6b7280" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg></button><div id="gnFM" style="display:none;position:absolute;left:0;top:34px;background:#fff;border-radius:12px;box-shadow:0 6px 24px rgba(0,0,0,.16);padding:6px;min-width:170px;z-index:30;">'+it+'</div></div>';};
var TR='max-height .38s cubic-bezier(.22,1,.36,1),opacity .3s,padding .38s cubic-bezier(.22,1,.36,1),margin .38s cubic-bezier(.22,1,.36,1)';
function gHide(el){if(el.getAttribute('data-gh')==='1'){return;}var cs=getComputedStyle(el);el._g=[cs.paddingTop,cs.paddingBottom,cs.marginTop,cs.marginBottom];
el.setAttribute('data-gh','1');el.style.transition=TR;el.style.overflow='hidden';el.style.maxHeight=el.offsetHeight+'px';void el.offsetHeight;
el.style.maxHeight='0px';el.style.opacity='0';el.style.paddingTop='0px';el.style.paddingBottom='0px';el.style.marginTop='0px';el.style.marginBottom='0px';el.style.pointerEvents='none';}
function gShow(el){if(el.getAttribute('data-gh')!=='1'){return;}el.setAttribute('data-gh','0');var g=el._g||['','','',''];
el.style.maxHeight=(el.scrollHeight+40)+'px';el.style.opacity='1';el.style.paddingTop=g[0];el.style.paddingBottom=g[1];el.style.marginTop=g[2];el.style.marginBottom=g[3];el.style.pointerEvents='';
setTimeout(function(){if(el.getAttribute('data-gh')==='0'){el.style.maxHeight='';el.style.overflow='';el.style.transition='';}},420);}
function gnApply(){var w=document.getElementById('ganttWin');if(!w){return;}var m=window._gnMode||'all';
var rows=Array.prototype.slice.call(w.querySelectorAll('.sx-row'));
rows.forEach(function(r){r.removeAttribute('data-lv');});
rows.forEach(function(r){var k=r.getAttribute('data-sk')||'';var isL=(k.indexOf('ms:')===0||k.indexOf('o:')===0||k.indexOf('q:')===0);if(!isL){return;}
var c=r.querySelector('.gcol'),has=!!(c&&c.children[1]&&c.children[1].textContent.trim());
var v=(m==='all')||(has&&(k.indexOf('ms:')===0?G[+k.split(':')[2]]===m:m==='c'));
if(v){r.setAttribute('data-lv','1');gShow(r);}else{gHide(r);}});
rows.forEach(function(r){var k=r.getAttribute('data-sk')||'';if(k.indexOf('ms:')===0||k.indexOf('o:')===0||k.indexOf('q:')===0){return;}
var el=r.parentElement;if(!el){return;}
var v=(m==='all')||!!el.querySelector('[data-lv="1"]');
if(v){gShow(el);}else{gHide(el);}});
if(m!=='all'){Array.prototype.forEach.call(w.querySelectorAll('.sx-row[data-sk^="m:"]'),function(r){var kd=r.nextElementSibling;if(kd&&kd.hasAttribute('data-sk-kids')){kd.setAttribute('data-o','1');}});
Array.prototype.forEach.call(w.querySelectorAll('[data-sk-kids][data-o="1"]'),function(kd){kd.style.maxHeight='none';});}
w.dispatchEvent(new Event('click'));}
document.addEventListener('click',function(e){
var fb=e.target.closest&&e.target.closest('#gnFB');var fm=document.getElementById('gnFM');
if(fb&&fm){e.stopPropagation();fm.style.display=fm.style.display==='block'?'none':'block';return;}
var fi=e.target.closest&&e.target.closest('.gnFI');
if(fi){e.stopPropagation();window._gnMode=fi.getAttribute('data-m');var lb=document.getElementById('gnFL');if(lb){lb.textContent=fi.textContent;}if(fm){fm.style.display='none';}gnApply();return;}
if(fm&&fm.style.display==='block'){fm.style.display='none';}
},true);
})();
function structAct(act,code){
if(act==='export'){window.location.href='/api/reports/export?code='+encodeURIComponent(code);return;}
var inp=document.createElement('input');inp.type='file';inp.accept='.xlsx';
inp.onchange=function(){var f=inp.files[0];if(!f){return;}
if(!confirm('Загрузить файл '+f.name+'? Данные запишутся по кодам проектов, указанным внутри файла, и заменят текущие.')){return;}
var fd=new FormData();fd.append('file',f);
fetch('/api/reports/import',{method:'POST',body:fd}).then(function(r){return r.json().catch(function(){return {};}).then(function(j){if(r.ok&&sw){structUpd(sw,true);}alert(r.ok?('Загружено'+(j.message?': '+j.message:'')):('Ошибка: '+(j.message||r.status)));});}).catch(function(){alert('Нет связи с сервером');});
};
inp.click();
}
function structBind(w){Array.prototype.forEach.call(w.querySelectorAll('.sx-row[data-sk^="o:"]'),function(r){r.draggable=true;});w.addEventListener('dragstart',function(e){var r=e.target.closest&&e.target.closest('.sx-row');if(!r){return;}var k=r.getAttribute('data-sk')||'';if(k.indexOf('o:')!==0){return;}var code=k.slice(2);try{e.dataTransfer.effectAllowed='copy';e.dataTransfer.setData('DownloadURL','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet:'+code+'.xlsx:'+location.origin+'/api/reports/export?code='+encodeURIComponent(code));}catch(x){}});w.addEventListener('click',function(e){var bt=e.target.closest('.sx-btn');if(bt){e.stopPropagation();structAct(bt.getAttribute('data-act'),bt.getAttribute('data-code'));return;}var r=e.target.closest('.sx-row');if(!r){return;}var k=r.getAttribute('data-sk');var kd=w.querySelector('[data-sk-kids="'+k+'"]');if(!kd){return;}var ar=r.firstChild;var o=kd.style.maxHeight!=='0px';kd.style.transition='max-height .35s ease';if(o){kd.style.transition='none';kd.style.maxHeight=kd.scrollHeight+'px';void kd.offsetHeight;kd.style.transition='max-height .35s ease';kd.style.maxHeight='0px';}else{kd.style.maxHeight=kd.scrollHeight+'px';setTimeout(function(){if(kd.style.maxHeight!=='0px'){kd.style.maxHeight='5000px';}},420);}if(ar){ar.style.transform=o?'rotate(-90deg)':'';}});}
(function(){var st=document.createElement('style');st.textContent='#structWin{scrollbar-width:none;-ms-overflow-style:none;}#structWin::-webkit-scrollbar{display:none;width:0;height:0;}';document.head.appendChild(st);})();var sw=null;
function closeStruct(instant){
if(sw===null){return;}
var o=sw;sw=null;
if(instant){o.style.display='none';}
if(!instant&&window.DB_OLD!==true){dbDust(o,'out');}o.classList.remove('on');
var sb=document.getElementById('structureBtn');if(sb){sb.classList.remove('nav-active');}
if(window._structPrev){window._structPrev.classList.add('nav-active');window._structPrev=null;}
window._structLastClose=Date.now();
setTimeout(function(){o.remove();},1050);
}
function dbDust(w,mode){var bs=[].slice.call(w.querySelectorAll('.dbb'));if(!bs.length){return;}
var dpr=Math.min(2,window.devicePixelRatio||1),W=innerWidth,H=innerHeight,cv=document.createElement('canvas');
cv.width=W*dpr;cv.height=H*dpr;cv.style.cssText='position:fixed;left:0;top:0;width:'+W+'px;height:'+H+'px;pointer-events:none;z-index:2003';
document.body.appendChild(cv);var c=cv.getContext('2d');c.scale(dpr,dpr);
var rs=bs.map(function(b){return b.getBoundingClientRect();}),y0=rs[0].top,y1=rs[rs.length-1].bottom,P=[],sbr=document.getElementById('structureBtn').getBoundingClientRect(),bx=sbr.left+sbr.width/2,by=sbr.top+sbr.height/2;
function mix(a,b,t){return [Math.round(a[0]+(b[0]-a[0])*t),Math.round(a[1]+(b[1]-a[1])*t),Math.round(a[2]+(b[2]-a[2])*t)];}
function rgb(f){f=Math.max(0,Math.min(1,f+(Math.random()-.5)*.25));return (f<.5?mix([106,91,214],[91,148,208],f*2):mix([91,148,208],[95,210,176],(f-.5)*2)).join(',');}
rs.forEach(function(r){var R=r.width/2,cx=r.left+R,cy=r.top+r.height/2;for(var i=0;i<1100;i++){var a=Math.random()*6.283,d=Math.sqrt(Math.random())*R*1.05,tx=cx+Math.cos(a)*d,ty=cy+Math.sin(a)*d;P.push({tx:tx,ty:ty,rgb:rgb((ty-y0)/Math.max(1,y1-y0)),dl:Math.random()*.4,ox:bx+(Math.random()-.5)*24,oy:by+(Math.random()-.5)*24,ph:Math.random()*6.283,s:.45+Math.random()*.4});}});
var IN=mode==='in',T=IN?1100:950,t0=performance.now();
if(IN){bs.forEach(function(b,i){setTimeout(function(){b.classList.add('sh');},600+i*110);});}else{bs.forEach(function(b){b.style.transition='opacity .25s';b.classList.remove('sh');});}
function ease(x){return 1-Math.pow(1-x,3);}
function fr(now){var e=(now-t0)/T;if(e>=1){cv.remove();return;}c.clearRect(0,0,W,H);
var g=IN?(e>.65?Math.max(0,1-(e-.65)/.35):1):1;
for(var i=0;i<P.length;i++){var p=P[i],k=Math.max(0,Math.min(1,(e-p.dl)/(1-p.dl))),q=ease(k),x,y,al;
if(IN){x=p.tx+(p.ox-p.tx)*(1-q)+Math.sin(p.ph+e*9)*(1-q)*q*60;y=p.ty+(p.oy-p.ty)*(1-q)+Math.cos(p.ph+e*7)*(1-q)*q*60;al=Math.min(1,k*4)*g*.9;}
else{x=p.tx+(p.ox-p.tx)*q+Math.sin(p.ph+e*9)*(1-q)*q*60;y=p.ty+(p.oy-p.ty)*q+Math.cos(p.ph+e*7)*(1-q)*q*60;al=(k>.9?(1-k)/.1:1)*.9;}
if(al<=0.01){continue;}c.fillStyle='rgba('+p.rgb+','+al.toFixed(2)+')';c.fillRect(x,y,p.s,p.s);}
requestAnimationFrame(fr);}
requestAnimationFrame(fr);}
function dbBtnsHtml(){var sb=document.getElementById('structureBtn');var r=sb?sb.getBoundingClientRect():{top:400,height:50};var cy=Math.round(r.top+r.height/2);
var V=`<style>
@keyframes vM{0%{opacity:0;transform:scale(.7);filter:blur(3px)}4%{opacity:1;transform:scale(1);filter:blur(0)}21%{opacity:1;transform:scale(1);filter:blur(0)}25%{opacity:0;transform:scale(1.3);filter:blur(3px)}100%{opacity:0;transform:scale(1.3);filter:blur(3px)}}
.vI{transform-origin:60px 60px;opacity:0;animation:vM 9.6s ease-in-out infinite backwards}
.vI1{animation-delay:-.38s}.vI2{animation-delay:2.02s}.vI3{animation-delay:4.42s}.vI4{animation-delay:6.82s}
</style>
<svg role="img" aria-label="Подготовительные работы" width="300" height="300" viewBox="0 0 120 120">
<defs>
<linearGradient id="vRing" gradientUnits="userSpaceOnUse" x1="0" y1="5" x2="0" y2="115"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient>
<linearGradient id="vBody" gradientUnits="userSpaceOnUse" x1="0" y1="28" x2="0" y2="92"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient>
<clipPath id="vClip"><circle cx="60" cy="60" r="49"/></clipPath>
</defs>
<path d="M5.84 50.45 A55 55 0 0 1 69.55 5.84" fill="none" stroke="url(#vRing)" stroke-width="6" stroke-linecap="round"/>
<path d="M80.6 9 A55 55 0 1 1 5.03 61.92" fill="none" stroke="url(#vRing)" stroke-width="6" stroke-linecap="round"/>
<g clip-path="url(#vClip)">
<g class="vI vI1" fill="url(#vBody)" stroke="url(#vBody)" stroke-linejoin="round" stroke-linecap="round">
<rect x="32" y="72" width="48" height="14" rx="7" stroke="none"/>
<path d="M74 72 V54 H52 L44 64 V72 Z" stroke-width="3"/>
<rect x="62" y="44" width="5" height="10" rx="2.5" stroke="none"/>
<rect x="58" y="58" width="10" height="8" rx="2" fill="#fff" stroke="none"/>
<path d="M86 44 V82" fill="none" stroke-width="7"/>
<path d="M84 76 H76" fill="none" stroke-width="5"/>
</g>
<g class="vI vI2" fill="url(#vBody)" stroke="url(#vBody)" stroke-linejoin="round" stroke-linecap="round">
<rect x="32" y="76" width="46" height="11" rx="5.5" stroke="none"/>
<rect x="36" y="56" width="24" height="18" rx="4" stroke="none"/>
<rect x="41" y="60" width="9" height="8" rx="2" fill="#fff" stroke="none"/>
<path d="M56 62 L70 40 L86 52" fill="none" stroke-width="6"/>
<path d="M82 50 L94 58 L88 68 L80 62 Z" stroke-width="2"/>
</g>
<g class="vI vI3" fill="url(#vBody)" stroke="url(#vBody)" stroke-linejoin="round" stroke-linecap="round">
<path d="M30 50 H64 V70 H30 Z" stroke-width="4"/>
<path d="M68 70 V54 H80 L90 64 V70 Z" stroke-width="3"/>
<circle cx="44" cy="78" r="8.5" stroke="none"/>
<circle cx="76" cy="78" r="8.5" stroke="none"/>
<circle cx="44" cy="78" r="3" fill="#fff" stroke="none"/>
<circle cx="76" cy="78" r="3" fill="#fff" stroke="none"/>
<rect x="72" y="58" width="8" height="6" rx="1.5" fill="#fff" stroke="none"/>
</g>
<g class="vI vI4" fill="url(#vBody)" stroke="url(#vBody)" stroke-linejoin="round" stroke-linecap="round">
<rect x="52" y="38" width="6" height="48" rx="1" stroke="none"/>
<rect x="32" y="38" width="56" height="5" rx="2.5" stroke="none"/>
<path d="M55 28 V38" fill="none" stroke-width="4"/>
<rect x="32" y="43" width="9" height="9" rx="2" stroke="none"/>
<path d="M78 43 V60" fill="none" stroke-width="2.5"/>
<rect x="72" y="60" width="12" height="9" rx="2" stroke="none"/>
<rect x="42" y="84" width="26" height="5" rx="2.5" stroke="none"/>
</g>
</g>
</svg>`;
var F=`<style>
@keyframes fM{0%{opacity:0;transform:scale(.7);filter:blur(3px)}4%{opacity:1;transform:scale(1);filter:blur(0)}21%{opacity:1;transform:scale(1);filter:blur(0)}25%{opacity:0;transform:scale(1.3);filter:blur(3px)}100%{opacity:0;transform:scale(1.3);filter:blur(3px)}}
.fM{transform-origin:60px 60px;opacity:0;animation:fM 9.6s ease-in-out infinite backwards}
.fM1{animation-delay:-.38s}.fM2{animation-delay:2.02s}.fM3{animation-delay:4.42s}.fM4{animation-delay:6.82s}
</style>
<svg role="img" aria-label="Финансы" width="300" height="300" viewBox="0 0 120 120">
<defs>
<linearGradient id="fRing" gradientUnits="userSpaceOnUse" x1="0" y1="5" x2="0" y2="115"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient>
<linearGradient id="fCoinG" gradientUnits="userSpaceOnUse" x1="0" y1="26" x2="0" y2="94"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient>
</defs>
<path d="M5.84 50.45 A55 55 0 0 1 69.55 5.84" fill="none" stroke="url(#fRing)" stroke-width="6" stroke-linecap="round"/>
<path d="M80.6 9 A55 55 0 1 1 5.03 61.92" fill="none" stroke="url(#fRing)" stroke-width="6" stroke-linecap="round"/>
<g fill="none" stroke="url(#fCoinG)" stroke-linecap="round" stroke-linejoin="round">
<g class="fM fM1"><path d="M78 42 C74 34 66 32 60 32 C48 32 42 38 42 45 C42 54 52 56 60 59 C68 62 78 65 78 74 C78 82 70 88 60 88 C50 88 42 84 39 76" stroke-width="9"/><path d="M60 22 V98" stroke-width="5"/></g>
<g class="fM fM2"><path d="M80 40 C74 34 66 32 58 32 C44 32 36 44 36 60 C36 76 44 88 58 88 C66 88 74 86 80 80" stroke-width="9"/><path d="M27 52 H68 M27 68 H68" stroke-width="5"/></g>
<g class="fM fM3"><path d="M78 42 C74 34 66 32 60 32 C48 32 42 38 42 45 C42 54 52 56 60 59 C68 62 78 65 78 74 C78 82 70 88 60 88 C50 88 42 84 39 76" stroke-width="9"/><path d="M33 60 L87 52 M33 69 L87 61" stroke-width="5"/></g>
<g class="fM fM4"><path d="M38 34 L60 60 L82 34 M60 60 V90" stroke-width="9"/><path d="M42 66 H78 M42 78 H78" stroke-width="5"/></g>
</g>
</svg>`;
V=V.replace('width="300" height="300"','width="100%" height="100%"');F=F.replace('width="300" height="300"','width="100%" height="100%"');
var B=[['','Оплаты'],['','Подготовительные работы'],['','']];
var h='<style>.dbc{position:absolute;left:6px;top:'+Math.min(cy-120,innerHeight-250)+'px;display:flex;flex-direction:column;align-items:center;gap:8px;width:80px}.dbb{position:relative;pointer-events:auto;width:72px;height:72px;padding:0;box-sizing:border-box;border-radius:50%;border:0;background:none;color:#6A5BD6;font-size:20px;cursor:pointer;opacity:0;transition:opacity .5s,width .2s,height .2s;box-shadow:none}.dbb.sh{opacity:1}.dbb svg{width:100%;height:100%;display:block;pointer-events:none}.dbb.on{width:80px;height:80px}.dbb canvas{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}.dbb:after{content:"";position:absolute;inset:-16px;border-radius:50%;background:radial-gradient(circle,rgba(106,91,214,.95) 1px,transparent 1.6px) 0 0/6px 6px;opacity:0;pointer-events:none;display:none}@keyframes dbp{55%{opacity:.85}to{opacity:1;filter:blur(0);transform:none}}@keyframes dbd{0%{opacity:.95;transform:scale(1.7)}100%{opacity:0;transform:scale(1)}}</style><div class="dbc">';
B.forEach(function(b,i){h+='<button class="dbb'+(i==0?' on':'')+'" title="'+b[1]+'" style="animation-delay:'+(i*120)+'ms" onclick="var a=this.parentNode.children;for(var k=1;k<a.length;k++)a[k].classList.remove(\'on\');this.classList.add(\'on\')">'+b[0]+'</button>';});
return h+'</div>';}
function openStruct(){
if(sw!==null){return;}
if(ov!==null){var _o=ov;closeAll();_o.style.display='none';}
if(tw!==null){var _t=tw;closeTeam();_t.style.display='none';}
var pv=document.querySelector('.buttons button.nav-active');
window._structPrev=(pv&&pv.id!=='structureBtn')?pv:null;
document.querySelectorAll('.buttons button').forEach(function(x){x.classList.remove('nav-active');});
var sb=document.getElementById('structureBtn');if(sb){sb.classList.add('nav-active');}
sw=document.createElement('div');sw.id='structWin';sw.className='upm-win';
sw.style.cssText='left:104px;width:calc(70vw - 104px);padding:0;z-index:2001;border:0;overflow:auto;';
sw.style.cssText='left:104px;top:0;bottom:0;width:340px;padding:0;z-index:2001;border:0;overflow:visible;background:none!important;box-shadow:none!important;clip-path:none!important;pointer-events:none;';if(window.DB_OLD===true){sw.innerHTML=STRUCT_DEFS+structListHtml();structBind(sw);structUpd(sw);}else{sw.innerHTML=dbBtnsHtml();}document.body.appendChild(sw);void sw.offsetWidth;if(window.DB_OLD!==true){dbDust(sw,'in');if(window.dbMount){dbMount(sw);}}
setTimeout(function(){if(sw){sw.classList.add('on');}},20);
}
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
var t=e.target.closest('#structureBtn');
if(t){var _an=t.querySelectorAll('animateTransform');for(var _i=0;_i<_an.length;_i++){try{_an[_i].beginElement();}catch(_x){}}
e.stopPropagation();e.preventDefault();
if(sw===null){if(Date.now()-(window._structLastClose||0)<560){return;}openStruct();}else{closeStruct();}return;}
if(sw!==null&&e.target.closest('.buttons button')){closeStruct(true);}
},true);
function closeTeam(){
if(tw===null){return;}
var o=tw;tw=null;o.classList.remove('on');
var tb=document.getElementById('teamBtn');if(tb){tb.classList.remove('nav-active');}
if(window._teamPrev){window._teamPrev.classList.add('nav-active');window._teamPrev=null;}
window._teamLastClose=Date.now();
setTimeout(function(){o.remove();},520);
}
function openTeam(){
if(tw!==null){return;}
if(ov!==null){var _o=ov;closeAll();_o.style.display='none';}
var pv=document.querySelector('.buttons button.nav-active');
window._teamPrev=(pv&&pv.id!=='teamBtn')?pv:null;
document.querySelectorAll('.buttons button').forEach(function(x){x.classList.remove('nav-active');});
var tb=document.getElementById('teamBtn');if(tb){tb.classList.add('nav-active');}
tw=document.createElement('div');tw.id='teamWin';tw.className='upm-win';
tw.style.cssText='left:104px;width:420px;padding:0;z-index:2001;border:0;overflow:auto;';tw.innerHTML=teamBdHtml()+teamListHtml();var _tb=tw.querySelector('#teamBd');if(_tb){_tb.style.position='sticky';_tb.style.top='0';_tb.style.zIndex='5';
var _in=document.createElement('input');_in.type='text';_in.placeholder='Поиск...';
_in.style.cssText='position:absolute;top:9px;right:12px;width:150px;height:24px;border:0;border-radius:12px;padding:0 10px;font-size:11px;outline:none;background:rgba(255,255,255,0.92);color:#1f2937;z-index:3;box-sizing:border-box;';
_in.oninput=function(){var q=_in.value.toLowerCase().trim();var L=tw.lastElementChild;if(!L){return;}Array.prototype.forEach.call(L.children,function(w){var t=w.getAttribute('data-s')||'';w.style.display=(!q||t.indexOf(q)>=0)?'':'none';});};
_tb.appendChild(_in);var _bb=tw.querySelector('#teamBdBody');if(_bb){_bb.style.marginTop='14px';}}
document.body.appendChild(tw);void tw.offsetWidth;
setTimeout(function(){if(tw){tw.classList.add('on');}},20);
}
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
var t=e.target.closest('#teamBtn');if(t){var _an=t.querySelectorAll('animateTransform');for(var _i=0;_i<_an.length;_i++){try{_an[_i].beginElement();}catch(_x){}}}
if(t){e.stopPropagation();e.preventDefault();if(tw===null){if(Date.now()-(window._teamLastClose||0)<560){return;}openTeam();}else{closeTeam();}return;}
if(tw!==null&&e.target.closest('.buttons button')&&!e.target.closest('#upmoBtn')){closeTeam();}
},true);
document.addEventListener('click',function(e){
if(window.innerWidth<=768){return;}
var b=e.target.closest('#upmoBtn');
if(b){if(ov===null){openAll();}else if(A.classList.contains('on')){if(B.classList.contains('on')){A.classList.remove('on');}else{closeAll();}}else{A.classList.add('on');}return;}
if(ov&&!window._upmoMapInit&&e.target.closest('.buttons button')){closeAll();}
},true);
})();
