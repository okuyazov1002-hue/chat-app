(function(){
if(document.getElementById('aiBtn')){return;}
var st=document.createElement('style');
st.textContent='#aiBtn{position:fixed;right:20px;bottom:20px;width:52px;height:52px;border:0;border-radius:50%;cursor:pointer;z-index:3000;color:#fff;font-size:22px;background:linear-gradient(135deg,#6A5BD6,#5B94D0 60%,#5FD2B0);box-shadow:0 4px 14px rgba(0,0,0,.25);}#aiWin{position:fixed;right:20px;bottom:16px;width:380px;max-width:calc(100vw - 40px);height:520px;max-height:calc(100vh - 32px);background:#fff;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.25);z-index:3000;display:flex;flex-direction:column;overflow:hidden;opacity:0;transform:translateY(16px) scale(.97);pointer-events:none;transition:opacity .3s ease,transform .3s cubic-bezier(.22,1,.36,1);}#aiWin.on{opacity:1;transform:none;pointer-events:auto;}#aiHead{padding:12px 16px;color:#fff;font-size:13px;font-weight:700;background:linear-gradient(135deg,#6A5BD6,#5B94D0 60%,#5FD2B0);}#aiMsgs{flex:1;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:8px;background:#f6f7fb;}.ai-m{max-width:85%;padding:8px 12px;border-radius:12px;font-size:12px;line-height:1.45;white-space:pre-wrap;word-break:break-word;box-shadow:0 1px 4px rgba(0,0,0,.08);}.ai-u{align-self:flex-end;background:#5B94D0;color:#fff;}.ai-a{align-self:flex-start;background:#fff;color:#1f2937;}#aiForm{display:flex;align-items:center;gap:8px;padding:10px;border-top:1px solid #eef0f3;}#aiIn{flex:1;height:34px;border:1px solid #e5e7eb;border-radius:17px;padding:0 12px;font-size:12px;outline:none;}#aiSend{flex:0 0 34px;width:34px;height:34px;padding:0;border:0;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#6A5BD6,#5B94D0);}';
document.head.appendChild(st);
var btn=document.createElement('button');btn.id='aiBtn';btn.title='Ассистент';btn.innerHTML='&#10024;';
var w=document.createElement('div');w.id='aiWin';
w.innerHTML='<div id="aiHead">Ассистент UPMO</div><div id="aiMsgs"></div><form id="aiForm"><input id="aiIn" type="text" placeholder="Вопрос по сайту или проектам..." autocomplete="off"><button id="aiSend" type="submit" title="Отправить"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13"/><path d="M22 2L15 22l-4-9-9-4 20-7z"/></svg></button></form>';
btn.style.display='none';var _f=document.createElement('link');_f.rel='stylesheet';_f.href='https://fonts.googleapis.com/css2?family=Nunito:wght@900&display=swap';document.head.appendChild(_f);document.body.appendChild(btn);document.body.appendChild(w);
var nb=document.getElementById('aiNavBtn');if(nb){nb.addEventListener('click',function(){btn.onclick();});}
var box=w.querySelector('#aiMsgs'),inp=w.querySelector('#aiIn'),hist=[],busy=false;
function add(t,c){var d=document.createElement('div');d.className='ai-m '+c;d.textContent=t;box.appendChild(d);box.scrollTop=box.scrollHeight;return d;}
add('Здравствуйте! Спрашивайте по сайту и проектам.','ai-a');
btn.onclick=function(){w.classList.toggle('on');if(w.classList.contains('on')){inp.focus();}};
w.querySelector('#aiForm').onsubmit=function(e){e.preventDefault();var q=inp.value.trim();if(!q||busy){return;}
inp.value='';add(q,'ai-u');hist.push({role:'user',content:q});busy=true;var p=add('Думаю...','ai-a');
fetch('/api/assistant',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:hist})}).then(function(r){return r.json().then(function(j){return {ok:r.ok,j:j};});}).then(function(x){
var t=x.ok?x.j.reply:(x.j.error||'Ошибка');p.textContent=t;if(x.ok){hist.push({role:'assistant',content:t});}busy=false;box.scrollTop=box.scrollHeight;
}).catch(function(){p.textContent='Нет связи с сервером';busy=false;});};
})();
