p="public/main.html"
s=open(p,encoding="utf-8").read()
k='id="upmoBlk3"'
sh="-5px -5px 16px rgba(106,90,224,0.45),5px 5px 16px rgba(29,211,176,0.45),0 0 18px rgba(74,144,217,0.4)"
if s.count(k)!=1:
    print("ANCHOR_COUNT",s.count(k))
else:
    i=s.index(k)
    j=s.find(sh,i)
    e=s.index("</div>",i)
    if j<0 or j>e:
        print("SHADOW_NOT_FOUND")
    else:
        s=s[:j]+"0 2px 14px rgba(0,0,0,0.2)"+s[j+len(sh):]
        open(p,"w",encoding="utf-8").write(s);print("PATCHED")
