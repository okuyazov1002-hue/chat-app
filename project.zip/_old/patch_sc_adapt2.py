p="public/upmo-scurve.js"
s=open(p,encoding="utf-8").read()
m1="H=(function(){var pn=el.closest"
m2="})(),pt=28,pb=28;"
if s.count(m1)!=1 or s.count(m2)!=1:
    print("ANCHOR_COUNT",s.count(m1),s.count(m2))
else:
    i=s.index(m1);j=s.index(m2)+len("})()")
    s=s[:i]+"H=Math.max(200,Math.min(450,window.innerHeight-618))"+s[j:]
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
