p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
a="+bar(oh,opl,of)+"
b="+"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
