p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("pin.style.marginLeft='0px';",
 "pin.style.marginLeft='0px';pin.style.transitionDelay='0.4s';if(mw){mw.style.transitionDelay='0s';}"),
("var mm=ov.querySelector('.stage-modal');if(mm){mm.style.transform='translateX(0)';",
 "pin.style.transitionDelay='0s';var mm=ov.querySelector('.stage-modal');if(mm){mm.style.transitionDelay='0.35s';mm.style.transform='translateX(0)';")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
