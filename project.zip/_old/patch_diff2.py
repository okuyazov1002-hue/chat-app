p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a = r"""stroke-dasharray="4 3" stroke-linecap="round"/>';"""
b = r"""stroke-dasharray="4 3" stroke-linecap="round"/>';s+='<text x="'+(cx-8)+'" y="'+((Y(pv)+Y(fv))/2+3)+'" text-anchor="end" font-size="9" font-weight="700" fill="#ef4444" stroke="#fff" stroke-width="3" paint-order="stroke">'+(pv>=fv?'−':'+')+cm(Math.abs(pv-fv))+' ('+Math.round(Math.abs(pv-fv)/total*100)+'%)</text>';"""
n = s.count(a)
if n == 1:
    open(p, "w", encoding="utf-8").write(s.replace(a, b))
    print("PATCHED")
else:
    print("ANCHOR_COUNT", n)
