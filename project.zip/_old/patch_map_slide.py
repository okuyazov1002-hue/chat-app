p="public/upmo-map.js"
s=open(p,encoding="utf-8").read()
a1="#upmoMapBlk #mapInfo{display:none !important;}#upmoMapBlk.su-obj #mapInfo{display:flex !important;"
b1="#upmoMapBlk #mapInfo{transform:translateX(110%);transition:transform .4s cubic-bezier(.22,1,.36,1);}#upmoMapBlk.su-obj #mapInfo{transform:translateX(0);}#upmoMapBlk #mapInfo.su-hold{transform:translateX(110%) !important;transition:none !important;}#upmoMapBlk #mapInfo{display:flex !important;"
a2="st.obs=new MutationObserver(sync);st.obs.observe(mi,{attributes:true,attributeFilter:['style']});sync();}"
b2=r"""function ghostOut(){
if(!st.snap){return;}
var g=st.snap;g.removeAttribute('id');
var ids=g.querySelectorAll('[id]');for(var q=0;q<ids.length;q++){ids[q].removeAttribute('id');}
g.style.cssText='position:absolute;right:0;left:auto;top:0;bottom:0;width:'+mi.offsetWidth+'px;margin:0;z-index:1001;background:#fff;box-shadow:-6px 0 18px rgba(0,0,0,0.25);display:flex;transform:translateX(0);transition:transform .35s ease;overflow:hidden;';
blk.appendChild(g);void g.offsetWidth;g.style.transform='translateX(110%)';
setTimeout(function(){g.remove();},400);
st.snap=null;
}
st.obs=new MutationObserver(function(recs){
var open=parseInt(mi.style.width)>460;
var had=blk.classList.contains('su-obj');
var styleRec=recs.some(function(r){return r.type==='attributes';});
if(styleRec&&open&&had&&st.snap){
mi.classList.add('su-hold');ghostOut();
setTimeout(function(){mi.classList.remove('su-hold');},380);
}else if(open&&!had){blk.classList.add('su-obj');}
else if(!open&&had){
mi.classList.add('su-hold');blk.classList.remove('su-obj');ghostOut();
setTimeout(function(){mi.classList.remove('su-hold');},380);
}
clearTimeout(st.snapT);
st.snapT=setTimeout(function(){if(parseInt(mi.style.width)>460){st.snap=mi.cloneNode(true);}},500);
});
st.obs.observe(mi,{attributes:true,attributeFilter:['style'],childList:true,subtree:true});
}"""
ok=True
for a in (a1,a2):
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:60])
if ok:
    s=s.replace(a1,b1).replace(a2,b2)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
