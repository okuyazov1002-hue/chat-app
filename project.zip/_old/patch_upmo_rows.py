p="public/main.html"
s=open(p,encoding="utf-8").read()
a="16px 10px 16px rgba(0,0,0,0.08);\"></div>';\ndocument.body.appendChild(ov);"
def row(t):
    return '<div class="ml-card0"><div class="ml-row" style="display:flex;align-items:center;padding:9px 10px 9px 12px;cursor:pointer;text-align:left;font-size:11px;font-weight:700;color:#1f2937;"><span style="width:12px;min-width:12px;flex-shrink:0;color:#6b7280;">&#9656;</span><span>'+t+'</span></div></div>'
rows=row("Подготовительные работы")+row("Основные проекты")+row("Вспомогательные проекты")
b="16px 10px 16px rgba(0,0,0,0.08);\"><div style=\"padding:16px;display:flex;flex-direction:column;gap:12px;\">"+rows+"</div></div>';\ndocument.body.appendChild(ov);"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
