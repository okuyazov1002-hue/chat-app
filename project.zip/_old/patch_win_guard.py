p="public/upmo-win.js"
s=open(p,encoding="utf-8").read()
pairs=[
("ov=document.createElement('div');ov.id='upmoWin';",
 "if(Date.now()-(window._upmoLastClose||0)<560){return;}\nov=document.createElement('div');ov.id='upmoWin';"),
("var o=ov,a=A,b=B;ov=null;",
 "window._upmoLastClose=Date.now();\nvar o=ov,a=A,b=B;ov=null;"),
("if(window.upmoMapRestore){window.upmoMapRestore();}},520);",
 "if(ov===null&&window.upmoMapRestore){window.upmoMapRestore();}},520);")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
