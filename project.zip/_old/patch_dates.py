p="public/main.html"
s=open(p,encoding="utf-8").read()
a_f="if(window.upmoCal){window.upmoCal(document.getElementById('upmoBlk4a'));}"
b_f=a_f+"\nif(window.upmoDates){window.upmoDates(document.getElementById('upmoBlk4b1'),t);}"
a_s='<script src="upmo-cal.js"></script>'
b_s=a_s+'\n<script src="upmo-dates.js"></script>'
c=[s.count(a_f),s.count(a_s)]
if c!=[1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a_f,b_f).replace(a_s,b_s)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
