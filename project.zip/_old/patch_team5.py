p="public/mobile-info.js"
s=open(p,encoding="utf-8").read()
pairs=[
('min-width:0;flex:1;"><div style="font-size:12px','min-width:0;flex:1;display:flex;align-items:center;gap:8px;"><div style="flex:1;min-width:0;font-size:12px'),
('color:#6b7280;margin-top:2px;','color:#6b7280;flex-shrink:0;'),
('color:#4a9fd8;margin-top:1px;','color:#4a9fd8;flex-shrink:0;min-width:62px;text-align:right;')
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:40])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
