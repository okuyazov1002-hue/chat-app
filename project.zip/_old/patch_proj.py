p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("if(window.upmoMonths){window.upmoMonths(document.getElementById('upmoMo'),t);}",
 "if(window.upmoMonths){window.upmoMonths(document.getElementById('upmoMo'),t);}\nif(window.upmoProj){window.upmoProj(document.getElementById('upmoBlk3'),t);}"),
('<script src="upmo-icon.js"></script>','<script src="upmo-icon.js"></script>\n<script src="upmo-proj.js"></script>')
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:60])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
