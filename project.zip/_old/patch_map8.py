p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("      allMarkers.forEach(function(m){if(leafMap.hasLayer(m)) leafMap.removeLayer(m);});\n      refreshMap();\n    }\n    function closeObj(){",
 "      var sel=null;if(isNarrow()){var mm=/data-code=\"([^\"]+)\"/.exec(html);if(mm)sel=mm[1];}\n      Object.keys(prepPolys).forEach(function(k){if(sel==null||k==sel){prepGroup.addLayer(prepPolys[k]);}else{prepGroup.removeLayer(prepPolys[k]);}});\n      allMarkers.forEach(function(m){if(sel!=null&&m._code==sel){if(leafMap.hasLayer(m)==false) prepGroup.addLayer(m);}else if(leafMap.hasLayer(m)) leafMap.removeLayer(m);});\n      refreshMap();\n    }\n    function closeObj(){"),
("renderMapList();\n      allMarkers.forEach(function(m){var g=",
 "renderMapList();\n      Object.keys(prepPolys).forEach(function(k){prepGroup.addLayer(prepPolys[k]);});\n      allMarkers.forEach(function(m){var g="),
("pm._grp=prepGroup;allMarkers.push(pm);",
 "pm._grp=prepGroup;pm._code=o[0];allMarkers.push(pm);")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
