import re
p="public/main.html"
s=open(p,encoding="utf-8").read()
def ks(n): return ";".join([".4 0 .2 1"]*n)
def anim(attr,vals,dur):
    v=vals.split(";"); n=len(v)-1
    kt=";".join(str(round(i/n,3)) for i in range(n+1))
    return '<animate attributeName="%s" values="%s" keyTimes="%s" dur="%s" begin="indefinite" calcMode="spline" keySplines="%s"/>'%(attr,vals,kt,dur,ks(n))
def bar(x,y,h,yv,hv,dur):
    return '<rect x="%d" y="%d" width="11" height="%d" rx="2.5">%s%s</rect>'%(x,y,h,anim("y",yv,dur),anim("height",hv,dur))
def ring(r,sw,extra,rot,col):
    return '<g><animateTransform attributeName="transform" type="rotate" values="%s" keyTimes="0;1" dur="1.2s" begin="indefinite" calcMode="spline" keySplines=".4 0 .2 1"/><circle cx="60" cy="60" r="52" fill="none" stroke="%s" stroke-width="9" stroke-linecap="round" stroke-dasharray="%s" transform="rotate(%d 60 60)"/></g>'%(rot,col,extra,r)
svg=('<svg width="34" height="34" viewBox="0 0 120 120" aria-label="UPMO"><defs>'
'<linearGradient id="ubArc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient>'
'<linearGradient id="ubBarsG" gradientUnits="userSpaceOnUse" x1="0" y1="38" x2="0" y2="88"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient>'
'<clipPath id="ubBars">'
+bar(34,42,42,"42;66;42","42;18;42","1.2s")
+bar(49,55,29,"55;40;55","29;44;29","1.0s")
+bar(64,66,18,"66;76;56;66","18;8;28;18","1.4s")
+bar(79,74,10,"74;46;74","10;38;10","1.1s")
+'</clipPath></defs>'
+ring(180,9,"78 249","0 60 60;360 60 60","#6A5BD6")
+ring(285,9,"205 122","0 60 60;-360 60 60","url(#ubArc)")
+'<g clip-path="url(#ubBars)"><rect x="30" y="38" width="64" height="50" fill="url(#ubBarsG)"/><polygon points="34,42 45,42 45,84" fill="#fff" fill-opacity="0.22"/><polygon points="49,55 60,55 60,84" fill="#fff" fill-opacity="0.22"/><polygon points="64,66 75,66 75,84" fill="#fff" fill-opacity="0.22"/><polygon points="79,74 90,74 90,84" fill="#fff" fill-opacity="0.22"/></g></svg>')
btn='<button id="upmoBtn" title="UPMO" onclick="this.querySelectorAll(\'animate,animateTransform\').forEach(function(a){a.beginElement();})">'+svg+'</button>'
pat=re.compile(r'<button id="upmoBtn" title="UPMO">.*?</button>',re.S)
m=pat.findall(s)
if len(m)!=1:
    print("ANCHOR_COUNT",len(m))
else:
    s=pat.sub(lambda x:btn,s)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
