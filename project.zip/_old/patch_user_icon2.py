p="public/main.html"
s=open(p,encoding="utf-8").read()
tag='<button id="settingsBtn" title="Добавить пользователя">'
if s.count(tag)!=1:
    print("ANCHOR_COUNT",s.count(tag))
else:
    i=s.index(tag)+len(tag)
    j=s.index('</svg>',i)+6
    svg=('<svg width="38" height="38" viewBox="0 0 120 120" fill="none">'
    '<defs>'
    '<linearGradient id="suRing" gradientUnits="userSpaceOnUse" x1="0" y1="8" x2="0" y2="112"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient>'
    '<linearGradient id="suBody" gradientUnits="userSpaceOnUse" x1="0" y1="34" x2="0" y2="86"><stop offset="0" stop-color="#6A5BD6"/><stop offset="1" stop-color="#5B94D0"/></linearGradient>'
    '<linearGradient id="suBadge" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient>'
    '</defs>'
    '<path class="su-s" d="M12.18 64.18 A48 48 0 1 1 46.77 106.14" stroke="currentColor" stroke-width="9" stroke-linecap="round"/>'
    '<polygon class="su-s su-f" points="43.5,117.7 50.1,94.6 31.5,96.6" fill="currentColor" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>'
    '<circle class="su-f" cx="60" cy="45" r="12" fill="currentColor"/>'
    '<path class="su-s su-f" d="M37 84 C37 68 47 62 60 62 C73 62 83 68 83 84 Z" fill="currentColor" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>'
    '<circle class="su-b" cx="17" cy="85" r="12" fill="#fff"/>'
    '<g class="su-plus"><path class="su-p" d="M17 79 V91 M11 85 H23" stroke="#4a90d9" stroke-width="4" stroke-linecap="round"/></g>'
    '<g transform="translate(17 85)"><g class="su-cur"><path d="M0 0 L0 22 L6 17 L10 26 L14 24 L10 15 L18 15 Z" fill="#fff" stroke="#1f2937" stroke-width="2" stroke-linejoin="round"/></g></g>'
    '</svg>')
    s=s[:i]+svg+s[j:]
    open(p,"w",encoding="utf-8").write(s);print("PATCHED main")
q="public/upmo-icon.js"
t=open(q,encoding="utf-8").read()
a="document.head.appendChild(st);"
if t.count(a)!=1:
    print("ANCHOR_COUNT js",t.count(a))
else:
    add=("var st2=document.createElement('style');"
    "st2.textContent='#settingsBtn.nav-active .su-s{stroke:url(#suRing);}#settingsBtn.nav-active .su-f{fill:url(#suBody);}#settingsBtn.nav-active .su-b{fill:url(#suBadge);}#settingsBtn.nav-active .su-p{stroke:#fff;}';"
    "document.head.appendChild(st2);")
    open(q,"w",encoding="utf-8").write(t.replace(a,a+"\n"+add));print("PATCHED js")
