p="public/main.html"
s=open(p,encoding="utf-8").read()
a="layersCtl.addOverlay(prepGroup,'Подготовительные работы');"
b=a+"if(window.innerWidth<=768){leafMap.removeLayer(newGroup);layersCtl.remove();}"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
