p="public/main.html"
s=open(p,encoding="utf-8").read()
g='<g transform="translate(17 85)">'
r1='<path class="su-s" d="M12.18'
r2='<polygon class="su-s su-f"'
if s.count(g)!=1 or s.count(r1)!=1 or s.count(r2)!=1:
    print("ANCHOR_COUNT",s.count(g),s.count(r1),s.count(r2))
else:
    i=s.index(g);j=s.index('</g></g>',i)+8
    s=s[:i]+s[j:]
    s=s.replace(r1,'<path class="su-s su-ring" pathLength="100" d="M12.18')
    s=s.replace(r2,'<polygon class="su-s su-f su-arr"')
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
