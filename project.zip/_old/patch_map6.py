p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("L.control.layers({'Спутник':sat,'Схема':osm},{}).addTo(leafMap)",
 "L.control.layers((window.innerWidth<=768?{'Спутник':sat}:{'Спутник':sat,'Схема':osm}),{}).addTo(leafMap)"),
("if(leafMap.hasLayer(newGroup)){\n        ['main','aux']",
 "if(leafMap.hasLayer(newGroup)&&!isNarrow()){\n        ['main','aux']")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:40])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
