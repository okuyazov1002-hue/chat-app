def patch(p, a, b):
    s = open(p, encoding="utf-8").read()
    n = s.count(a)
    if n == 1:
        open(p, "w", encoding="utf-8").write(s.replace(a, b))
        print("PATCHED", p)
    else:
        print("ANCHOR_COUNT", n, p)

a1 = r"""app.get("/api/prep/object/:code/worklist", async (req, res) => {"""
b1 = r"""app.get("/api/prep/object/:code/term", async (req, res) => {
  try {
    const code = req.params.code;
    const report = await mongoose.connection.db.collection("reports").findOne({ code });
    const rows = (report && report.rows) ? report.rows : [];
    let start = null, end = null, cost = 0, done = 0;
    rows.forEach(r => {
      cost += r.cost || 0; done += r.done || 0;
      if (r.planStart) { const d = new Date(r.planStart); if (isNaN(d) == false && (start == null || d < start)) start = d; }
      if (r.planEnd) { const d = new Date(r.planEnd); if (isNaN(d) == false && (end == null || d > end)) end = d; }
    });
    const curve = await mongoose.connection.db.collection("data").findOne({ _id: "prep_cost_curve_" + code });
    const today = new Date();
    let delay = 0;
    if (start != null && end != null && cost > 0 && done < cost * 0.999) {
      let dateF = null;
      const v = curve ? (curve.value || {}) : {};
      const labels = v.labels || [], per = v.planPer || [];
      if (labels.length > 0) {
        let cum = 0;
        for (let i = 0; i < labels.length; i++) {
          const m = per[i] || 0;
          if (cum + m >= done) {
            const parts = String(labels[i]).split("-");
            const ms = new Date(Number(parts[0]), Number(parts[1]) - 1, 1);
            const me = new Date(Number(parts[0]), Number(parts[1]), 1);
            const frac = m > 0 ? (done - cum) / m : 0;
            dateF = new Date(ms.getTime() + frac * (me.getTime() - ms.getTime()));
            break;
          }
          cum += m;
        }
      } else {
        dateF = new Date(start.getTime() + (done / cost) * (end.getTime() - start.getTime()));
      }
      if (dateF != null) { delay = Math.max(0, Math.round((today.getTime() - dateF.getTime()) / 86400000)); }
    }
    const forecast = end ? new Date(end.getTime() + delay * 86400000) : null;
    res.json({ start, end, forecast, delay });
  } catch (err) {
    res.status(500).json({ message: "Ошибка сервера: " + err.message });
  }
});
app.get("/api/prep/object/:code/worklist", async (req, res) => {"""
patch("server.js", a1, b1)

a2 = r"""st('dsOR',c-d);}).catch(function(){});"""
b2 = r"""st('dsOR',c-d);}).catch(function(){});
op.insertAdjacentHTML('beforeend','<div style="margin-top:8px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);padding:12px 12px 14px;"><div style="font-size:12px;font-weight:700;color:#fff;margin-bottom:10px;">Сроки</div><div style="display:flex;gap:8px;">'+blk('Начало','dsTS')+blk('Окончание','dsTE')+blk('Прогноз','dsTF')+blk('Срок','dsTD')+'</div></div>');
fetch('/api/prep/object/'+encodeURIComponent(code)+'/term').then(function(x){return x.json();}).then(function(t){function fd(v){if(v==null){return '—';}var q=new Date(v);return ('0'+q.getDate()).slice(-2)+'.'+('0'+(q.getMonth()+1)).slice(-2)+'.'+q.getFullYear();}function put(id,v,c){var e=document.getElementById(id);if(e){e.textContent=v;if(c){e.style.color=c;}}}var bad=t.delay>0;put('dsTS',fd(t.start));put('dsTE',fd(t.end));put('dsTF',fd(t.forecast),bad?'#b91c1c':'#166534');put('dsTD',t.delay+' дн.',bad?'#b91c1c':'#166534');}).catch(function(){});"""
patch("public/mobile-info.js", a2, b2)
