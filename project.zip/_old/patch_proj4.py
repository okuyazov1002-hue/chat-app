p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
a="""el.innerHTML='<div style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:#1f2937;padding:0 4px 8px;"><span>Проекты</span>'+pills(tot.c>0,tpl,tf)+'</div>'+h;"""
b="el.innerHTML=h;"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
