p="public/mobile-info.js"
s=open(p,encoding="utf-8").read()
a="height:42px;margin-bottom:-29px"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,"height:38px;margin-bottom:-25px"));print("PATCHED")
