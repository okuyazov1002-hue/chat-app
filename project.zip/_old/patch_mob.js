const fs = require("fs");
let s = fs.readFileSync("server.js", "utf8");
const a = '    const mobSheet = wb.addWorksheet("Mobilization");';
const n = s.split(a).length - 1;
if (n == 1) {
  const b = '    const mobDocs = await mongoose.connection.db.collection("data").find({ _id: { $regex: "^prep_mobilization_" } }).toArray();\n    mobDocs.forEach(md => {\n      if (reports.some(r => r.code == md.code) == false) return;\n      const v = md.value || {};\n      (v.labels || []).forEach((k, i) => {\n        mobByMonth[k] = mobByMonth[k] || { plan: 0, fact: 0 };\n        mobByMonth[k].plan += (v.plan || [])[i] || 0;\n        mobByMonth[k].fact += (v.fact || [])[i] || 0;\n      });\n    });\n' + a;
  fs.writeFileSync("server.js", s.split(a).join(b));
  console.log("PATCHED");
} else {
  console.log("ANCHOR_COUNT", n);
}
