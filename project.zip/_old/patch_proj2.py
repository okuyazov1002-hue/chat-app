p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
pairs=[
("""<span class="ar" style="width:10px;">&#9656;</span>""",""),
("+dates(st,en,has)+bar(has,ppl,pf)+'</div>","+dates(st,en,has)+'</div>")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:60])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
