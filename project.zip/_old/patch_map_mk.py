p="public/upmo-map.js"
s=open(p,encoding="utf-8").read()
a="#upmoMapBlk .leaflet-control-layers{display:none !important;}"
b="#upmoMapBlk .leaflet-control-layers,#upmoMapBlk .leaflet-marker-pane,#upmoMapBlk .leaflet-shadow-pane,#upmoMapBlk .leaflet-tooltip-pane,#upmoMapBlk .leaflet-popup-pane{display:none !important;}"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
