p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
pairs = [
 (r"""var W=nb.clientWidth||380;var H=170;var pl=46;var pr=16;var pt=24;var pb=26;""",
  r"""var W=nb.clientWidth||380;var H=170;var pl=14;var pr=14;var pt=24;var pb=26;"""),
 (r"""stroke-width="1"/><text x="'+(pl-6)+'" y="'+(y+3)+'" text-anchor="end" font-size="8" fill="#6b7280">'+((g==0)?'0':cm(top*g))+'</text>';});""",
  r"""stroke-width="1"/>';});"""),
 (r"""var step=Math.ceil(n/6);""",
  r"""var step=Math.max(1,Math.ceil(14/((W-pl-pr)/(n-1))));"""),
 (r"""for(var i2=0;i2<n;i2+=step){var k=String(sc.labels[i2]);s+='<text x="'+X(i2)+'" y="'+(H-8)+'" text-anchor="middle" font-size="8" fill="#6b7280">'+k.slice(5)+'.'+k.slice(2,4)+'</text>';}""",
  r"""for(var i2=0;i2<n;i2+=step){var k=String(sc.labels[i2]);var mm2=k.slice(5);s+='<text x="'+X(i2)+'" y="'+(H-18)+'" text-anchor="middle" font-size="8" fill="#6b7280">'+mm2+'</text>';if(i2==0||mm2=='01'){s+='<text x="'+X(i2)+'" y="'+(H-7)+'" text-anchor="middle" font-size="8" fill="#9ca3af">'+k.slice(0,4)+'</text>';}}""")
]
ok = True
for a, b in pairs:
    n = s.count(a)
    if n != 1:
        ok = False
        print("ANCHOR_COUNT", n, a[:50])
if ok:
    for a, b in pairs:
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
    print("PATCHED")
