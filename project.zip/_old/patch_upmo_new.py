p="public/main.html"
s=open(p,encoding="utf-8").read()
a1="document.addEventListener('click',function(e){\nvar b=e.target.closest('#upmoBtn');"
b1="document.addEventListener('click',function(e){\nif(window.innerWidth>768){return;}\nvar b=e.target.closest('#upmoBtn');"
a2="</body>"
b2='<script src="upmo-win.js"></script>\n</body>'
n1=s.count(a1);n2=s.count(a2)
if n1!=1 or n2!=1:
    print("ANCHOR_COUNT",n1,n2)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a1,b1).replace(a2,b2));print("PATCHED")
