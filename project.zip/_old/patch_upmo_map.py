def patch(p,pairs):
    s=open(p,encoding="utf-8").read()
    ok=True
    for a,b in pairs:
        n=s.count(a)
        if n!=1:
            ok=False;print("ANCHOR_COUNT",p,n,a[:50])
    if ok:
        for a,b in pairs: s=s.replace(a,b)
        open(p,"w",encoding="utf-8").write(s);print("PATCHED",p)
patch("public/main.html",[
('<div style="padding:16px;display:flex;gap:16px;align-items:flex-start;"><div id="upmoCard" style="flex:0 0 400px;',
 '<div style="padding:16px;display:flex;gap:16px;align-items:stretch;"><div style="flex:0 0 400px;display:flex;flex-direction:column;gap:16px;"><div id="upmoCard" style="'),
('Загрузка...</div><div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:16px;">',
 'Загрузка...</div><div id="upmoMapBlk" style="flex:1;min-height:260px;border-radius:16px;overflow:hidden;position:relative;background:#e5e7eb;box-shadow:-5px -5px 16px rgba(106,90,224,0.45),5px 5px 16px rgba(29,211,176,0.45),0 0 18px rgba(74,144,217,0.4);"></div></div><div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:16px;">'),
("if(window.upmoMonths){window.upmoMonths(document.getElementById('upmoMo'),t);}",
 "if(window.upmoMonths){window.upmoMonths(document.getElementById('upmoMo'),t);}\nif(window.upmoMap){window.upmoMap(document.getElementById('upmoMapBlk'));}"),
('<script src="upmo-sync.js"></script>','<script src="upmo-sync.js"></script>\n<script src="upmo-map.js"></script>')
])
patch("public/upmo-win.js",[
("setTimeout(function(){o.remove();},520);",
 "setTimeout(function(){o.remove();if(window.upmoMapRestore){window.upmoMapRestore();}},520);")
])
