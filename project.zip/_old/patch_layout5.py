p="public/main.html"
s=open(p,encoding="utf-8").read()
a="pin.innerHTML='"
if s.count(a)!=1:
    print("ANCHOR_COUNT",s.count(a))
else:
    i=s.index(a);j=s.index("\n",i)
    sh="-5px -5px 16px rgba(106,90,224,0.45),5px 5px 16px rgba(29,211,176,0.45),0 0 18px rgba(74,144,217,0.4)"
    gr="linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%)"
    new=("pin.innerHTML='<div style=\"padding:16px;display:flex;flex-direction:column;gap:16px;\">"
    "<div style=\"display:flex;gap:16px;align-items:flex-start;\">"
    "<div id=\"upmoCard\" style=\"flex:0 0 400px;box-sizing:border-box;box-shadow:"+sh+";border-radius:16px;padding:14px 16px;background:"+gr+";color:#fff;font-size:11px;\">Загрузка...</div>"
    "<div id=\"upmoMapBlk\" style=\"flex:0 0 400px;min-width:0;height:340px;border-radius:16px;overflow:hidden;position:relative;background:#e5e7eb;box-shadow:"+sh+";\"></div>"
    "<div id=\"upmoBlk3\" style=\"flex:1;min-width:0;height:340px;box-sizing:border-box;border-radius:16px;background:#fff;box-shadow:"+sh+";\"></div>"
    "</div>"
    "<div style=\"width:816px;max-width:100%;display:flex;flex-direction:column;gap:16px;\">"
    "<div id=\"upmoSc\" style=\"min-width:0;background:#fff;border-radius:16px;box-shadow:0 0 16px rgba(74,144,217,0.25);\"></div>"
    "<div id=\"upmoMo\" style=\"min-width:0;border-radius:16px;box-shadow:"+sh+";background:"+gr+";\"></div>"
    "</div></div>';")
    s=s[:i]+new+s[j:]
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
