p="public/upmo-win.js"
s=open(p,encoding="utf-8").read()
a="busy=true;\nA.classList.remove('on');"
b="busy=true;\nA.classList.remove('on');B.classList.remove('on');"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
