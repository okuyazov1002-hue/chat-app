p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a = r"""<div style="display:flex;align-items:center;justify-content:space-between;"><div style="font-size:11px;color:rgba(255,255,255,0.85);font-weight:700;">Общая стоимость</div><div id="dsMapBtn" style="background:rgba(255,255,255,0.5);border-radius:14px;padding:5px 12px;display:flex;align-items:center;gap:5px;font-size:11px;font-weight:700;color:#1f2937;box-shadow:0 2px 8px rgba(0,0,0,0.12);cursor:pointer;">"""
b = r"""<div style="display:flex;align-items:flex-start;justify-content:space-between;"><div style="font-size:11px;color:rgba(255,255,255,0.85);font-weight:700;">Общая стоимость</div><div id="dsMapBtn" style="background:rgba(255,255,255,0.5);border-radius:14px;padding:6px 10px;box-sizing:border-box;width:calc((100% - 12px)/3);height:42px;margin-bottom:-29px;display:flex;align-items:center;justify-content:center;gap:6px;font-size:12px;font-weight:700;color:#1f2937;box-shadow:0 2px 8px rgba(0,0,0,0.12);cursor:pointer;">"""
n = s.count(a)
if n == 1:
    open(p, "w", encoding="utf-8").write(s.replace(a, b))
    print("PATCHED")
else:
    print("ANCHOR_COUNT", n)
