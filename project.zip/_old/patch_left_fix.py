p="public/main.html"
s=open(p,encoding="utf-8").read()
a1='<div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:16px;"><div id="upmoCard"'
b1='<div style="flex:0 0 400px;display:flex;flex-direction:column;gap:16px;"><div id="upmoCard"'
a2='<div id="upmoBlk3" style="flex:0 0 500px;min-width:0;'
b2='<div id="upmoBlk3" style="flex:1;min-width:0;'
c=[s.count(a1),s.count(a2)]
if c!=[1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,b1).replace(a2,b2)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
