p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
a1="function setCard(o,code,reset){"
fn=r"""function setSide(o,reset){
var d=document.getElementById('upmoBlk4b1'),p=document.getElementById('upmoBlk4b2');
var ok=o&&(o.cost||0)>0;
if(d&&d.children.length>=3){
var dv=[d.children[0].children[1],d.children[2].children[1]];
if(!d._o){d._o=[dv[0].textContent,dv[1].textContent];}
var a0,a1;
if(reset){a0=d._o[0];a1=d._o[1];}else{a0=ok?fd(o.start):'—';a1=ok?fd(o.end||o.planEnd):'—';}
anim(dv[0],a0);anim(dv[1],a1);
}
if(p&&p.children.length>=2){
var cs=p.children[0].children;
var pv=[cs[0].children[1],cs[1].children[1],cs[2].children[1]];
var bars=p.children[1].children;
var bi=[bars[0].firstChild,bars[1].firstChild];
if(!p._o){p._o=[pv[0].textContent,pv[1].textContent,pv[2].textContent,pv[2].style.color,bi[0].style.width,bi[1].style.width];}
var x0,x1,x2,xc,w0,w1;
if(reset){x0=p._o[0];x1=p._o[1];x2=p._o[2];xc=p._o[3];w0=p._o[4];w1=p._o[5];}
else if(!ok){x0='—';x1='—';x2='—';xc='#9ca3af';w0='0%';w1='0%';}
else{var pl=Math.round(o.planPct||0);var f=Math.round((o.done||0)/o.cost*100);var df=f-pl;x0=pl+'%';x1=f+'%';x2=(df>0?'+':'')+df+'%';xc=df<0?'#e53e3e':'#38a169';w0=Math.min(100,pl)+'%';w1=Math.min(100,f)+'%';}
anim(pv[0],x0);anim(pv[1],x1);anim(pv[2],x2);
pv[2].style.color=xc;bi[0].style.width=w0;bi[1].style.width=w1;
}
}
"""
a2="anim(t,tt);anim(bg,bb);anim(vs[0],v0);anim(vs[1],v1);anim(vs[2],v2);"
c=[s.count(a1),s.count(a2)]
if c!=[1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,fn+a1).replace(a2,a2+"setSide(o,reset);")
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
