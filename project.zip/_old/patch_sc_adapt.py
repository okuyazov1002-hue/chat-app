p="public/upmo-scurve.js"
s=open(p,encoding="utf-8").read()
a="var W=n*step,H=200,pt=28,pb=28;"
b="""var W=n*step,H=(function(){var pn=el.closest(".upm-win"),wr=el.parentNode,rw=wr?wr.previousElementSibling:null;if(!pn||!rw){return 200;}var a=pn.clientHeight-32-rw.offsetHeight-32-169-11;return Math.max(200,Math.min(450,a));})(),pt=28,pb=28;"""
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
