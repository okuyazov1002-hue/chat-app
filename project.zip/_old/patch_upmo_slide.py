p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("if(m){m.classList.remove('open');}var b=document.getElementById('upmoBtn');",
 "if(m){m.classList.remove('open');m.style.transition='';m.style.transitionDelay='';m.style.transform='';m.style.clipPath='';}var b=document.getElementById('upmoBtn');"),
("if(b){b.classList.remove('nav-active');}setTimeout(function(){o.remove();},400);}",
 "if(b){b.classList.remove('nav-active');}setTimeout(function(){o.remove();},520);}")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
