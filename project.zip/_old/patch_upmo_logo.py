p="public/upmo-win.js"
s=open(p,encoding="utf-8").read()
pairs=[
("if(b){if(ov){closeAll();}else{openAll();}return;}",
 "if(b){if(ov===null){openAll();}else if(A.classList.contains('on')){if(B.classList.contains('on')){A.classList.remove('on');}else{closeAll();}}else{A.classList.add('on');}return;}"),
("#upmoA{left:104px;width:420px;padding:16px;}",
 "#upmoA{left:104px;width:420px;padding:16px;z-index:2001;}")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
