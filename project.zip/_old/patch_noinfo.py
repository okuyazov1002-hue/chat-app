p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a1 = r"""objs+='<div class="dsObj" data-oc="'+c+'" style="cursor:pointer;display:flex;"""
b1 = r"""objs+='<div class="dsObj" data-oc="'+c+'" data-nd="'+(oh?'':'1')+'" style="cursor:pointer;display:flex;"""
a2 = r"""if(ob){window.dsOpenObj(ob.getAttribute('data-oc'));return;}"""
b2 = r"""if(ob){if(ob.getAttribute('data-nd')=='1'){window.dsNoInfo();return;}window.dsOpenObj(ob.getAttribute('data-oc'));return;}"""
c1 = s.count(a1)
c2 = s.count(a2)
if c1 == 1 and c2 == 1:
    open(p, "w", encoding="utf-8").write(s.replace(a1, b1).replace(a2, b2))
    print("PATCHED")
else:
    print("ANCHOR_COUNT", c1, c2)
