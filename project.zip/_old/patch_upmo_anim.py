p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("'<div data-kids=\"'+k+'\" style=\"display:none;\">'",
 "'<div data-kids=\"'+k+'\" style=\"max-height:0;overflow:hidden;transition:max-height .35s ease;\">'"),
("var op=kids.style.display!=='none';kids.style.display=op?'none':'block';",
 "var op=kids.style.maxHeight!==''&&kids.style.maxHeight!=='0px';kids.style.maxHeight=op?'0px':kids.scrollHeight+'px';"),
("style=\"padding:16px;display:flex;flex-direction:column;gap:12px;\">",
 "style=\"padding:16px;display:flex;flex-direction:column;gap:6px;\">"),
("+sec('aux','Вспомогательные проекты',ai);",
 "+sec('aux','Вспомогательные проекты',ai);box.querySelectorAll('.ml-card0').forEach(function(c){c.style.margin='0';});")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
