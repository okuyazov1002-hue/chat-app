p="public/main.html"
s=open(p,encoding="utf-8").read()
a='<div style="width:100%;display:flex;flex-direction:column;gap:16px;">'
b='<div style="width:1382px;flex:0 0 auto;display:flex;flex-direction:column;gap:16px;">'
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
