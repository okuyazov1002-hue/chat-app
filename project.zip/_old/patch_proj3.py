p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
pairs=[
('<div style="border-radius:12px;background:#f8fafc;margin-bottom:6px;overflow:hidden;">','<div style="border-radius:14px;background:#fff;box-shadow:0 1px 6px rgba(0,0,0,0.14);margin-bottom:8px;overflow:hidden;">'),
("<span>'+p.name+'</span>","<span>'+p.code+' '+p.name+'</span>")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:60])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
