p="public/main.html"
s=open(p,encoding="utf-8").read()
a='<div id="upmoMapBlk" style="flex:1;min-width:0;height:340px;'
b='<div id="upmoMapBlk" style="flex:0 0 400px;min-width:0;height:340px;'
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
