p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a = r"""var pa=(pv>=fv);"""
b = r"""var pa=(pv>=fv);s+='<line x1="'+cx+'" x2="'+cx+'" y1="'+Y(pv)+'" y2="'+Y(fv)+'" stroke="#f87171" stroke-width="2" stroke-dasharray="4 3" stroke-linecap="round"/>';"""
n = s.count(a)
if n == 1:
    open(p, "w", encoding="utf-8").write(s.replace(a, b))
    print("PATCHED")
else:
    print("ANCHOR_COUNT", n)
