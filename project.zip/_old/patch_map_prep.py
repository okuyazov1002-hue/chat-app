def patch(p,pairs):
    s=open(p,encoding="utf-8").read()
    ok=True
    for a,b in pairs:
        n=s.count(a)
        if n!=1:
            ok=False;print("ANCHOR_COUNT",p,n,a[:50])
    if ok:
        for a,b in pairs:
            s=s.replace(a,b)
        open(p,"w",encoding="utf-8").write(s);print("PATCHED",p)
patch("public/main.html",[
("layersCtl.addOverlay(prepGroup,'Подготовительные работы');",
 "layersCtl.addOverlay(prepGroup,'Подготовительные работы');window.upmoNewGroup=newGroup;window.upmoPrepGroup=prepGroup;")
])
patch("public/upmo-map.js",[
("blk.appendChild(mb);",
 "blk.appendChild(mb);\nif(window.leafMap&&window.upmoNewGroup&&window.leafMap.hasLayer(window.upmoNewGroup)){st.hadNew=true;window.leafMap.removeLayer(window.upmoNewGroup);}\nsetTimeout(function(){try{var bb=window.upmoPrepGroup.getBounds();if(bb.isValid()){window.leafMap.fitBounds(bb,{padding:[20,20]});}}catch(er){}},450);"),
("st.mb.setAttribute('style',st.sty||'');",
 "st.mb.setAttribute('style',st.sty||'');\nif(st.hadNew&&window.leafMap&&window.upmoNewGroup){window.leafMap.addLayer(window.upmoNewGroup);}\nst.hadNew=false;")
])
