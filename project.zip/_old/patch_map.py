p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a1 = r"""<div style="width:100%;"><div style="font-size:11px;color:rgba(255,255,255,0.85);font-weight:700;">Общая стоимость</div>"""
b1 = r"""<div style="width:100%;"><div style="display:flex;align-items:center;justify-content:space-between;"><div style="font-size:11px;color:rgba(255,255,255,0.85);font-weight:700;">Общая стоимость</div><div id="dsMapBtn" style="background:rgba(255,255,255,0.5);border-radius:14px;padding:5px 12px;display:flex;align-items:center;gap:5px;font-size:11px;font-weight:700;color:#1f2937;box-shadow:0 2px 8px rgba(0,0,0,0.12);cursor:pointer;"><svg width="12" height="12" viewBox="0 0 24 24"><path d="M12 2C8.1 2 5 5.1 5 9c0 5.2 7 13 7 13s7-7.8 7-13c0-3.9-3.1-7-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z" fill="currentColor"/></svg>Карта</div></div>"""
a2 = r"""el.innerHTML=left;"""
b2 = r"""el.innerHTML=left;var mb=document.getElementById('dsMapBtn');if(mb){mb.addEventListener('click',function(){window.dsGoMap();});}"""
c1 = s.count(a1)
c2 = s.count(a2)
if c1 == 1 and c2 == 1:
    open(p, "w", encoding="utf-8").write(s.replace(a1, b1).replace(a2, b2))
    print("PATCHED")
else:
    print("ANCHOR_COUNT", c1, c2)
