p="public/upmo-cal.js"
s=open(p,encoding="utf-8").read()
a1="var now=new Date();"
b1="var now=new Date();var MN=['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'];"
a2="""'">'+m+'</div>';"""
b2="""'">'+MN[m-1]+'</div>';"""
c=[s.count(a1),s.count(a2)]
if c!=[1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,b1).replace(a2,b2)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
