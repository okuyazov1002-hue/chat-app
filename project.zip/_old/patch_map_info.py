p="public/upmo-map.js"
s=open(p,encoding="utf-8").read()
helper=r"""
function infoIn(blk){var mi=document.getElementById('mapInfo');if(mi===null||st.mi){return;}
st.mi=mi;st.mipar=mi.parentNode;st.minx=mi.nextSibling;st.blk=blk;blk.appendChild(mi);
function sync(){blk.classList.toggle('su-obj',parseInt(mi.style.width)>460);}
st.obs=new MutationObserver(sync);st.obs.observe(mi,{attributes:true,attributeFilter:['style']});sync();}
function infoOut(){if(!st.mi){return;}try{st.obs.disconnect();if(st.blk){st.blk.classList.remove('su-obj');}st.mipar.insertBefore(st.mi,st.minx);}catch(e){}st.mi=null;}
"""
pairs=[
("var st={mb:null,par:null,nx:null,sty:null};","var st={mb:null,par:null,nx:null,sty:null};"+helper),
("window.upmoMapRestore=function(){","window.upmoMapRestore=function(){\ninfoOut();"),
("z.innerHTML=iCol;blk.classList.add('su-big');tick();","z.innerHTML=iCol;blk.classList.add('su-big');infoIn(blk);tick();"),
("z.innerHTML=iExp;blk.classList.remove('su-big');tick();","var pb=blk.querySelector('.pback');if(pb){pb.click();}\nblk.classList.remove('su-obj');\nz.innerHTML=iExp;blk.classList.remove('su-big');tick();"),
("var ph3=document.getElementById('upmoMapPh');","infoOut();var ph3=document.getElementById('upmoMapPh');"),
("#upmoMapBlk.su-big .leaflet-tooltip-pane{display:block !important;}",
 "#upmoMapBlk.su-big .leaflet-tooltip-pane{display:block !important;}#upmoMapBlk #mapInfo{display:none !important;}#upmoMapBlk.su-obj #mapInfo{display:flex !important;position:absolute;left:0;top:0;bottom:0;width:min(760px,62%) !important;margin:0 !important;z-index:1002;background:#fff;box-shadow:6px 0 18px rgba(0,0,0,0.25);}")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:60])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
