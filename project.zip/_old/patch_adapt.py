def patch(p,pairs):
    s=open(p,encoding="utf-8").read()
    ok=True
    for a,b in pairs:
        n=s.count(a)
        if n!=1:
            ok=False;print("ANCHOR_COUNT",p,n,a[:60])
    if ok:
        for a,b in pairs:
            s=s.replace(a,b)
        open(p,"w",encoding="utf-8").write(s);print("PATCHED",p)
patch("public/main.html",[
('<div style="padding:16px;display:flex;flex-direction:column;gap:16px;">','<div style="padding:16px;box-sizing:border-box;min-height:100%;display:flex;flex-direction:column;gap:16px;">'),
('width:1382px;flex:0 0 auto;display:flex;','width:1382px;flex:1 0 auto;display:flex;'),
('<div id="upmoSc" style="min-width:0;','<div id="upmoSc" style="min-width:0;min-height:211px;'),
('<div id="upmoMo" style="min-width:0;','<div id="upmoMo" style="min-width:0;flex:1 1 auto;')
])
patch("public/upmo-months.js",[
("var bw=step-6,H=110,pc=[],last=0;","var bw=step-6,H=Math.max(70,Math.min(420,el.clientHeight-59)),pc=[],last=0;")
])
