p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("margin-left:400px;height:100%;background:#fff;border-radius:0 20px 20px 0;transform:translateX(-120%);transition:transform .45s cubic-bezier(.22,1,.36,1),margin-left .45s cubic-bezier(.22,1,.36,1);",
 "margin-left:0;height:100%;background:#fff;border-radius:0 20px 20px 0;opacity:0;transform:translateX(-30px);transition:transform .4s ease,opacity .4s ease;"),
("pin.style.transform='translateX(-120%)';pin.setAttribute('data-o','0');",
 "pin.style.transform='translateX(-30px)';pin.style.opacity='0';pin.setAttribute('data-o','0');"),
("pin.style.marginLeft='400px';}",
 "}"),
("pin.style.transform='translateX(0)';var mw=",
 "pin.style.transform='translateX(0)';pin.style.opacity='1';var mw="),
("pin.style.marginLeft='0px';pin.style.transitionDelay='0.5s';",
 "pin.style.transitionDelay='0.5s';")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
