p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
i = s.index("window.dsObjCharts=function")
head = s[:i]
seg = s[i:]
pairs = [
 (r"""var n=sc.labels.length;if(n<2){el.textContent='Нет данных';el2.textContent='Нет данных';return;}""",
  r"""var n=sc.labels.length;if(n<2){el.textContent='Нет данных';el2.textContent='Нет данных';return;}var cw=Math.max(22,Math.floor((hb.clientWidth-24)/n));"""),
 (r"""h+='<div style="width:22px;flex:none;""", r"""h+='<div style="width:'+cw+'px;flex:none;"""),
 (r"""<div style="position:relative;width:22px;height:110px;">""", r"""<div style="position:relative;width:'+cw+'px;height:110px;">"""),
 (r"""left:3px;bottom:0;width:16px;height:110px;""", r"""left:'+Math.round((cw-16)/2)+'px;bottom:0;width:16px;height:110px;"""),
 (r"""left:3px;bottom:0;width:16px;height:'+hf+'px;""", r"""left:'+Math.round((cw-16)/2)+'px;bottom:0;width:16px;height:'+hf+'px;"""),
 (r"""display:flex;width:'+(n*22)+'px;padding-top:16px;">""", r"""display:flex;width:'+(n*cw)+'px;padding-top:16px;">"""),
 (r"""Math.min(x-w/2,n*22-w)""", r"""Math.min(x-w/2,n*cw-w)"""),
 (r"""var i=Math.floor(x/22);""", r"""var i=Math.floor(x/cw);"""),
 (r"""var W=n*22;""", r"""var W=n*cw;"""),
 (r"""function X(i){return i*22+11;}""", r"""function X(i){return i*cw+cw/2;}"""),
 (r"""var sl=Math.max(0,(last-5)*22);""", r"""var sl=Math.max(0,(last-5)*cw);""")
]
ok = True
for a, b in pairs:
    n = seg.count(a)
    if n != 1:
        ok = False
        print("ANCHOR_COUNT", n, a[:50])
if ok:
    for a, b in pairs:
        seg = seg.replace(a, b)
    open(p, "w", encoding="utf-8").write(head + seg)
    print("PATCHED")
