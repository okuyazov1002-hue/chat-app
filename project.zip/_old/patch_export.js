const fs = require("fs");
let s = fs.readFileSync("server.js", "utf8");
const a = '    const byMonth = {};\n    reports.forEach(r => {\n      (r.rows || []).forEach(row => {\n        if (row.planStart == null || row.planEnd == null) return;';
const n = s.split(a).length - 1;
if (n == 1) {
  const b = '    const byMonth = {};\n    const curveCodes = {};\n    const curveDocs = await mongoose.connection.db.collection("data").find({ _id: { $regex: "^prep_cost_curve_" } }).toArray();\n    curveDocs.forEach(cd => {\n      const v = cd.value || {};\n      if (reports.some(r => r.code == cd.code) == false) return;\n      curveCodes[cd.code] = 1;\n      (v.labels || []).forEach((k, i) => {\n        byMonth[k] = byMonth[k] || { plan: 0, fact: 0 };\n        byMonth[k].plan += (v.planPer || [])[i] || 0;\n        byMonth[k].fact += (v.factPer || [])[i] || 0;\n      });\n    });\n    reports.forEach(r => {\n      if (curveCodes[r.code]) return;\n      (r.rows || []).forEach(row => {\n        if (row.planStart == null || row.planEnd == null) return;';
  fs.writeFileSync("server.js", s.split(a).join(b));
  console.log("PATCHED");
} else {
  console.log("ANCHOR_COUNT", n);
}
