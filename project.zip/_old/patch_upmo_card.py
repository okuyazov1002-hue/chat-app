p="public/main.html"
s=open(p,encoding="utf-8").read()
a="var opn=pin.getAttribute('data-o')=='1';pin.style.transform=opn?'translateX(-120%)':'translateX(0)';pin.setAttribute('data-o',opn?'0':'1');}"
b="var opn=pin.getAttribute('data-o')=='1';var same=pin.getAttribute('data-k')==k;if(opn&&same){pin.style.transform='translateX(-120%)';pin.setAttribute('data-o','0');}else{pin.setAttribute('data-k',k);pin.setAttribute('data-o','1');pin.style.transform='translateX(0)';window.upmoFillPanel(pin,k);}}"
c="</body>"
fn="""<script>
window.upmoFillPanel=function(pin,k){
var t=k=='act:int'?'int':(k=='act:ext'?'ext':'');
pin.innerHTML='<div style="padding:16px;"><div id="upmoCard" style="max-width:520px;box-sizing:border-box;border-radius:16px;padding:14px 16px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);color:#fff;font-size:11px;">Загрузка...</div></div>';
fetch('/api/prep/summary'+(t?'?type='+t:'')).then(function(r){return r.json();}).then(function(d){
var el=document.getElementById('upmoCard');if(!el){return;}
var fm=(typeof fmtMoney==='function')?fmtMoney:function(x){return String(x);};
var lab='font-size:10px;color:#4b5563;font-weight:600;';
var blk='background:rgba(255,255,255,0.5);border-radius:14px;padding:6px 10px;box-shadow:0 2px 8px rgba(0,0,0,0.12);';
var val='font-size:12px;color:#1f2937;font-weight:700;';
var tc=d.totalCost||0;
el.innerHTML='<div style="font-size:11px;color:rgba(255,255,255,0.85);font-weight:700;">Общая стоимость</div><div style="font-size:18px;color:#fff;font-weight:700;margin-top:2px;">'+fm(tc)+'</div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-top:10px;"><div style="'+blk+'"><div style="'+lab+'">План</div><div style="'+val+'">'+fm(Math.round(tc*(d.planPct||0)/100))+'</div></div><div style="'+blk+'"><div style="'+lab+'">Освоено</div><div style="'+val+'">'+fm(d.done||0)+'</div></div><div style="'+blk+'"><div style="'+lab+'">Остаток</div><div style="'+val+'">'+fm(d.remaining||0)+'</div></div></div>';
}).catch(function(){var el=document.getElementById('upmoCard');if(el){el.textContent='Нет данных';}});
};
</script>
"""
n1=s.count(a); n2=s.count(c)
if n1!=1 or n2!=1:
    print("ANCHOR_COUNT",n1,n2)
else:
    s=s.replace(a,b).replace(c,fn+c)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
