p="public/main.html"
s=open(p,encoding="utf-8").read()
a="</body>"
js="""<script>
(function(){
var ov=null;
function closeU(){if(!ov){return;}var o=ov;ov=null;var m=o.querySelector('.stage-modal');o.classList.remove('open');if(m){m.classList.remove('open');}var b=document.getElementById('upmoBtn');if(b){b.classList.remove('nav-active');}setTimeout(function(){o.remove();},400);}
document.addEventListener('click',function(e){
var b=e.target.closest('#upmoBtn');
if(b==null){if(ov&&(e.target.closest('.buttons button')||e.target===ov)){closeU();}return;}
if(ov){closeU();return;}
b.classList.add('nav-active');
ov=document.createElement('div');ov.id='upmoOverlay';ov.className='stage-modal-overlay';ov.style.cssText='display:block;padding:0;background:transparent;';
ov.innerHTML='<div class="stage-modal" style="position:fixed;left:104px;top:16px;bottom:16px;height:calc(100vh - 32px);width:520px;max-width:calc(100vw - 140px);border-radius:0 20px 20px 0;transform-origin:left center;box-shadow:16px -10px 16px rgba(0,0,0,0.08),20px 0 20px rgba(0,0,0,0.10),16px 10px 16px rgba(0,0,0,0.08);"></div>';
document.body.appendChild(ov);
setTimeout(function(){if(ov){ov.classList.add('open');ov.querySelector('.stage-modal').classList.add('open');}},20);
},true);
})();
</script>
"""
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,js+a));print("PATCHED")
