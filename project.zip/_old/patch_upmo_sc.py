p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
('<div style="padding:16px;"><div id="upmoCard"','<div style="padding:16px;display:flex;gap:16px;align-items:flex-start;"><div id="upmoCard"'),
('id="upmoCard" style="max-width:400px;','id="upmoCard" style="flex:0 0 400px;'),
("Загрузка...</div></div>';\nfetch('/api/prep/summary'+(t?'?type='+t:''))",
 "Загрузка...</div><div id=\"upmoSc\" style=\"flex:1;min-width:0;background:#fff;border-radius:16px;box-shadow:0 0 16px rgba(74,144,217,0.25);\"></div></div>';\nif(window.upmoScurve){window.upmoScurve(document.getElementById('upmoSc'),t);}\nfetch('/api/prep/summary'+(t?'?type='+t:''))"),
('<script src="upmo-win.js"></script>','<script src="upmo-scurve.js"></script>\n<script src="upmo-win.js"></script>')
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
