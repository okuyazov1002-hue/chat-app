p="public/main.html"
s=open(p,encoding="utf-8").read()
a='<div id="upmoBlk4" style="flex:1;min-height:0;box-sizing:border-box;border-radius:16px;background:#fff;box-shadow:0 2px 14px rgba(0,0,0,0.2);"></div>'
st='flex:1;min-width:0;box-sizing:border-box;border-radius:16px;background:#fff;box-shadow:0 2px 14px rgba(0,0,0,0.2);'
b='<div id="upmoBlk4" style="flex:1;min-height:0;display:flex;gap:16px;"><div id="upmoBlk4a" style="'+st+'"></div><div id="upmoBlk4b" style="'+st+'"></div></div>'
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
