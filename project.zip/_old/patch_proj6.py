p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
pairs=[
("padding:8px 4px 8px 18px;","padding:8px 10px;"),
("+dates(oh?o.start:null,oh?o.end:null,oh)+bar(oh,opl,of)+","+bar(oh,opl,of)+")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:60])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
