p="public/mobile-info.js"
s=open(p,encoding="utf-8").read()
a1="var rows=[['Отдел',u.department],['Должность',u.position],['Дата рождения',u.birthday],['Внутренний номер',u.internalPhone]];"
b1="var rows=[['Отдел',u.department],['Должность',u.position],['Дата рождения',u.birthday],['Внутренний',u.internalPhone],['Мобильный',u.mobilePhone],['Почта',u.email]];"
a2="d+='<div style=\"margin-top:6px;\"><div style=\"font-size:10px;color:#9ca3af;\">'+r[0]+'</div><div style=\"font-size:12px;color:#1f2937;font-weight:600;\">'+esc(r[1])+'</div></div>';"
b2="d+='<div style=\"display:flex;gap:10px;margin-top:6px;align-items:baseline;\"><div style=\"width:84px;flex-shrink:0;font-size:10px;color:#9ca3af;\">'+r[0]+'</div><div style=\"flex:1;min-width:0;font-size:12px;color:#1f2937;font-weight:600;word-break:break-word;\">'+esc(r[1])+'</div></div>';"
ok=True
for a in (a1,a2):
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:40])
if ok:
    s=s.replace(a1,b1).replace(a2,b2)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
