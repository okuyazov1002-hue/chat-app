p="public/main.html"
s=open(p,encoding="utf-8").read()
a1='<div style="display:flex;gap:16px;align-items:flex-start;"><div id="upmoCard" style="flex:0 0 400px;'
b1='<div style="display:flex;gap:16px;align-items:stretch;"><div style="flex:0 0 400px;display:flex;flex-direction:column;gap:16px;"><div id="upmoCard" style="'
a2='Загрузка...</div><div id="upmoMapBlk"'
b2='Загрузка...</div><div id="upmoBlk4" style="flex:1;min-height:0;box-sizing:border-box;border-radius:16px;background:#fff;box-shadow:0 2px 14px rgba(0,0,0,0.2);"></div></div><div id="upmoMapBlk"'
n1=s.count(a1);n2=s.count(a2)
if n1!=1 or n2!=1:
    print("ANCHOR_COUNT",n1,n2)
else:
    s=s.replace(a1,b1).replace(a2,b2)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
