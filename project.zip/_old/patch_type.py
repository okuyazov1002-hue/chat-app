def patch(p, pairs):
    s = open(p, encoding="utf-8").read()
    ok = True
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            ok = False
            print("ANCHOR_COUNT", n, p, repr(a[:60]))
    if ok:
        for a, b in pairs:
            s = s.replace(a, b)
        open(p, "w", encoding="utf-8").write(s)
        print("PATCHED", p)

patch("server.js", [
 ('app.get("/api/prep/objects", async (req, res) => {',
  'function filterByType(rows, type) {\n  if (type == "int") return rows.filter(x => x.contractor && x.contractor.includes("Внутренний"));\n  if (type == "ext") return rows.filter(x => x.contractor === "Внешний");\n  return rows;\n}\napp.get("/api/prep/objects", async (req, res) => {'),
 ('    const result = reports.map(r => {\n      const rows = r.rows || [];',
  '    const ftype = req.query.type;\n    const result = reports.map(r => {\n      const rows = filterByType(r.rows || [], ftype);'),
 ('        code: r.code,\n        cost, done, paid,',
  '        code: r.code,\n        nrows: rows.length,\n        cost, done, paid,'),
 ('    result.sort((a, b) => a.code.localeCompare(b.code));\n    res.json(result);',
  '    const out = ftype ? result.filter(o => o.nrows > 0) : result;\n    out.sort((a, b) => a.code.localeCompare(b.code));\n    res.json(out);'),
 ('    let allRows = [];\n    reports.forEach(r => { allRows = allRows.concat(r.rows || []); });',
  '    let allRows = [];\n    reports.forEach(r => { allRows = allRows.concat(filterByType(r.rows || [], req.query.type)); });'),
 ('    if (codeFilter) docs = docs.filter(d => d.code === codeFilter);',
  '    if (codeFilter) docs = docs.filter(d => d.code === codeFilter);\n    const ty = req.query.type;\n    if (ty == "int") docs = docs.filter(d => d.contractor && (d.contractor.includes("Внутренний") || d.contractor == "Смешанный"));\n    if (ty == "ext") docs = docs.filter(d => d.contractor && (d.contractor == "Внешний" || d.contractor == "Смешанный"));')
])

patch("public/mobile-info.js", [
 ("""if(key=='act:all'){window.dsRenderPrepAll(document.getElementById('prepPanelBody'));}""",
  """if(key=='act:all'||key=='act:int'||key=='act:ext'){window.dsRenderPrepAll(document.getElementById('prepPanelBody'),key.slice(4));}"""),
 ("""window.dsRenderPrepAll=function(body){""",
  """window.dsRenderPrepAll=function(body,mode){var ty=(mode=='int'||mode=='ext')?mode:'';"""),
 ("""window.dsFillProjects(document.getElementById('dsBlock2'));""",
  """window.dsFillProjects(document.getElementById('dsBlock2'),ty);"""),
 ("""window.dsFillMonths(document.getElementById('dsBlock3'));""",
  """window.dsFillMonths(document.getElementById('dsBlock3'),ty);"""),
 ("""fetch('/api/prep/summary').then(function(r){return r.json();}).then(function(d){""",
  """fetch('/api/prep/summary'+(ty?'?type='+ty:'')).then(function(r){return r.json();}).then(function(d){"""),
 ("""Math.round(d.totalCost*d.planPct/100)""",
  """Math.round(d.totalCost*(d.planPct||0)/100)"""),
 ("""window.dsFillProjects=function(box){""",
  """window.dsFillProjects=function(box,ty){"""),
 ("""names[it.code]=it.name;var pc=it.code.split('-')[0];""",
  """names[it.code]=it.name;if(ty){return;}var pc=it.code.split('-')[0];"""),
 ("""fetch('/api/prep/objects').then(function(r){return r.json();}).then(function(list){""",
  """fetch('/api/prep/objects'+(ty?'?type='+ty:'')).then(function(r){return r.json();}).then(function(list){if(ty&&list.length==0){var e0=document.getElementById('dsProjList');if(e0){e0.innerHTML='';}return;}"""),
 ("""window.dsFillMonths=function(box){if(window.dsFillScurve){window.dsFillScurve(box);}""",
  """window.dsFillMonths=function(box,ty){if(window.dsFillScurve){window.dsFillScurve(box,ty);}"""),
 ("""fetch('/api/prep/scurve').then(function(r){return r.json();}).then(function(sc){""",
  """fetch('/api/prep/scurve'+(ty?'?type='+ty:'')).then(function(r){return r.json();}).then(function(sc){"""),
 ("""window.dsFillScurve=function(box){""",
  """window.dsFillScurve=function(box,ty){"""),
 ("""Promise.all([fetch('/api/prep/scurve').then(function(r){return r.json();}),fetch('/api/prep/summary').then(function(r){return r.json();})])""",
  """Promise.all([fetch('/api/prep/scurve'+(ty?'?type='+ty:'')).then(function(r){return r.json();}),fetch('/api/prep/summary'+(ty?'?type='+ty:'')).then(function(r){return r.json();})])""")
])
