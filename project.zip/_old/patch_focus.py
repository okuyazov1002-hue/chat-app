p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
a1='<div style="padding:8px 10px;border-top:1px solid #eef0f3;">'
b1='<div class="upO" data-oc="\'+c+\'" style="cursor:pointer;padding:8px 10px;border-top:1px solid #eef0f3;">'
a2="var r=e.target.closest('.upP');if(r===null){return;}"
b2="var ob=e.target.closest('.upO');if(ob!==null){var oc=ob.getAttribute('data-oc');var was=(window._upmoFocus===oc);window._upmoFocus=was?null:oc;el.querySelectorAll('.upO').forEach(function(x){x.style.background='';});if(was){if(window.dsMapAll){window.dsMapAll();}}else{ob.style.background='#eaf3fb';if(window.dsMapFocus){window.dsMapFocus(oc);}}return;}\n"+a2
a3="if(el===null){return;}"
b3="if(el===null){return;}window._upmoFocus=null;"
c=[s.count(a1),s.count(a2),s.count(a3)]
if c!=[1,1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,b1).replace(a2,b2).replace(a3,b3)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
