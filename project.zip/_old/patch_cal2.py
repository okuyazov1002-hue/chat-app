sh="-5px -5px 16px rgba(106,90,224,0.45),5px 5px 16px rgba(29,211,176,0.45),0 0 18px rgba(74,144,217,0.4)"
gr="linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%)"
p="public/main.html"
s=open(p,encoding="utf-8").read()
k='id="upmoBlk4a"'
old="background:#fff;box-shadow:0 2px 14px rgba(0,0,0,0.2);"
if s.count(k)!=1:
    print("ANCHOR_COUNT html",s.count(k))
else:
    i=s.index(k);j=s.find(old,i);e=s.index("</div>",i)
    if j<0 or j>e:
        print("OLD_STYLE_NOT_FOUND")
    else:
        s=s[:j]+"background:"+gr+";box-shadow:"+sh+";"+s[j+len(old):]
        open(p,"w",encoding="utf-8").write(s);print("PATCHED html")
q="public/upmo-cal.js"
t=open(q,encoding="utf-8").read()
pairs=[
("color:#6b7280;font-size:15px;","color:rgba(255,255,255,0.85);font-size:15px;",2),
("font-size:13px;font-weight:700;color:#1f2937;","font-size:13px;font-weight:700;color:#fff;",1),
("(p?'#e53e3e':'#cbd5e1')","(p?'#fff':'rgba(255,255,255,0.45)')",1),
("background:linear-gradient(135deg,#6a5ae0,#1dd3b0);color:#fff;","background:#fff;color:#4a90d9;",1),
("background:#f3f4f6;color:#374151;","background:rgba(255,255,255,0.28);color:#fff;",1),
("inset 0 0 0 1.5px #4a90d9","inset 0 0 0 1.5px #fff",1)
]
ok=True
for a,b,c in pairs:
    n=t.count(a)
    if n!=c:
        ok=False;print("ANCHOR_COUNT js",n,a[:50])
if ok:
    for a,b,c in pairs:
        t=t.replace(a,b)
    open(q,"w",encoding="utf-8").write(t);print("PATCHED js")
