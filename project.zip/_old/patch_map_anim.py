p="public/upmo-map.js"
s=open(p,encoding="utf-8").read()
m1="z.addEventListener('click',function(e){"
m2="blk.appendChild(z);"
if s.count(m1)!=1 or s.count(m2)!=1:
    print("ANCHOR_COUNT",s.count(m1),s.count(m2))
else:
    i=s.index(m1);j=s.index(m2)
    new=r"""z.addEventListener('click',function(e){
e.stopPropagation();
if(blk._busy){return;}
blk._busy=true;
var w=blk.closest('.upm-win');if(w===null){blk._busy=false;return;}
function tick(){var t=0;var iv=setInterval(function(){if(window.leafMap){window.leafMap.invalidateSize();}t+=40;if(t>560){clearInterval(iv);}},40);}
if(!big){
big=true;
if(w){w.scrollTop=0;}
var wr=w.getBoundingClientRect();var r=blk.getBoundingClientRect();
oldCss=blk.style.cssText;
var ph=document.createElement('div');ph.id='upmoMapPh';ph.style.cssText='flex:1;min-height:'+r.height+'px;';
blk.parentNode.insertBefore(ph,blk);
blk.style.position='absolute';blk.style.flex='none';blk.style.zIndex='5';blk.style.minHeight='0';blk.style.margin='0';
blk.style.left=(r.left-wr.left)+'px';blk.style.top=(r.top-wr.top)+'px';blk.style.width=r.width+'px';blk.style.height=r.height+'px';
void blk.offsetWidth;
blk.style.transition='left .45s ease,top .45s ease,width .45s ease,height .45s ease';
blk.style.left='16px';blk.style.top='16px';blk.style.width=(w.clientWidth-32)+'px';blk.style.height=(w.clientHeight-32)+'px';
z.innerHTML=iCol;tick();
setTimeout(function(){blk._busy=false;},480);
}else{
big=false;
var ph2=document.getElementById('upmoMapPh');
var wr2=w.getBoundingClientRect();
if(ph2){var r2=ph2.getBoundingClientRect();
blk.style.left=(r2.left-wr2.left)+'px';blk.style.top=(r2.top-wr2.top)+'px';blk.style.width=r2.width+'px';blk.style.height=r2.height+'px';}
z.innerHTML=iExp;tick();
setTimeout(function(){blk.style.transition='';blk.style.cssText=oldCss;var ph3=document.getElementById('upmoMapPh');if(ph3){ph3.remove();}if(window.leafMap){window.leafMap.invalidateSize();}blk._busy=false;},480);
}
});
"""
    open(p,"w",encoding="utf-8").write(s[:i]+new+s[j:]);print("PATCHED")
