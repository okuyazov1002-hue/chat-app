p="public/main.html"
s=open(p,encoding="utf-8").read()
tag='<button id="settingsBtn" title="Добавить пользователя">'
sc='<script src="upmo-map.js"></script>'
if s.count(tag)!=1 or s.count(sc)!=1:
    print("ANCHOR_COUNT",s.count(tag),s.count(sc))
else:
    i=s.index(tag)+len(tag)
    j=s.index('</svg>',i)+6
    svg=('<svg width="26" height="26" viewBox="0 0 120 120" fill="none">'
    '<path d="M12.18 64.18 A48 48 0 1 1 46.77 106.14" stroke="currentColor" stroke-width="9" stroke-linecap="round"/>'
    '<polygon points="43.5,117.7 50.1,94.6 31.5,96.6" fill="currentColor" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>'
    '<circle cx="60" cy="45" r="12" fill="currentColor"/>'
    '<path d="M37 84 C37 68 47 62 60 62 C73 62 83 68 83 84 Z" fill="currentColor" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>'
    '<circle cx="17" cy="85" r="12" fill="currentColor"/>'
    '<g class="su-plus"><path d="M17 79 V91 M11 85 H23" stroke="#4a90d9" stroke-width="4" stroke-linecap="round"/></g>'
    '<g transform="translate(17 85)"><g class="su-cur"><path d="M0 0 L0 22 L6 17 L10 26 L14 24 L10 15 L18 15 Z" fill="#fff" stroke="#1f2937" stroke-width="2" stroke-linejoin="round"/></g></g>'
    '</svg>')
    s=s[:i]+svg+s[j:]
    s=s.replace(sc,sc+'\n<script src="upmo-icon.js"></script>')
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
