p="public/upmo-map.js"
s=open(p,encoding="utf-8").read()
a="var st={mb:null,par:null,nx:null,sty:null};"
b=a+"\nvar css=document.createElement('style');css.textContent='#upmoMapBlk .leaflet-control-zoom,#upmoMapBlk .leaflet-control-layers{display:none !important;}';document.head.appendChild(css);"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
