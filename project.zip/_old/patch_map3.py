p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
pairs = [
 ("if(b==null){return;}\nif(b.id=='infoBtn'){return;}", "if(b==null){return;}\nif(window.dsSkipNav){return;}\nif(b.id=='infoBtn'){return;}"),
 ("mb.addEventListener('click',function(){window.dsGoMap();});", "mb.addEventListener('click',function(){window.dsMapToggle();});")
]
ok = True
for a, b in pairs:
    n = s.count(a)
    if n != 1:
        ok = False
        print("ANCHOR_COUNT", n, a[:50])
if ok:
    for a, b in pairs:
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
    print("PATCHED")
