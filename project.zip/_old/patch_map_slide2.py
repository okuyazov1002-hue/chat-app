p="public/upmo-map.js"
s=open(p,encoding="utf-8").read()
pairs=[
("transition:transform .4s cubic-bezier(.22,1,.36,1);}#upmoMapBlk.su-obj","transition:transform .4s cubic-bezier(.22,1,.36,1) !important;}#upmoMapBlk.su-obj"),
("var styleRec=recs.some(function(r){return r.type==='attributes';});","var styleRec=recs.some(function(r){return r.type==='childList'&&r.target.id==='mapInfoBody'&&r.removedNodes.length>0;});")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:60])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
