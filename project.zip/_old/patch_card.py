p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
a1="el.onclick=function(e){"
fn="""function setCard(o,code,reset){
var cd=document.getElementById('upmoCard');if(cd===null||cd.children.length<3){return;}
var t=cd.children[0],bg=cd.children[1],g=cd.children[2];
var vs=[g.children[0].children[1],g.children[1].children[1],g.children[2].children[1]];
if(!cd._o){cd._o=[t.textContent,bg.textContent,vs[0].textContent,vs[1].textContent,vs[2].textContent];}
if(reset){t.textContent=cd._o[0];bg.textContent=cd._o[1];vs[0].textContent=cd._o[2];vs[1].textContent=cd._o[3];vs[2].textContent=cd._o[4];return;}
var fm=(typeof fmtMoney==='function')?fmtMoney:function(x){return String(x);};
var ok=o&&(o.cost||0)>0;
t.textContent=(names[code]||code);
if(!ok){bg.textContent='—';vs.forEach(function(v){v.textContent='—';});return;}
var pl=Math.round(o.cost*(o.planPct||0)/100);
bg.textContent=fm(o.cost);vs[0].textContent=fm(pl);vs[1].textContent=fm(o.done||0);vs[2].textContent=fm(o.cost-(o.done||0));
}
"""
a2="window._upmoFocus=was?null:oc;"
b2="window._upmoFocus=was?null:oc;setCard(was?null:(dm[oc]||null),oc,was);"
c=[s.count(a1),s.count(a2)]
if c!=[1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,fn+a1).replace(a2,b2)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
