p="public/upmo-scurve.js"
s=open(p,encoding="utf-8").read()
a="var W=n*step,H=230,pt=28,pb=28;"
b="var W=n*step,H=170,pt=28,pb=28;"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
