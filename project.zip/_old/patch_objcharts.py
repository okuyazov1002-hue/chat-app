def patch(p,pairs):
    s=open(p,encoding="utf-8").read()
    ok=True
    for a,b in pairs:
        n=s.count(a)
        if n!=1:
            ok=False;print("ANCHOR_COUNT",p,n,a[:70])
    if ok:
        for a,b in pairs:
            s=s.replace(a,b)
        open(p,"w",encoding="utf-8").write(s);print("PATCHED",p)
patch("public/upmo-scurve.js",[
("window.upmoScurve=function(el,ty){","window.upmoScurve=function(el,ty,code,obj){"),
("Promise.all([fetch('/api/prep/scurve'+(ty?'?type='+ty:'')).then(function(r){return r.json();}),fetch('/api/prep/summary'+(ty?'?type='+ty:'')).then(function(r){return r.json();})]).then(function(a){",
 "Promise.all([window.upmoScData(ty,code),window.upmoSumData(ty,code,obj)]).then(function(a){")
])
patch("public/upmo-months.js",[
("window.upmoMonths=function(el,ty){","window.upmoMonths=function(el,ty,code){"),
("fetch('/api/prep/scurve'+(ty?'?type='+ty:'')).then(function(r){return r.json();}).then(function(sc){","window.upmoScData(ty,code).then(function(sc){")
])
patch("public/upmo-proj.js",[
("function anim(node,txt){",
 "function redraw(code,o){var sc=document.getElementById('upmoSc'),mo=document.getElementById('upmoMo');if(!sc||!mo){return;}[sc,mo].forEach(function(x){x.style.transition='opacity .25s';x.style.opacity='0';});setTimeout(function(){if(window.upmoScurve){window.upmoScurve(sc,ty,code,o);}if(window.upmoMonths){window.upmoMonths(mo,ty,code);}setTimeout(function(){sc.style.opacity='1';mo.style.opacity='1';},80);},260);}\nfunction anim(node,txt){"),
("setCard(was?null:(dm[oc]||null),oc,was);","setCard(was?null:(dm[oc]||null),oc,was);redraw(was?null:oc,was?null:(dm[oc]||null));")
])
patch("public/main.html",[
('<script src="upmo-sync.js"></script>','<script src="upmo-sync.js"></script>\n<script src="upmo-data.js"></script>')
])
