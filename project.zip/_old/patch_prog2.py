p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
row = r"""<div style="display:flex;justify-content:space-between;gap:10px;font-size:10px;font-weight:800;color:#1f2937;"><span style="font-weight:700;color:#4b5563;">%s</span><span id="%s">—</span></div>"""
def col(l, i):
    return r"""<div style="text-align:center;"><div style="font-size:9px;font-weight:700;color:#4b5563;">""" + l + r"""</div><div id=\"""".replace('\\"', '"') + i + r"""" style="font-size:11px;font-weight:800;color:#1f2937;">—</div></div>"""
pairs = [
  (row % ("План", "dsGP"), r"""<div style="display:flex;gap:12px;">""" + col("План", "dsGP")),
  (row % ("Факт", "dsGF"), col("Факт", "dsGF")),
  (row % ("Разница", "dsGD"), col("Разница", "dsGD") + "</div>")
]
ok = True
for a, b in pairs:
    n = s.count(a)
    if n != 1:
        ok = False
        print("ANCHOR_COUNT", n, a[:60])
if ok:
    for a, b in pairs:
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
    print("PATCHED")
