p="public/main.html"
s=open(p,encoding="utf-8").read()
st1='flex:1;min-height:0;box-sizing:border-box;border-radius:16px;background:#fff;box-shadow:0 2px 14px rgba(0,0,0,0.2);'
a_b='<div id="upmoBlk4b" style="flex:1;min-width:0;box-sizing:border-box;border-radius:16px;background:#fff;box-shadow:0 2px 14px rgba(0,0,0,0.2);"></div>'
b_b='<div id="upmoBlk4b" style="flex:1;min-width:0;display:flex;flex-direction:column;gap:16px;"><div id="upmoBlk4b1" style="'+st1+'"></div><div id="upmoBlk4b2" style="'+st1+'"></div></div>'
a_f="if(window.upmoProj){window.upmoProj(document.getElementById('upmoBlk3'),t);}"
b_f=a_f+"\nif(window.upmoCal){window.upmoCal(document.getElementById('upmoBlk4a'));}"
a_s='<script src="upmo-proj.js"></script>'
b_s=a_s+'\n<script src="upmo-cal.js"></script>'
c=[s.count(a_b),s.count(a_f),s.count(a_s)]
if c!=[1,1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a_b,b_b).replace(a_f,b_f).replace(a_s,b_s)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
