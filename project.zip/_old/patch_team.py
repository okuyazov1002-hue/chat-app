p="public/mobile-info.js"
s=open(p,encoding="utf-8").read()
a='<div class="obj-modal-header">Команда</div>'
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,'<div class="obj-modal-header" style="min-height:0;padding:0;border:0;"></div>'));print("PATCHED")
