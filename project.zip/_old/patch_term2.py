p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a1 = r"""padding:12px 12px 14px;"><div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">"""
b1 = r"""padding:12px 12px 38px;"><div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">"""
a2 = r"""op.insertAdjacentHTML('beforeend','<div style="margin-top:8px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);padding:12px 12px 14px;"><div style="font-size:12px;font-weight:700;color:#fff;margin-bottom:10px;">Сроки</div><div style="display:flex;gap:8px;">'+blk('Начало','dsTS')+blk('Окончание','dsTE')+blk('Прогноз','dsTF')+blk('Срок','dsTD')+'</div></div>');"""
b2 = r"""function blk2(l,id){return '<div style="flex:1;min-width:0;border-radius:16px;padding:7px 10px;background:#f3f4f6;"><div style="font-size:10px;font-weight:700;color:#6b7280;">'+l+'</div><div id="'+id+'" style="font-size:11px;font-weight:800;color:#1f2937;white-space:nowrap;margin-top:1px;">—</div></div>';}
op.insertAdjacentHTML('beforeend','<div style="position:relative;z-index:2;margin-top:-24px;background:#fff;border-radius:22px 22px 0 0;padding:16px 12px 16px;"><div style="font-size:12px;font-weight:700;color:#1f2937;margin-bottom:10px;">Сроки</div><div style="display:flex;gap:8px;">'+blk2('Начало','dsTS')+blk2('Окончание','dsTE')+blk2('Прогноз','dsTF')+blk2('Срок','dsTD')+'</div></div>');"""
c1 = s.count(a1)
c2 = s.count(a2)
if c1 == 1 and c2 == 1:
    s = s.replace(a1, b1).replace(a2, b2)
    open(p, "w", encoding="utf-8").write(s)
    print("PATCHED")
else:
    print("ANCHOR_COUNT", c1, c2)
