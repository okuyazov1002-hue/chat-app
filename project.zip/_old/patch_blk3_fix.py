p="public/main.html"
s=open(p,encoding="utf-8").read()
a='<div id="upmoBlk3" style="flex:1;min-width:0;'
b='<div id="upmoBlk3" style="flex:0 0 500px;min-width:0;margin-left:auto;'
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
