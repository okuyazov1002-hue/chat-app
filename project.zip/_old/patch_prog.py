p="public/main.html"
s=open(p,encoding="utf-8").read()
a1='<div id="upmoBlk4b" style="flex:1;min-width:0;display:flex;flex-direction:column;gap:16px;">'
b1='<div id="upmoBlk4b" style="flex:0 0 200px;min-width:0;display:flex;flex-direction:column;gap:16px;">'
a2="if(window.upmoDates){window.upmoDates(document.getElementById('upmoBlk4b1'),t);}"
b2=a2+"\nif(window.upmoProg){window.upmoProg(document.getElementById('upmoBlk4b2'),t);}"
a3='<script src="upmo-dates.js"></script>'
b3=a3+'\n<script src="upmo-prog.js"></script>'
c=[s.count(a1),s.count(a2),s.count(a3)]
if c!=[1,1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,b1).replace(a2,b2).replace(a3,b3)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
