p="public/main.html"
s=open(p,encoding="utf-8").read()
a="document.body.appendChild(ov);\nsetTimeout(function(){if(ov){"
js="""document.body.appendChild(ov);
try{
var box=ov.querySelector('.stage-modal > div');
var mr=function(l,k,t,hk){return '<div class="ml-row" data-k="'+k+'" style="display:flex;align-items:center;padding:9px 10px 9px '+(l?24:12)+'px;cursor:pointer;text-align:left;font-size:11px;'+(l?'color:#374151;':'font-weight:700;color:#1f2937;')+'"><span class="ar" style="width:12px;min-width:12px;flex-shrink:0;color:#6b7280;">'+(hk?'&#9656;':'')+'</span><span>'+t+'</span></div>';};
var sec=function(k,t,items){var inn='';items.forEach(function(it){inn+=mr(1,it[0],it[1],false);});return '<div class="ml-card0">'+mr(0,k,t,true)+'<div data-kids="'+k+'" style="display:none;">'+inn+'</div></div>';};
var pi=[['act:all','Общая информация'],['act:int','Внутренний'],['act:ext','Внешний']];
var mi=PROJECTS.main.items.map(function(it){return ['proj:'+it.code,it.code+' '+it.name];});
var ai=PROJECTS.aux.items.map(function(it){return ['proj:'+it.code,it.code+' '+it.name];});
box.innerHTML=sec('prep','Подготовительные работы',pi)+sec('main','Основные проекты',mi)+sec('aux','Вспомогательные проекты',ai);
box.addEventListener('click',function(e){var r=e.target.closest('.ml-row');if(!r){return;}var k=r.getAttribute('data-k');var kids=box.querySelector('[data-kids="'+k+'"]');if(kids){var op=kids.style.display!=='none';kids.style.display=op?'none':'block';r.querySelector('.ar').innerHTML=op?'&#9656;':'&#9662;';return;}if(k.indexOf('act:')===0&&window.dsGoPrep&&window.innerWidth<=768){window.dsGoPrep(k);}});
}catch(err){}
setTimeout(function(){if(ov){"""
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,js));print("PATCHED")
