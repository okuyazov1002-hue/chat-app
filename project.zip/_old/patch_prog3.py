p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a = r"""<div style="font-size:10px;font-weight:700;color:#4b5563;margin-bottom:2px;">Прогресс</div>"""
n = s.count(a)
if n == 1:
    open(p, "w", encoding="utf-8").write(s.replace(a, ""))
    print("PATCHED")
else:
    print("ANCHOR_COUNT", n)
