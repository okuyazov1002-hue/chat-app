p="public/main.html"
s=open(p,encoding="utf-8").read()
a1='<div id="upmoMapBlk" style="flex:0 0 400px;min-width:0;height:340px;'
b1='<div id="upmoMapBlk" style="flex:0 0 400px;min-width:0;margin-left:auto;height:340px;'
a2='<div id="upmoBlk3" style="flex:0 0 500px;min-width:0;margin-left:auto;'
b2='<div id="upmoBlk3" style="flex:0 0 500px;min-width:0;'
c=[s.count(a1),s.count(a2)]
if c!=[1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,b1).replace(a2,b2)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
