p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
m1="function setCard(o,code,reset){"
m2="vs[2].textContent=fm(o.cost-(o.done||0));\n}\n"
if s.count(m1)!=1 or s.count(m2)!=1:
    print("ANCHOR_COUNT",s.count(m1),s.count(m2))
else:
    i=s.index(m1);j=s.index(m2)+len(m2)
    new=r"""function anim(node,txt){
var tk=(node._tk=(node._tk||0)+1);
var cur=node.textContent;
node.style.minHeight=node.offsetHeight+'px';
var se=Math.max(6,Math.min(30,500/Math.max(1,cur.length)));
var sw=Math.max(6,Math.min(30,500/Math.max(1,txt.length)));
function erase(){
if(node._tk!==tk){return;}
if(cur.length>0){cur=cur.slice(0,-1);node.textContent=cur;setTimeout(erase,se);}else{write(1);}
}
function write(k){
if(node._tk!==tk){return;}
node.textContent=txt.slice(txt.length-k);
if(k<txt.length){setTimeout(function(){write(k+1);},sw);}else{node.style.minHeight='';}
}
if(cur.length===0&&txt.length===0){return;}
erase();
}
function setCard(o,code,reset){
var cd=document.getElementById('upmoCard');if(cd===null||cd.children.length<3){return;}
var t=cd.children[0],bg=cd.children[1],g=cd.children[2];
var vs=[g.children[0].children[1],g.children[1].children[1],g.children[2].children[1]];
if(!cd._o){cd._o=[t.textContent,bg.textContent,vs[0].textContent,vs[1].textContent,vs[2].textContent];}
var tt,bb,v0,v1,v2;
if(reset){tt=cd._o[0];bb=cd._o[1];v0=cd._o[2];v1=cd._o[3];v2=cd._o[4];}
else{
var fm=(typeof fmtMoney==='function')?fmtMoney:function(x){return String(x);};
var ok=o&&(o.cost||0)>0;
tt=(names[code]||code);
if(!ok){bb='—';v0='—';v1='—';v2='—';}
else{var pl=Math.round(o.cost*(o.planPct||0)/100);bb=String(fm(o.cost));v0=String(fm(pl));v1=String(fm(o.done||0));v2=String(fm(o.cost-(o.done||0)));}
}
anim(t,tt);anim(bg,bb);anim(vs[0],v0);anim(vs[1],v1);anim(vs[2],v2);
}
"""
    s=s[:i]+new+s[j:]
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
