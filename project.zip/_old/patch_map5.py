p="public/mobile-info.js"
s=open(p,encoding="utf-8").read()
pairs=[
("window.dsMapRestore();if(hold){hold.remove();}b2.style.zIndex='';",
 "window.dsMapRestore();if(hold){hold.remove();}b2.style.zIndex='';b2.style.height='';b2.style.overflowY='';var pbx=document.getElementById('prepPanelBody');if(pbx){pbx.style.overflow='';pbx.scrollTop=0;}var hh=b2.querySelector('.dsPr[data-pk=\"__all\"]');if(hh){hh.style.position='';hh.style.top='';hh.style.background='';hh.style.zIndex='';}"),
("hold2.style.height=window.dsMapH+'px';",
 "hold2.style.height=window.dsMapH+'px';var pb=document.getElementById('prepPanelBody');if(pb){pb.scrollTop=0;pb.style.overflow='hidden';b2.style.height=(pb.clientHeight-window.dsMapH+18)+'px';b2.style.overflowY='auto';var h2=b2.querySelector('.dsPr[data-pk=\"__all\"]');if(h2){h2.style.position='sticky';h2.style.top='0';h2.style.background='#fff';h2.style.zIndex='2';}}")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:40])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
