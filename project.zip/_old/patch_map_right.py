p="public/upmo-map.js"
s=open(p,encoding="utf-8").read()
pairs=[
("position:absolute;left:0;top:0;bottom:0;width:min(760px,62%) !important;","position:absolute;right:0;left:auto;top:0;bottom:0;width:min(760px,62%) !important;"),
("box-shadow:6px 0 18px rgba(0,0,0,0.25);","box-shadow:-6px 0 18px rgba(0,0,0,0.25);"),
("cursor:pointer;z-index:1000;","cursor:pointer;z-index:1003;")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:60])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
