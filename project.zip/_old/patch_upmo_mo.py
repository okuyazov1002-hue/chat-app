p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("box-shadow:0 0 16px rgba(74,144,217,0.25);\"></div></div>';",
 "box-shadow:0 0 16px rgba(74,144,217,0.25);\"></div></div><div id=\"upmoMo\" style=\"margin:0 16px 16px;border-radius:16px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);\"></div>';"),
("if(window.upmoScurve){window.upmoScurve(document.getElementById('upmoSc'),t);}",
 "if(window.upmoScurve){window.upmoScurve(document.getElementById('upmoSc'),t);}\nif(window.upmoMonths){window.upmoMonths(document.getElementById('upmoMo'),t);}"),
('<script src="upmo-scurve.js"></script>','<script src="upmo-scurve.js"></script>\n<script src="upmo-months.js"></script>')
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
