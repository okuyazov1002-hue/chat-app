def patch(p,pairs):
    s=open(p,encoding="utf-8").read()
    ok=True
    for a,b in pairs:
        n=s.count(a)
        if n!=1:
            ok=False;print("ANCHOR_COUNT",p,n,a[:50])
    if ok:
        for a,b in pairs:
            s=s.replace(a,b)
        open(p,"w",encoding="utf-8").write(s);print("PATCHED",p)
patch("public/upmo-win.js",[
("if(ov&&e.target.closest('.buttons button')){closeAll();}",
 "if(ov&&!window._upmoMapInit&&e.target.closest('.buttons button')){closeAll();}")
])
patch("public/upmo-map.js",[
("mbtn.click();",
 "window._upmoMapInit=true;mbtn.click();window._upmoMapInit=false;")
])
