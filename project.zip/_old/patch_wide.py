p="public/main.html"
s=open(p,encoding="utf-8").read()
a='<div style=\\"width:816px;max-width:100%;display:flex;flex-direction:column;gap:16px;\\">'
a2='<div style="width:816px;max-width:100%;display:flex;flex-direction:column;gap:16px;">'
b='<div style="width:100%;display:flex;flex-direction:column;gap:16px;">'
if s.count(a2)==1:
    open(p,"w",encoding="utf-8").write(s.replace(a2,b));print("PATCHED")
else:
    print("ANCHOR_COUNT",s.count(a2),s.count(a))
