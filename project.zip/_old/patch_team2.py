p="public/mobile-info.js"
s=open(p,encoding="utf-8").read()
a='<div id="teamSheetBody" style="flex:1;min-height:0;padding:6px 0 16px 0;"></div>'
b='<div id="teamSheetBody" style="flex:1;min-height:0;padding:0;display:flex;flex-direction:column;"><div id="teamTop" style="flex:0 0 auto;height:120px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);"></div><div id="teamWhite" style="flex:1;position:relative;margin-top:-18px;background:#fff;border-radius:18px 18px 0 0;"></div></div>'
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
