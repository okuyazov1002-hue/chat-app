p="public/upmo-map.js"
s=open(p,encoding="utf-8").read()
pairs=[
("#upmoMapBlk .leaflet-popup-pane{display:none !important;}",
 "#upmoMapBlk .leaflet-popup-pane{display:none !important;}#upmoMapBlk.su-big .leaflet-tooltip-pane{display:block !important;}"),
("z.innerHTML=iCol;tick();","z.innerHTML=iCol;blk.classList.add('su-big');tick();"),
("z.innerHTML=iExp;tick();","z.innerHTML=iExp;blk.classList.remove('su-big');tick();")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs:
        s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
