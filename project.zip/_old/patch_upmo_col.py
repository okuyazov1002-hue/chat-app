p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
('<div id="upmoSc" style="flex:1;min-width:0;background:#fff;',
 '<div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:16px;"><div id="upmoSc" style="min-width:0;background:#fff;'),
('"></div></div><div id="upmoMo" style="margin:0 16px 16px;border-radius:16px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);"></div>\';',
 '"></div><div id="upmoMo" style="border-radius:16px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);"></div></div></div>\';')
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
