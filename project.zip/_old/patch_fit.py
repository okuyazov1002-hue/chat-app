def patch(p,pairs):
    s=open(p,encoding="utf-8").read()
    ok=True
    for a,b in pairs:
        n=s.count(a)
        if n!=1:
            ok=False;print("ANCHOR_COUNT",p,n,a[:60])
    if ok:
        for a,b in pairs:
            s=s.replace(a,b)
        open(p,"w",encoding="utf-8").write(s);print("PATCHED",p)
patch("public/upmo-win.js",[
("#upmoB{left:104px;right:16px;}","#upmoB{left:104px;right:16px;bottom:auto;max-height:calc(100vh - 32px);}")
])
patch("public/upmo-proj.js",[
("el.style.scrollbarWidth='thin';",
 "el.style.scrollbarWidth='none';el.style.msOverflowStyle='none';if(!document.getElementById('upmoProjSt')){var sx=document.createElement('style');sx.id='upmoProjSt';sx.textContent='#upmoBlk3::-webkit-scrollbar{display:none;}';document.head.appendChild(sx);}")
])
