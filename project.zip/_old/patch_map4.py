p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
pairs = [
 ("hold2.style.cssText='position:relative;height:0;overflow:hidden;transition:height .45s ease;background:#e5e7eb;';",
  "hold2.style.cssText='position:sticky;top:0;z-index:0;height:0;overflow:hidden;transition:height .45s ease;background:#e5e7eb;';b2.style.zIndex='1';"),
 ("window.dsMapRestore();if(hold){hold.remove();}",
  "window.dsMapRestore();if(hold){hold.remove();}b2.style.zIndex='';")
]
ok = True
for a, b in pairs:
    n = s.count(a)
    if n != 1:
        ok = False
        print("ANCHOR_COUNT", n, a[:50])
if ok:
    for a, b in pairs:
        s = s.replace(a, b)
    open(p, "w", encoding="utf-8").write(s)
    print("PATCHED")
