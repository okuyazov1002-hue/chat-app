def patch(p,pairs):
    s=open(p,encoding="utf-8").read()
    ok=True
    for a,b in pairs:
        n=s.count(a)
        if n!=1:
            ok=False;print("ANCHOR_COUNT",p,n,a[:50])
    if ok:
        for a,b in pairs: s=s.replace(a,b)
        open(p,"w",encoding="utf-8").write(s);print("PATCHED",p)
patch("public/main.html",[
("pm._grp=prepGroup;pm._code=o[0];allMarkers.push(pm);\n    });",
 "pm._grp=prepGroup;pm._code=o[0];allMarkers.push(pm);\n    });\n    window.dsMapFocus=function(code){var poly=prepPolys[code];if(!poly)return false;leafMap.invalidateSize();Object.keys(prepPolys).forEach(function(k){if(k==code){prepGroup.addLayer(prepPolys[k]);}else{prepGroup.removeLayer(prepPolys[k]);}});allMarkers.forEach(function(m){if(m._code==code){if(leafMap.hasLayer(m)==false)prepGroup.addLayer(m);}else if(leafMap.hasLayer(m)){leafMap.removeLayer(m);}});leafMap.fitBounds(poly.getBounds(),{maxZoom:18,padding:[20,20]});return true;};\n    window.dsMapAll=function(){Object.keys(prepPolys).forEach(function(k){prepGroup.addLayer(prepPolys[k]);});allMarkers.forEach(function(m){if(m._grp==prepGroup&&leafMap.hasLayer(m)==false)prepGroup.addLayer(m);});};")
])
patch("public/mobile-info.js",[
("if(ob){if(ob.getAttribute('data-nd')=='1')",
 "if(ob){if(window.dsMapOn&&window.dsMapFocus){var oc=ob.getAttribute('data-oc');if(window.dsFocused==oc){window.dsFocused=null;window.dsMapAll();}else{window.dsFocused=oc;window.dsMapFocus(oc);}return;}if(ob.getAttribute('data-nd')=='1')"),
("window.dsMapRestore();if(hold){hold.remove();}b2.style.zIndex='';",
 "window.dsFocused=null;if(window.dsMapAll){window.dsMapAll();}window.dsMapRestore();if(hold){hold.remove();}b2.style.zIndex='';")
])
