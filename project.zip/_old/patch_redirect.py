p="server.js"
s=open(p,encoding="utf-8").read()
a="app.set('trust proxy',1);"
b=a+"\napp.use(function(req,res,next){var h=String(req.headers.host||'').toLowerCase().split(':')[0];if(h==='dsomk.online'||h==='www.dsomk.online'){return res.redirect(301,'https://upmo.uz'+req.originalUrl);}next();});"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
