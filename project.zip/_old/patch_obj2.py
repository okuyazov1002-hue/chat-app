p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a = r"""op.innerHTML='<div style="padding:14px 18px;background:#fff;"><div style="font-size:9px;font-weight:700;color:#9ca3af;">'+code+'</div><div style="font-size:14px;font-weight:700;color:#1f2937;margin-top:2px;">'+nm+'</div></div>';"""
b = r"""function blk(l,id){return '<div style="flex:1;min-width:0;border-radius:16px;padding:7px 10px;background:rgba(255,255,255,0.5);"><div style="font-size:10px;font-weight:700;color:#4b5563;">'+l+'</div><div id="'+id+'" style="font-size:12px;font-weight:800;color:#1f2937;white-space:nowrap;margin-top:1px;">—</div></div>';}
op.innerHTML='<div style="background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);padding:12px 12px 14px;"><div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;"><span style="background:rgba(255,255,255,0.5);border-radius:10px;padding:4px 9px;font-size:11px;font-weight:800;color:#1f2937;flex:none;">'+code+'</span><span style="font-size:12px;font-weight:700;color:#fff;">'+nm+'</span></div><div style="font-size:12px;font-weight:700;color:#fff;">Общая стоимость</div><div id="dsOT" style="font-size:20px;font-weight:800;color:#fff;margin:2px 0 10px;">—</div><div style="display:flex;gap:8px;">'+blk('План','dsOP')+blk('Освоено','dsOD')+blk('Остаток','dsOR')+'</div></div>';
fetch('/api/prep/objects').then(function(x){return x.json();}).then(function(list){var o=null;list.forEach(function(q){if(q.code==code){o=q;}});if(o==null||(o.cost||0)<=0){return;}var c=o.cost||0;var d=o.done||0;var pl=c*(o.planPct||0)/100;function st(id,v){var e=document.getElementById(id);if(e){e.textContent=fmtMoney(v);}}st('dsOT',c);st('dsOP',pl);st('dsOD',d);st('dsOR',c-d);}).catch(function(){});"""
n = s.count(a)
if n == 1:
    open(p, "w", encoding="utf-8").write(s.replace(a, b))
    print("PATCHED")
else:
    print("ANCHOR_COUNT", n)
