p="public/main.html"
s=open(p,encoding="utf-8").read()
a="window.innerWidth<=768){window.dsGoPrep(k);}"
js="""window.innerWidth<=768){window.dsGoPrep(k);}else if(k.indexOf('act:')===0&&window.innerWidth>768){var pw=ov.querySelector('#upmoPanel2');if(!pw){pw=document.createElement('div');pw.id='upmoPanel2';pw.style.cssText='position:fixed;left:104px;right:16px;top:16px;bottom:16px;overflow:hidden;pointer-events:none;';pw.innerHTML='<div id="upmoPanel2in" style="pointer-events:auto;margin-left:400px;height:100%;background:#fff;border-radius:0 20px 20px 0;box-shadow:0 0 20px rgba(0,0,0,0.10);transform:translateX(-120%);transition:transform .45s cubic-bezier(.22,1,.36,1);"></div>';ov.insertBefore(pw,ov.firstChild);void pw.offsetWidth;}var pin=ov.querySelector('#upmoPanel2in');var opn=pin.getAttribute('data-o')=='1';pin.style.transform=opn?'translateX(-120%)':'translateX(0)';pin.setAttribute('data-o',opn?'0':'1');}"""
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,js));print("PATCHED")
