p="public/mobile-info.js"
s=open(p,encoding="utf-8").read()
a="border-radius:0 0 18px 18px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);\"></div>"
b="border-radius:0 0 18px 18px;background:linear-gradient(90deg,#6a5ae0 0%,#4a90d9 50%,#1dd3b0 100%);transition:height .4s ease;\"><div id=\"teamTab\" style=\"position:absolute;left:50%;bottom:-15px;transform:translateX(-50%);width:52px;height:28px;border-radius:14px;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,0.22);display:flex;align-items:center;justify-content:center;font-size:14px;color:#4a90d9;cursor:pointer;z-index:3;\">&#9650;</div></div>"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    s=s.replace(a,b)
    s+="""
document.addEventListener('click',function(e){var tb=e.target.closest('#teamTab');if(tb==null){return;}e.stopPropagation();var t=document.getElementById('teamTop');var closed=t.getAttribute('data-c')=='1';t.style.height=closed?'120px':'36px';t.setAttribute('data-c',closed?'0':'1');tb.innerHTML=closed?'&#9650;':'&#9660;';},true);
"""
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
