p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
a1="function redraw(code,o){"
fn=r"""var MNF=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
function setCardMonth(tt,bb,v0,v1,v2){
var cd=document.getElementById('upmoCard');if(cd===null||cd.children.length<3){return;}
var t=cd.children[0],bg=cd.children[1],g=cd.children[2];
var vs=[g.children[0].children[1],g.children[1].children[1],g.children[2].children[1]];
if(!cd._o){cd._o=[t.textContent,bg.textContent,vs[0].textContent,vs[1].textContent,vs[2].textContent];}
anim(t,tt);anim(bg,bb);anim(vs[0],v0);anim(vs[1],v1);anim(vs[2],v2);
}
function applyCard(){
var p=window.upmoPeriod||null;var code=window._upmoFocus||null;var o=code?(dm[code]||null):null;
if(!p){setCard(o,code,code===null);return;}
window.upmoScData(ty,code).then(function(sc){
var fm=(typeof fmtMoney==='function')?fmtMoney:function(x){return String(x);};
var key=p.y+'-'+(p.m<10?'0':'')+p.m;
var i=(sc.labels||[]).indexOf(key);
var tt=MNF[p.m-1]+' '+p.y+(code?' · '+code:'');
var pl=(i>=0)?(sc.planAmt[i]||0):null;
var f=(i>=0&&sc.factAmt[i]!=null)?sc.factAmt[i]:null;
var bb=(pl===null)?'—':String(fm(pl));
var v1=(f===null)?'—':String(fm(f));
var v2=(pl===null||f===null)?'—':String(fm(pl-f));
setCardMonth(tt,bb,bb,v1,v2);
setSide(o,code===null);
});
}
"""
a2="setCard(was?null:(dm[oc]||null),oc,was);"
a3="el.onclick=function(e){"
b3="if(window._upmoPerL){window.removeEventListener('upmo-period',window._upmoPerL);}window._upmoPerL=function(){applyCard();};window.addEventListener('upmo-period',window._upmoPerL);\n"+a3
c=[s.count(a1),s.count(a2),s.count(a3)]
if c!=[1,1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,fn+a1).replace(a2,"applyCard();").replace(a3,b3)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
