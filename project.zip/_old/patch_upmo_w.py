p="public/main.html"
s=open(p,encoding="utf-8").read()
a='width:520px;max-width:calc(100vw - 140px);border-radius:0 20px 20px 0;transform-origin:left center;box-shadow:16px -10px 16px rgba(0,0,0,0.08),20px 0 20px rgba(0,0,0,0.10),16px 10px 16px rgba(0,0,0,0.08);"><div style="padding:16px'
b=a.replace("width:520px","width:420px")
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
