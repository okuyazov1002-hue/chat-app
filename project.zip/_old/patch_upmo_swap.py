p="public/main.html"
s=open(p,encoding="utf-8").read()
pairs=[
("transition:transform .45s cubic-bezier(.22,1,.36,1);\"></div>'",
 "transition:transform .45s cubic-bezier(.22,1,.36,1),margin-left .45s cubic-bezier(.22,1,.36,1);\"></div>'"),
("if(opn&&same){pin.style.transform='translateX(-120%)';pin.setAttribute('data-o','0');}",
 "if(opn&&same){pin.style.transform='translateX(-120%)';pin.setAttribute('data-o','0');var mm=ov.querySelector('.stage-modal');if(mm){mm.style.transform='translateX(0)';mm.style.clipPath='inset(0 0 0 0px)';}pin.style.marginLeft='400px';}"),
("else{pin.setAttribute('data-k',k);pin.setAttribute('data-o','1');pin.style.transform='translateX(0)';",
 "else{pin.setAttribute('data-k',k);pin.setAttribute('data-o','1');pin.style.transform='translateX(0)';var mw=ov.querySelector('.stage-modal');if(mw){var wd=mw.offsetWidth;mw.style.clipPath='inset(0 0 0 0px)';void mw.offsetWidth;mw.style.transition='transform .45s cubic-bezier(.22,1,.36,1),clip-path .45s cubic-bezier(.22,1,.36,1)';mw.style.transform='translateX(-'+wd+'px)';mw.style.clipPath='inset(0 0 0 '+wd+'px)';}pin.style.marginLeft='0px';")
]
ok=True
for a,b in pairs:
    n=s.count(a)
    if n!=1:
        ok=False;print("ANCHOR_COUNT",n,a[:50])
if ok:
    for a,b in pairs: s=s.replace(a,b)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
