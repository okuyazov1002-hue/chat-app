p="public/main.html"
s=open(p,encoding="utf-8").read()
a="if(window.upmoMap){window.upmoMap(document.getElementById('upmoMapBlk'));}"
b="setTimeout(function(){var mk=document.getElementById('upmoMapBlk');if(window.upmoMap&&mk){window.upmoMap(mk);}},1500);"
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
