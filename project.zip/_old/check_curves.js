const mongoose = require("mongoose");
require("dotenv").config();
mongoose.connect(process.env.MONGODB_URI).then(async () => {
  const db = mongoose.connection.db;
  const docs = await db.collection("data").find({ _id: { $regex: "^prep_cost_curve_" } }).toArray();
  const reps = await db.collection("reports").find({ code: { $regex: "-" } }).toArray();
  const m = v => (v / 1e6).toFixed(1).padStart(10);
  const sum = a => (a || []).reduce((s, x) => s + (x || 0), 0);
  const seen = {};
  let tp = 0, tf = 0, bp = 0, bf = 0;
  console.log("КОД".padEnd(12) + "кривая_план   Basic_план       разн          кривая_факт   Basic_факт       разн   (млн)");
  docs.forEach(d => {
    const v = d.value || {};
    const code = d.code;
    seen[code] = 1;
    const r = reps.find(x => x.code == code);
    const rows = r ? (r.rows || []) : [];
    const bc = sum(rows.map(x => x.cost));
    const bd = sum(rows.map(x => x.done));
    const cp = sum(v.planPer);
    const cf = sum(v.factPer);
    tp += cp; tf += cf; bp += bc; bf += bd;
    const okp = Math.abs(cp - bc) < 1000 ? "OK" : "РАЗНИЦА";
    const okf = Math.abs(cf - bd) < 1000 ? "OK" : "РАЗНИЦА";
    console.log(String(code).padEnd(12) + m(cp) + m(bc) + m(cp - bc) + " " + okp.padEnd(8) + m(cf) + m(bd) + m(cf - bd) + " " + okf);
  });
  reps.forEach(r => {
    if (seen[r.code] == 1) { return; }
    const rows = r.rows || [];
    const c = sum(rows.map(x => x.cost));
    const d = sum(rows.map(x => x.done));
    bp += c; bf += d;
    console.log(String(r.code).padEnd(12) + "НЕТ КРИВОЙ (лист Cost не загружен). Basic план " + m(c) + " факт " + m(d));
  });
  console.log("ИТОГО кривая план " + m(tp) + " факт " + m(tf) + " | Basic план " + m(bp) + " факт " + m(bf));
  process.exit(0);
}).catch(e => { console.error(e); process.exit(1); });
