const mongoose = require("mongoose");
require("dotenv").config();
mongoose.connect(process.env.MONGODB_URI).then(async () => {
  const db = mongoose.connection.db;
  const reps = await db.collection("reports").find({ code: { $regex: "-" } }).toArray();
  console.log("=== Project в строках (код | строк | с Project | пример | updatedAt) ===");
  reps.forEach(r => {
    const rows = r.rows || [];
    const withP = rows.filter(x => x.project);
    console.log(r.code, "|", rows.length, "|", withP.length, "|", withP.length ? withP[0].project : "-", "|", r.updatedAt);
  });
  const mob = await db.collection("data").find({ _id: { $regex: "^prep_mobilization_" } }).toArray();
  console.log("=== Mobilization (код | месяцев | сумма plan | сумма fact | updatedAt) ===");
  mob.forEach(d => {
    const v = d.value || {};
    const sum = a => (a || []).reduce((s, x) => s + (x || 0), 0);
    console.log(d.code, "|", (v.labels || []).length, "|", sum(v.plan), "|", sum(v.fact), "|", d.updatedAt);
  });
  process.exit(0);
}).catch(e => { console.error(e); process.exit(1); });
