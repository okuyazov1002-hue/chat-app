p="public/upmo-proj.js"
s=open(p,encoding="utf-8").read()
a1="function applyCard(){"
fn=r"""function setProgPct(pp,fp){
var p=document.getElementById('upmoBlk4b2');if(!p||p.children.length<2){return;}
var cs=p.children[0].children;
var pv=[cs[0].children[1],cs[1].children[1],cs[2].children[1]];
var bars=p.children[1].children;
var bi=[bars[0].firstChild,bars[1].firstChild];
if(!p._o){p._o=[pv[0].textContent,pv[1].textContent,pv[2].textContent,pv[2].style.color,bi[0].style.width,bi[1].style.width];}
function pf(x){return (Math.round(x*10)/10).toString().replace('.',',')+'%';}
var x0,x1,x2,xc,w0,w1;
if(pp===null||fp===null){x0='—';x1='—';x2='—';xc='#9ca3af';w0='0%';w1='0%';}
else{var df=fp-pp;var base=Math.max(pp,fp);x0=pf(pp);x1=pf(fp);x2=(df>0?'+':'')+pf(df);xc=df<0?'#e53e3e':'#38a169';w0=(base>0?pp/base*100:0)+'%';w1=(base>0?fp/base*100:0)+'%';}
anim(pv[0],x0);anim(pv[1],x1);anim(pv[2],x2);
pv[2].style.color=xc;bi[0].style.width=w0;bi[1].style.width=w1;
}
"""
a2="setSide(o,code===null);"
b2=a2+"\nwindow.upmoSumData(ty,code,o).then(function(su){var tot=su.totalCost||0;var pp=(tot&&pl!==null)?pl/tot*100:null;var fp=(tot&&f!==null)?f/tot*100:null;setProgPct(pp,fp);});"
c=[s.count(a1),s.count(a2)]
if c!=[1,1]:
    print("ANCHOR_COUNT",c)
else:
    s=s.replace(a1,fn+a1).replace(a2,b2)
    open(p,"w",encoding="utf-8").write(s);print("PATCHED")
