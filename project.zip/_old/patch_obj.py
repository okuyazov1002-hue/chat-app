def patch(p, pairs):
    s = open(p, encoding="utf-8").read()
    ok = True
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            ok = False
            print("ANCHOR_COUNT", n, p, a[:45])
    if ok:
        for a, b in pairs:
            s = s.replace(a, b)
        open(p, "w", encoding="utf-8").write(s)
        print("PATCHED", p)
patch("public/mobile-info.js", [
 (r"""objs+='<div style="display:flex;""", r"""objs+='<div class="dsObj" data-oc="'+c+'" style="cursor:pointer;display:flex;"""),
 (r"""box.addEventListener('click',function(e){var r=e.target.closest('.dsPr');if(r==null){return;}""", r"""box.addEventListener('click',function(e){var ob=e.target.closest('.dsObj');if(ob){window.dsOpenObj(ob.getAttribute('data-oc'));return;}var r=e.target.closest('.dsPr');if(r==null){return;}""")
])
patch("public/mobile-top.js", [
 (r"""function topClose(){""", r"""function topClose(){var ob=document.getElementById('objPage');if(ob&&window.dsCloseObj){window.dsCloseObj();return;}""")
])
