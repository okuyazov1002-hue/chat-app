p="public/upmo-months.js"
s=open(p,encoding="utf-8").read()
a="H=Math.max(70,Math.min(420,el.clientHeight-59))"
b="""H=(function(){var pn=el.closest(".upm-win"),wr=el.parentNode,rw=wr?wr.previousElementSibling:null,sc=document.getElementById("upmoSc");if(!pn||!rw){return 110;}var a=pn.clientHeight-32-rw.offsetHeight-16-(sc?sc.offsetHeight:211)-16-59;return Math.max(70,Math.min(420,a));})()"""
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
