const fs = require("fs");
let s = fs.readFileSync("server.js", "utf8");
const pairs = [
  ['        stage: row.getCell(4).value || "",\n', '        project: String(row.getCell(3).value || ""),\n        stage: row.getCell(4).value || "",\n'],
  ['row.contractor || "", "", row.stage || ""', 'row.contractor || "", row.project || "", row.stage || ""'],
  ['total.addRow([r.code, contractor, "", mh, mhFact, cost, done, progress]);', 'total.addRow([r.code, contractor, (rows.find(x => x.project) || {}).project || "", mh, mhFact, cost, done, progress]);']
];
let ok = true;
pairs.forEach(p => { const n = s.split(p[0]).length - 1; if (n == 1) { return; } ok = false; console.log("ANCHOR_COUNT", n, p[0].slice(0, 40)); });
if (ok) {
  pairs.forEach(p => { s = s.split(p[0]).join(p[1]); });
  fs.writeFileSync("server.js", s);
  console.log("PATCHED");
}
