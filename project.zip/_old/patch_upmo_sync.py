def patch(p,pairs):
    s=open(p,encoding="utf-8").read()
    ok=True
    for a,b in pairs:
        n=s.count(a)
        if n!=1:
            ok=False;print("ANCHOR_COUNT",p,n,a[:50])
    if ok:
        for a,b in pairs: s=s.replace(a,b)
        open(p,"w",encoding="utf-8").write(s);print("PATCHED",p)
patch("public/upmo-scurve.js",[
("<div style=\"padding:0 12px 12px;overflow-x:auto;scrollbar-width:none;\">'+s+'</div>';",
 "<div id=\"upmoScS\" style=\"padding:0 12px 12px;overflow-x:auto;scrollbar-width:none;cursor:grab;\">'+s+'</div>';if(window.upmoLink){window.upmoLink();}")
])
patch("public/upmo-months.js",[
("<div id=\"upmoMS\" style=\"overflow-x:auto;scrollbar-width:none;padding:6px 12px 8px;\">",
 "<div id=\"upmoMS\" style=\"overflow-x:auto;scrollbar-width:none;padding:6px 12px 8px;cursor:grab;\">"),
("ms.scrollLeft=Math.max(0,(last-5)*step);",
 "ms.scrollLeft=Math.max(0,(last-5)*step);if(window.upmoLink){window.upmoLink();}")
])
patch("public/main.html",[
('<script src="upmo-months.js"></script>','<script src="upmo-months.js"></script>\n<script src="upmo-sync.js"></script>')
])
