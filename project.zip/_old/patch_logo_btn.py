p="public/main.html"
s=open(p,encoding="utf-8").read()
a='<button id="teamBtn"'
svg='<svg width="34" height="34" viewBox="0 0 120 120" aria-label="UPMO"><defs><linearGradient id="ubArc" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient><linearGradient id="ubBarsG" gradientUnits="userSpaceOnUse" x1="0" y1="38" x2="0" y2="88"><stop offset="0" stop-color="#6A5BD6"/><stop offset="0.5" stop-color="#5B94D0"/><stop offset="1" stop-color="#5FD2B0"/></linearGradient><clipPath id="ubBars"><rect x="34" y="42" width="11" height="42" rx="2.5"/><rect x="49" y="55" width="11" height="29" rx="2.5"/><rect x="64" y="66" width="11" height="18" rx="2.5"/><rect x="79" y="74" width="11" height="10" rx="2.5"/></clipPath></defs><circle cx="60" cy="60" r="52" fill="none" stroke="#6A5BD6" stroke-width="9" stroke-linecap="round" stroke-dasharray="78 249" transform="rotate(180 60 60)"/><circle cx="60" cy="60" r="52" fill="none" stroke="url(#ubArc)" stroke-width="9" stroke-linecap="round" stroke-dasharray="205 122" transform="rotate(285 60 60)"/><g clip-path="url(#ubBars)"><rect x="30" y="38" width="64" height="50" fill="url(#ubBarsG)"/><polygon points="34,42 45,42 45,84" fill="#fff" fill-opacity="0.22"/><polygon points="49,55 60,55 60,84" fill="#fff" fill-opacity="0.22"/><polygon points="64,66 75,66 75,84" fill="#fff" fill-opacity="0.22"/><polygon points="79,74 90,74 90,84" fill="#fff" fill-opacity="0.22"/></g></svg>'
b='<button id="upmoBtn" title="UPMO">'+svg+'</button>\n'+a
n=s.count(a)
if n!=1:
    print("ANCHOR_COUNT",n)
else:
    open(p,"w",encoding="utf-8").write(s.replace(a,b));print("PATCHED")
