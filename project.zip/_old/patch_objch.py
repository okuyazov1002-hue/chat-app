p = "public/mobile-info.js"
s = open(p, encoding="utf-8").read()
a1 = r"""border-radius:22px 22px 0 0;padding:16px 12px 16px;"""
b1 = r"""border-radius:22px 22px 0 0;padding:16px 12px 40px;"""
a2 = r"""fetch('/api/prep/object/'+encodeURIComponent(code)+'/term')"""
b2 = r"""if(window.dsObjCharts){window.dsObjCharts(op,code);}fetch('/api/prep/object/'+encodeURIComponent(code)+'/term')"""
c1 = s.count(a1)
c2 = s.count(a2)
if c1 == 1 and c2 == 1:
    open(p, "w", encoding="utf-8").write(s.replace(a1, b1).replace(a2, b2))
    print("PATCHED")
else:
    print("ANCHOR_COUNT", c1, c2)
